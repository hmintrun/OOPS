# Collect form data into Google Sheets

A sign-up form with no server of your own. `apps-script/Code.gs` runs inside a Google Sheet and adds one row for every POST it receives, and `index.html` is a plain form that sends to it. This site's workshop registration form saves its rows the same way.

## Run it
1. Create a Google Sheet. Open Extensions → Apps Script, delete what is there and paste in `apps-script/Code.gs`.
2. Press Deploy → New deployment and choose the type Web app. Set "Execute as" to Me and "Who has access" to Anyone, then authorise it.
3. Copy the web app URL, which ends in `/exec`. Open it in a browser tab: it should say the collector is running.
4. Paste the URL into `ENDPOINT` near the bottom of `index.html`, open `index.html` in a browser and send the form. The row appears in a tab named Responses.

In a React or Next.js app, use `react/sheet.ts` instead of the script inside `index.html`. It has the same sender, plus a hook that remembers that this browser already sent a row.

## Watch out
- The URL is public. Anyone who has it can add rows, so treat the sheet as untrusted input and keep nothing secret in it.
- After you change `Code.gs`, the live URL still runs the old code. Open Deploy → Manage deployments, edit the deployment and choose "New version".
- If the form says it could not confirm the save, look at the sheet before you send again. The usual cause is that access is not set to Anyone.
- The body is sent as `text/plain` on purpose. With `application/json` the browser first sends a preflight request, and Apps Script does not answer it.
- `clean_()` in the script puts an apostrophe in front of any value that starts with `=`, `+`, `-` or `@`, so nobody can plant a formula in your sheet. Keep it.

## Make it yours
To collect another field, add it in `COLUMNS` in `Code.gs`, in the form, and in `SheetRow` if you use the React file, then deploy a new version. A good next step is to send a row after an on-chain action, for example the wallet and the transaction hash after a mint.
