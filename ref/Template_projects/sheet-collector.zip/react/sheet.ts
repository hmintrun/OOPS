"use client";

// The same sender as index.html, as a module for a React or Next.js app, plus a small store that remembers
// "this browser already sent a row" so the form can show a thank-you screen after a reload.

import { useSyncExternalStore } from "react";

// ❓ What is NEXT_PUBLIC_ and why not use process.env.SHEET_ENDPOINT?
// → Next.js only puts variables with the NEXT_PUBLIC_ prefix into the bundle that runs in the browser; other variables exist only on the server.
//   This file runs client-side, so the prefix is required. With Vite, read import.meta.env.VITE_SHEET_ENDPOINT instead.
export const SHEET_ENDPOINT = (process.env.NEXT_PUBLIC_SHEET_ENDPOINT ?? "").trim();
export const hasSheetEndpoint = /^https:\/\//.test(SHEET_ENDPOINT);

// Keep these fields in step with COLUMNS in apps-script/Code.gs.
export type SheetRow = {
  name: string;
  contact: string;
  wallet: string;
  note: string;
};

const KEY = "sheet-collector:submitted";

// ❓ What are listeners and snapshot for?
// → This is a minimal "external store" for useSyncExternalStore: snapshot caches the current value, listeners are the
//   components that need to re-render when it changes. localStorage does not announce changes within the same tab, so we build this ourselves.
const listeners = new Set<() => void>();
let snapshot: string | undefined;

// ❓ Why must reading localStorage be wrapped in try/catch?
// → localStorage can throw: Safari private mode, an iframe with blocked cookies, or running on the server (no window).
//   Returning "" keeps the app running normally.
function read(): string {
  try {
    return localStorage.getItem(KEY) ?? "";
  } catch {
    return "";
  }
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

// ❓ Why must getSnapshot return the same value if nothing changed?
// → useSyncExternalStore compares the snapshot with Object.is on every render; if it kept returning different values, React
//   would render forever. The value is a string cached in `snapshot`, and localStorage is only read the first time.
function getSnapshot() {
  if (snapshot === undefined) snapshot = read();
  return snapshot;
}

// ❓ What is getServerSnapshot for?
// → On the server there is no localStorage, so it always returns "". The first client render uses this value too,
//   so the HTML matches; right after that React reads the real getSnapshot and re-renders if it differs.
function getServerSnapshot() {
  return "";
}

/** The row this browser already sent, or null. */
export function useSubmittedRow(): SheetRow | null {
  const raw = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as SheetRow;
  } catch {
    return null;
  }
}

function remember(row: SheetRow) {
  const raw = JSON.stringify(row);
  try {
    localStorage.setItem(KEY, raw);
  } catch {}
  // ❓ We already called setItem, so why also assign the snapshot and call listeners?
  // → setItem does not make React re-render. Updating the cache and calling the listeners makes every component that uses
  //   useSubmittedRow render right away.
  snapshot = raw;
  for (const l of listeners) l();
}

export function forgetSubmittedRow() {
  try {
    localStorage.removeItem(KEY);
  } catch {}
  snapshot = "";
  for (const l of listeners) l();
}

export type SubmitResult = { ok: true } | { ok: false; reason: string };

export async function submitRow(row: SheetRow): Promise<SubmitResult> {
  if (!hasSheetEndpoint) {
    return { ok: false, reason: "NEXT_PUBLIC_SHEET_ENDPOINT is not set in .env.local" };
  }

  try {
    // ❓ Why Content-Type text/plain when the body is JSON?
    // → A cross-origin POST marked application/json makes the browser ask permission first (an OPTIONS "preflight"), and
    //   Apps Script does not answer preflights. text/plain is a "simple request": the browser sends it straight away.
    const res = await fetch(SHEET_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(row),
    });
    // ❓ Where does the answer come from?
    // → Apps Script answers the POST with a redirect to another Google address and the browser follows it by itself.
    //   What arrives here is the JSON that doPost() returned, so { ok: true } means the row is in the sheet.
    const answer = (await res.json()) as { ok?: boolean; error?: string };
    if (!answer.ok) return { ok: false, reason: answer.error || "the script reported an error" };
    remember(row);
    return { ok: true };
  } catch (e) {
    // ❓ Why is there no automatic retry?
    // → A failure here does not prove that nothing was written: the row can be saved and the answer lost on the way back.
    //   Retrying by itself could add the same row twice, so the caller should tell the person to check the sheet first.
    return { ok: false, reason: (e as Error).message || "could not confirm that the row was saved" };
  }
}
