import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
// ❓ What is solc, and why do we not need Remix/Hardhat?
// → solc is the Solidity compiler itself, packaged as an npm package (solc-js runs on WASM).
// → With it you can compile straight in Node, with no other tool.
import solc from "solc";

export const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const SOURCE = join(ROOT, "contracts", "AvaxCats.sol");

// ❓ The contract has `import "@openzeppelin/..."`, where does solc get that file?
// → solc only accepts the one source we give it; when it meets an import it calls this callback with the path (for example "@openzeppelin/contracts/token/ERC721/ERC721.sol").
// → We read the file from node_modules and return { contents }. Without this callback → "File not found" even after npm install.
function findImports(path) {
  try {
    return { contents: readFileSync(join(ROOT, "node_modules", path), "utf8") };
  } catch {
    return {
      error:
        `Import not found: ${path}\n` +
        "→ Have you run `npm install` in this folder?",
    };
  }
}

export function compile({ quiet = false } = {}) {
  if (!quiet) {
    console.log(
      `🔨 Compile contracts/AvaxCats.sol (solc ${solc.version().split("+")[0]})…`,
    );
  }

  // ❓ What format is this input object?
  // → It is the "standard JSON input", the official way to talk to solc: language, sources (file name → contents), settings.
  // → Remix/Hardhat/Foundry all produce exactly this JSON internally. optimizer runs=200 is a common default and reduces gas when calling functions.
  const input = {
    language: "Solidity",
    sources: { "AvaxCats.sol": { content: readFileSync(SOURCE, "utf8") } },
    settings: {
      optimizer: { enabled: true, runs: 200 },
      // ❓ Why only ask for "abi" and "evm.bytecode.object"?
      // → outputSelection picks the output for every file (*) and every contract (*). Deploying needs exactly two things: the abi (to encode/decode function calls)
      // → and the bytecode (the EVM code sent to the chain). We do not ask for the AST, sourcemaps… so compiling is fast and the output is small.
      outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } },
    },
  };

  // ❓ What does solc.compile take and return?
  // → It takes a JSON STRING (so we JSON.stringify the input) and returns a JSON string → JSON.parse it again.
  // → The option { import: findImports } attaches the import-resolving callback above.
  const out = JSON.parse(
    solc.compile(JSON.stringify(input), { import: findImports }),
  );

  // ❓ Why filter on severity === "error"?
  // → out.errors also contains warnings (for example an unused variable). We only stop on real errors and let warnings through.
  // → Without this check the next line crashes confusingly because out.contracts is undefined.
  const errors = (out.errors ?? []).filter((e) => e.severity === "error");
  if (errors.length) {
    for (const e of errors) console.error(e.formattedMessage);
    process.exit(1);
  }

  // ❓ Why index two levels ["AvaxCats.sol"]["AvaxCats"]?
  // → solc output is grouped by file → by contract, because one .sol file can hold several contracts.
  // → The key "AvaxCats.sol" must match the key in input.sources above; the contract name must match `contract AvaxCats` in the .sol.
  const artifact = out.contracts["AvaxCats.sol"]["AvaxCats"];
  const abi = artifact.abi;
  // ❓ Why add "0x"?
  // → solc returns the bytecode as a raw hex string with no prefix. viem/ethers need hex as `0x${string}`, and without it deployContract refuses.
  // → This is all the EVM machine code that goes into the data field of the deploy transaction.
  const bytecode = "0x" + artifact.evm.bytecode.object;

  if (!quiet) {
    console.log(
      `✅ Compile OK: bytecode ${(bytecode.length - 2) / 2} bytes, ` +
        `${abi.filter((x) => x.type === "function").length} public functions`,
    );
  }
  return { abi, bytecode };
}

// ❓ What is this last line for?
// → This file is both a module (deploy.mjs imports compile) and directly runnable (`node scripts/compile.mjs`).
// → It only runs itself when called directly, so it does not compile twice when imported.
if (process.argv[1]?.endsWith("compile.mjs")) compile();
