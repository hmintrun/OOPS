import { defineChain } from "viem";
import { avalancheFuji } from "viem/chains";

// ❓ What is an RPC URL and why does it come from env?
// → RPC is the HTTP endpoint of a node that accepts JSON-RPC (eth_call, eth_sendRawTransaction…). anvil listens on 127.0.0.1:8545 by default;
// → NEXT_PUBLIC_RPC_URL lets you change the port when 8545 is busy. Declared in one place, shared by anvil.mjs, deploy and the frontend.
export const LOCAL_RPC_URL =
  process.env.NEXT_PUBLIC_RPC_URL || "http://127.0.0.1:8545";

// ❓ What is defineChain for, viem already has Fuji?
// → viem ships avalancheFuji but does not know our local chain. defineChain creates a chain object (id 31337, currency, rpc)
// → so the client signs transactions with the right chainId (EIP-155) and shows the right AVAX unit.
export const anvil = defineChain({
  id: 31337,
  name: "Anvil (local)",
  nativeCurrency: { name: "Avalanche", symbol: "AVAX", decimals: 18 },
  rpcUrls: { default: { http: [LOCAL_RPC_URL] } },
  testnet: true,
});

// ❓ Is it OK to keep a private key in the code?
// → This is account #0's key that anvil prints on every start: fixed and PUBLIC to the whole world, worth something only on the local chain.
// → Never send real assets to this address. Real keys always live in .env.local (not committed).
export const ANVIL_PRIVATE_KEY =
  "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80";
export const ANVIL_PRIVATE_KEY_2 =
  "0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d";

// ❓ What is the priority order for choosing the network?
// → --network=fuji / --network fuji > a bare argument "fuji"/"anvil" > the NEXT_PUBLIC_CHAIN variable > default anvil.
// → Every script shares this function, so `npm run deploy -- fuji` and `npm run deploy -- --network=fuji` behave the same.
export function resolveNetwork(argv = process.argv) {
  const flag = argv.find((a) => a.startsWith("--network"));
  const fromFlag = flag?.includes("=")
    ? flag.split("=")[1]
    : flag
      ? argv[argv.indexOf(flag) + 1]
      : undefined;
  const bare = argv.slice(2).find((a) => /^(anvil|fuji)$/i.test(a));
  const raw = fromFlag || bare || process.env.NEXT_PUBLIC_CHAIN || "anvil";

  // ❓ Why only two choices?
  // → A whitelist: an unknown value (for example "mainnet") falls back to anvil, so you never deploy by accident to a network with real money.
  // → It returns the chain object, rpcUrl and explorer together so scripts do not have to assemble them.
  const key = raw.toLowerCase() === "fuji" ? "fuji" : "anvil";
  return key === "fuji"
    ? {
        key,
        chain: avalancheFuji,
        rpcUrl: avalancheFuji.rpcUrls.default.http[0],
        explorer: "https://testnet.snowtrace.io",
        label: "Avalanche Fuji (43113)",
      }
    : {
        key,
        chain: anvil,
        rpcUrl: LOCAL_RPC_URL,
        explorer: "",
        label: `Anvil local (31337) at ${LOCAL_RPC_URL}`,
      };
}
