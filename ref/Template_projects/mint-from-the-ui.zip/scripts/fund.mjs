import { createPublicClient, formatEther, http, parseEther, toHex } from "viem";
import { resolveNetwork } from "./chains.mjs";

const net = resolveNetwork();
// ❓ Why does this script refuse to run on Fuji?
// → anvil_setBalance is an RPC method only anvil has; only a local node offers it. A real network has no way to "print money":
// → to get test AVAX you have to ask a faucet. That is the core difference between a local chain and a real network.
if (net.key !== "anvil") {
  console.error(`
❌ npm run fund only works on anvil.

   Real networks can't print money on demand. That is exactly the difference.
   On Fuji, get test AVAX from the faucet: https://build.avax.network/console/primary-network/faucet
`);
  process.exit(1);
}

const [address, amountArg] = process.argv.slice(2).filter((a) => !a.startsWith("--"));
if (!/^0x[0-9a-fA-F]{40}$/.test(address ?? "")) {
  console.error(`
❌ Missing wallet address.

   npm run fund 0xYourWalletAddress        # fund 10000 AVAX
   npm run fund 0xYourWalletAddress 500    # fund 500 AVAX

   Where to find it: open Core/MetaMask and copy the active wallet address, or
   check the wallet bar on the mint page after clicking "Connect wallet".
`);
  process.exit(1);
}

// ❓ Why is the amount a string, "10000"?
// → parseEther below takes a string and converts it to wei (×10^18) as a BigInt, avoiding JavaScript's float errors with large numbers.
const amount = amountArg ?? "10000";
const client = createPublicClient({ chain: net.chain, transport: http(net.rpcUrl) });

try {
  // ❓ What is the getChainId call for?
  // → It pings the RPC to see whether anvil is running. Without `npm run anvil` it fails right here with instructions, instead of a confusing ECONNREFUSED in the next step.
  await client.getChainId();
} catch {
  console.error(`
❌ Could not connect to anvil at ${net.rpcUrl}
   Open another terminal tab and run:  npm run anvil
`);
  process.exit(1);
}

const before = await client.getBalance({ address });

// ❓ What is client.request with the method "anvil_setBalance"?
// → A raw JSON-RPC call: viem has no wrapper for anvil's own methods, so we send it directly. params = [address, the new balance as hex wei].
// → The balance is SET (not added to) immediately: no transaction, no block, nobody signs.
await client.request({
  method: "anvil_setBalance",
  params: [address, toHex(parseEther(amount))],
});

// ❓ Why read the balance again after setting it?
// → To confirm the state on the node really changed and to print before/after. getBalance returns wei as a BigInt → formatEther to display it.
const after = await client.getBalance({ address });
console.log(`
💰 Funded ${address}
   before : ${formatEther(before)} AVAX
   after  : ${formatEther(after)} AVAX

   Go back to the mint page. The balance updates automatically and you can mint right away.
`);
