// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ❓ Why import OpenZeppelin instead of writing ERC-721 ourselves?
// → ERC721URIStorage already has ownerOf, transfer, approve, tokenURI... and has been audited.
//   We only write our own logic: who can mint which cat, once each.
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";

contract AvaxCats is ERC721URIStorage {

    // ❓ How is a constant different from a normal variable?
    // → The value is written straight into the bytecode at compile time: reading it costs no SLOAD gas and nobody can change it.
    uint256 public constant COLLECTION_SIZE = 48;

    uint256 public constant MAX_SUPPLY = COLLECTION_SIZE;

    // ❓ What do these three state variables store?
    // → totalMinted: how many tokens have been issued (also the next tokenId).
    //   catMinted[catId]: whether this cat already has an owner. catOf[tokenId]: which cat this token is.
    //   public generates a getter, so the frontend can read it directly through the ABI.
    uint256 public totalMinted;
    mapping(uint256 => bool) public catMinted;
    mapping(uint256 => uint256) public catOf;

    // ❓ There is already a return value, why an event?
    // → A return value is only received on a direct call. When the frontend sends a transaction it only gets a receipt,
    //   so it has to read the tokenId from the event in receipt.logs. indexed lets you filter logs by address / tokenId / catId.
    event Minted(address indexed to, uint256 indexed tokenId, uint256 indexed catId);

    // ❓ How is a custom error different from require("error string")?
    // → Cheaper on gas than a text string, and the frontend can recognise the exact error name (CatAlreadyMinted)
    //   and show a proper message instead of a generic "execution reverted".
    error CatDoesNotExist(uint256 catId);
    error CatAlreadyMinted(uint256 catId);

    // ❓ Where are the token name and symbol set?
    // → Passed to the ERC721 constructor exactly once at deploy time; they cannot change afterwards.
    constructor() ERC721("AvaxCats - Team1 VN", "ACAT") {}

    // ❓ Why does mint take a uri instead of the contract generating the metadata?
    // → The frontend already packs the image + attributes into a base64 data URI; the contract just stores that string.
    //   No IPFS, no server: the whole NFT lives on-chain. The trade-off is a long tokenURI (~1.8KB), so a mint costs ~1.4M gas.
    function mint(uint256 catId, string memory uri) external returns (uint256) {
        // ❓ How important are these two checks?
        // → They are the collection's "rules": only 48 cats, each one once.
        //   The UI can be edited or the contract called directly, but rules written here cannot be bypassed.
        if (catId >= COLLECTION_SIZE) revert CatDoesNotExist(catId);
        if (catMinted[catId]) revert CatAlreadyMinted(catId);

        // ❓ Why update state first and only then call _safeMint?
        // → The checks-effects-interactions pattern: change state before calling out, which blocks reentrancy.
        catMinted[catId] = true;
        // ❓ How is ++totalMinted different from totalMinted++?
        // → It increments first and then takes the value, so the first token has id = 1 and there is no token 0.
        uint256 tokenId = ++totalMinted;
        catOf[tokenId] = catId;

        // ❓ How is _safeMint different from _mint?
        // → If the recipient is a contract, _safeMint checks that it knows how to receive ERC-721 (onERC721Received),
        //   so the NFT cannot get stuck forever in a contract that cannot handle it.
        _safeMint(msg.sender, tokenId);
        _setTokenURI(tokenId, uri);
        emit Minted(msg.sender, tokenId, catId);
        return tokenId;
    }

    // ❓ There is already catMinted, why do we need mintedBitmap?
    // → The frontend needs the state of all 48 cats; calling catMinted 48 times is 48 RPC calls.
    //   Packing 48 bits into one uint256 (bit i = 1 means cat i is minted) needs a single read. It is a view, so it costs no gas.
    function mintedBitmap() external view returns (uint256 bits) {
        for (uint256 i; i < COLLECTION_SIZE; ++i) {
            if (catMinted[i]) bits |= (1 << i);
        }
    }
}
