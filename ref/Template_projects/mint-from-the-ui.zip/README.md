# Read and write a contract from the UI

A small Next.js app that talks to an AvaxCats contract. It reads how many cats are minted, lets you pick one, sends the mint transaction from your wallet, waits for the receipt and shows the token it created. It is the mint flow of this site's mint dApp, made to run on its own, with the contract and its deploy script included.

## Run it
The quickest way is a local chain. It needs Foundry (getfoundry.sh) and Node 22.9 or newer, but no wallet and no test AVAX.

1. Install the packages and copy `.env.example` to `.env.local`.
2. Start the local chain and leave it running.
3. In a second terminal, deploy the contract. The script writes its address to `.env.local`.
4. Start the app, open http://localhost:3000, press **Dev wallet (anvil)**, pick a cat and press **Mint NFT**.

```bash
npm install
cp .env.example .env.local
npm run anvil          # terminal 1, keep it running
npm run deploy:anvil   # terminal 2
npm run dev            # terminal 2
```

To use the Fuji testnet instead, put the private key of a separate testnet wallet in `.env.local` as `DEPLOYER_PRIVATE_KEY`, run `npm run deploy:fuji`, restart `npm run dev`, and connect Core or MetaMask with some test AVAX in it.

## Where to look
- `src/lib/contract.ts` has the ABI: only the functions and the event this page uses.
- `src/components/SupplyBadge.tsx` and `src/lib/minted.ts` read from the chain. Reads are free and need no wallet.
- `src/components/MintPanel.tsx` sends the transaction, waits for the receipt, reads the token id from the `Minted` event and turns common errors into one plain sentence.
- `src/lib/metadata.ts` builds the tokenURI. The image and traits are stored on-chain, with no IPFS.
- `src/lib/deployed.ts` finds the contract address.
- `contracts/AvaxCats.sol` and `scripts/` are the contract and the scripts that compile and deploy it. *Your first smart contract* explains them and adds a test.

## Watch out
- A transaction hash only means the transaction was sent. Wait for the receipt and check its status before you tell the user it worked.
- Each cat can be minted once, and the contract enforces it. If two people pick the same cat, the second transaction reverts with `CatAlreadyMinted`.
- A mint stores about 1.8 KB on-chain and used about 1.7M gas in our local run. That is fine on a testnet and expensive on a busy chain.
- Stopping anvil erases the chain. When you start it again, run `npm run deploy:anvil` again and restart `npm run dev`.
- Every `NEXT_PUBLIC_` value is built into the page and is public. `DEPLOYER_PRIVATE_KEY` has no such prefix, so it stays on your machine. Use a wallet made only for the testnet and keep `.env.local` out of git.

## Make it yours
Swap the ABI, the address and the function names for your own contract, and keep the same flow: read, write, wait for the receipt.
