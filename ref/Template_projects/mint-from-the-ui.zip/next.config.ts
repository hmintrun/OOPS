import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // ❓ What does output: "export" change?
  // → `npm run build` writes plain HTML, CSS and JS into out/. There is no Node server to run:
  //   any static host (GitHub Pages, Cloudflare, Vercel) can serve that folder.
  output: "export",
  // ❓ Why allow these dev origins?
  // → To test with a wallet app on your phone you open the dev server by your laptop's LAN address
  //   (http://192.168.x.x:3000). Next blocks dev requests from other origins unless they are listed here.
  allowedDevOrigins: ["127.0.0.1", "192.168.*.*", "10.*.*.*", "172.16.*.*"],
};

export default nextConfig;
