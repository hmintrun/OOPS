import type { Metadata, Viewport } from "next";
import { Geist_Mono, Hanken_Grotesk } from "next/font/google";
import "./globals.css";
import { Providers } from "./providers";

// ❓ What do these two font calls do?
// → next/font downloads the fonts when you build and serves them from your own site, so the page makes no request to Google.
//   Each call exposes a CSS variable; globals.css maps them to Tailwind's font-sans and font-mono.
const sans = Hanken_Grotesk({ subsets: ["latin", "latin-ext", "vietnamese"], variable: "--font-brand-sans", display: "swap" });
const mono = Geist_Mono({ subsets: ["latin"], variable: "--font-geist-mono", display: "swap" });

export const metadata: Metadata = {
  title: "Mint from the UI",
  description: "Read a contract and send a mint transaction from React with wagmi and viem.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#0a0a0a",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${sans.variable} ${mono.variable}`}>
      <body className="flex min-h-screen flex-col font-sans antialiased">
        {/* ❓ Why wrap everything in Providers? → Every wagmi hook below needs the config and the query cache it provides. */}
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
