"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { CatGrid } from "@/components/CatGrid";
import { MintPanel } from "@/components/MintPanel";
import { WalletBar } from "@/components/WalletBar";
import { Mono } from "@/components/ui";
import { CATS } from "@/lib/cats";
import { CHAIN_LABEL } from "@/lib/chains";
import { explorerAddress } from "@/lib/contract";
import { useContractAddress } from "@/lib/deployed";
import { useMintedCats } from "@/lib/minted";

export default function Home() {
  const { address: contract, isConfigured } = useContractAddress();
  // ❓ Why does the page read the minted cats instead of CatGrid or MintPanel?
  // → One read of mintedBitmap feeds both: the grid greys out taken cats and the panel knows whether the selected one is free.
  const { taken, available, mintedCount, refetch } = useMintedCats();
  const [selected, setSelected] = useState(0);
  const [rolling, setRolling] = useState(false);

  const [justMinted, setJustMinted] = useState<number | null>(null);
  const rollTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  // ❓ What does Random do?
  // → It draws from the cats that are still free (available), six times 70ms apart so the grid visibly "rolls" before it settles.
  const pickRandom = useCallback(() => {
    if (available.length === 0) return;
    const draw = () =>
      setSelected(available[Math.floor(Math.random() * available.length)]!);
    if (rollTimer.current) clearInterval(rollTimer.current);
    setJustMinted(null);
    setRolling(true);
    draw();
    let n = 1;
    rollTimer.current = setInterval(() => {
      draw();
      if (++n >= 6) {
        if (rollTimer.current) clearInterval(rollTimer.current);
        rollTimer.current = null;
        setRolling(false);
      }
    }, 70);
  }, [available]);

  useEffect(
    () => () => {
      if (rollTimer.current) clearInterval(rollTimer.current);
    },
    [],
  );

  const [touched, setTouched] = useState(false);

  // ❓ Why refetch right after a mint?
  // → The grid polls every POLL_MS. Asking again at once greys out the cat you just minted without that wait.
  const handleMinted = useCallback(() => {
    setJustMinted(selected);
    refetch();
  }, [selected, refetch]);

  const choose = (i: number) => {
    setTouched(true);
    setJustMinted(null);
    setSelected(i);
  };

  // ❓ Why is the cat on screen not always `selected`?
  // → Before you pick anything, cat 0 is selected by default. If someone already minted it, show the first free cat instead.
  //   Once you click a cat (touched) or have just minted one, your choice is kept even though it is now taken.
  const effective =
    touched || selected === justMinted || !taken[selected] || available.length === 0
      ? selected
      : available[0]!;

  const contractLink = isConfigured ? explorerAddress(contract) : null;

  return (
    <main className="min-w-0 flex-1 overflow-x-clip">
      <section className="mx-auto w-full max-w-7xl px-5 pt-16 pb-10 md:px-6 md:pt-24">
        <h1 className="display text-4xl text-fg md:text-6xl">Mint a cat</h1>
        <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted md:text-base">
          This app is set to {CHAIN_LABEL}. It reads how many cats are minted straight from the
          contract, and your wallet signs the mint transaction.
        </p>
        {isConfigured && (
          <p className="mt-4 text-[13px] text-muted">
            Contract{" "}
            {contractLink ? (
              <a className="underline hover:text-fg" href={contractLink} target="_blank" rel="noreferrer">
                <Mono>{contract}</Mono>
              </a>
            ) : (
              <Mono className="text-fg">{contract}</Mono>
            )}
          </p>
        )}
      </section>

      <WalletBar />

      {/* pb-28 on phones leaves room for MintPanel's fixed bottom bar */}
      <section className="mx-auto w-full max-w-7xl px-5 pt-12 pb-28 sm:pb-16 md:px-6 md:pt-16">
        {!isConfigured ? (
          <div className="max-w-2xl border border-line bg-surface-solid p-6">
            <h2 className="heading text-xl text-fg">No contract address yet</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              Run <Mono className="text-fg">npm run deploy:anvil</Mono> to deploy AvaxCats. It writes the address to{" "}
              <Mono className="text-fg">.env.local</Mono> as <Mono className="text-fg">NEXT_PUBLIC_CONTRACT_ADDRESS</Mono>. Then restart{" "}
              <Mono className="text-fg">npm run dev</Mono>. The README has the steps.
            </p>
          </div>
        ) : (
          <>
            <div className="mb-8 flex flex-wrap items-end justify-between gap-x-8 gap-y-4">
              <div className="min-w-0">
                <h2 className="display text-3xl text-fg md:text-5xl">Pick your cat</h2>
                <p className="mt-4 max-w-2xl text-sm leading-relaxed text-muted md:text-base">
                  Image and traits go straight into the tokenURI, with no IPFS. Each cat can be
                  minted once. That rule lives in the contract, not in this page.
                </p>
              </div>
              <p className="font-mono text-sm text-muted">
                <span className="text-2xl tabular-nums tracking-tight text-fg">{mintedCount}</span>{" "}
                / {CATS.length} minted
              </p>
            </div>

            <CatGrid selected={effective} onSelect={choose} taken={taken} rolling={rolling} />
            <MintPanel
              cat={CATS[effective]!}
              catId={effective}
              taken={taken[effective] ?? false}
              onRandom={pickRandom}
              onMinted={handleMinted}
              onMintStart={() => setJustMinted(selected)}
            />
          </>
        )}
      </section>
    </main>
  );
}
