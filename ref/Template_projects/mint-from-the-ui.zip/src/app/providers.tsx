"use client";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import { WagmiProvider } from "wagmi";
import { config } from "@/lib/wagmi";

export function Providers({ children }: { children: React.ReactNode }) {
  // ❓ Why create the QueryClient inside useState?
  // → So each render session has exactly one client (the cache of on-chain data) and it is not recreated on every re-render.
  const [queryClient] = useState(() => new QueryClient());
  return (
    // ❓ What do these two providers do?
    // → WagmiProvider hands the config (chains, connectors) down to every wagmi hook.
    //   QueryClientProvider is TanStack Query: caching, refetching and loading state for every read from the chain.
    <WagmiProvider config={config}>
      <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
    </WagmiProvider>
  );
}
