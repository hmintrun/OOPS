import { defineChain } from "viem";
import { avalancheFuji } from "wagmi/chains";

export const LOCAL_RPC_URL =
  process.env.NEXT_PUBLIC_RPC_URL || "http://127.0.0.1:8545";

// ❓ Why define the anvil chain ourselves?
// → viem ships avalancheFuji, but anvil is a local chain on your machine (id 31337, RPC 127.0.0.1)
//   so we have to declare the chainId, gas token and RPC URL by hand.
export const anvil = defineChain({
  id: 31337,
  name: "Anvil (local)",
  nativeCurrency: { name: "Avalanche", symbol: "AVAX", decimals: 18 },
  rpcUrls: { default: { http: [LOCAL_RPC_URL] } },
  testnet: true,
});

export const CHAINS = { anvil, fuji: avalancheFuji } as const;
export type ChainKey = keyof typeof CHAINS;

// ❓ What is the benefit of choosing the network with an environment variable?
// → The same code runs anvil for learning and Fuji for the demo. Change NEXT_PUBLIC_CHAIN in .env.local and you are done,
//   and no component hardcodes a network name.
export const CHAIN_KEY: ChainKey =
  (process.env.NEXT_PUBLIC_CHAIN || "anvil").toLowerCase() === "fuji"
    ? "fuji"
    : "anvil";

export const activeChain = CHAINS[CHAIN_KEY];
export const isLocal = CHAIN_KEY === "anvil";

export const CHAIN_LABEL = isLocal
  ? `Anvil local (${anvil.id})`
  : `Fuji Testnet (${avalancheFuji.id})`;

// ❓ What is POLL_MS?
// → How often the frontend asks the chain again (mintedBitmap, totalMinted). Anvil mines blocks instantly so we ask every 4s;
//   Fuji produces a block about every 2s, and 12s is enough and saves public RPC.
export const POLL_MS = isLocal ? 4_000 : 12_000;

export const EXPLORER = isLocal ? "" : "https://testnet.snowtrace.io";
export const FAUCET = "https://build.avax.network/console/primary-network/faucet";

export { avalancheFuji };
