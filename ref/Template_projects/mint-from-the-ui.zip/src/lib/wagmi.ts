import { createConfig, http } from "wagmi";
import { injected, mock, walletConnect } from "wagmi/connectors";
import { anvil, avalancheFuji, isLocal, LOCAL_RPC_URL } from "./chains";

export const ANVIL_ACCOUNT =
  "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266" as const;

export const WC_PROJECT_ID = (process.env.NEXT_PUBLIC_WC_PROJECT_ID ?? "").trim();
export const hasWalletConnect = WC_PROJECT_ID.length > 0;

const SITE_URL =
  typeof window !== "undefined" ? window.location.origin : "https://team1vn.xyz";

// ❓ What is a connector?
// → How the app talks to a wallet. injected = a wallet installed in the browser (Core, MetaMask);
//   walletConnect = a wallet on a phone (Core mobile); mock = a "dev wallet" used only with anvil.
const connectors = [
  injected(),
  ...(hasWalletConnect
    ? [
        walletConnect({
          projectId: WC_PROJECT_ID,
          showQrModal: true,
          metadata: {
            name: "AvaxCats Mint by Team1 VN",
            description: "Mint an AvaxCat NFT on Avalanche Fuji. Team Avalanche, Team1 VN",
            url: SITE_URL,
            icons: [`${SITE_URL}/icon.svg`],
          },
        }),
      ]
    : []),
  // ❓ Why is mock only added when isLocal?
  // → Anvil signs on behalf of its 10 default accounts (eth_sendTransaction needs no wallet).
  //   A real network never signs for anyone, so on Fuji this connector is meaningless and is dropped.
  ...(isLocal
    ? [mock({ accounts: [ANVIL_ACCOUNT], features: { reconnect: true } })]
    : []),
];

// ❓ What does it mean that createConfig is "a single source of truth"?
// → Every wagmi hook (useAccount, useReadContract, useWriteContract...) takes its chain list,
//   connectors and transports from this object. Change it here and the whole app follows.
export const config = createConfig({
  chains: [anvil, avalancheFuji],
  connectors,
  // ❓ What do transports do?
  // → For each chain, just how to send JSON-RPC: anvil through a local URL, Fuji through viem's default RPC.
  //   Reads (views) go through the transport; signing transactions goes through the connector (the wallet).
  transports: {
    [anvil.id]: http(LOCAL_RPC_URL),
    [avalancheFuji.id]: http(),
  },
  ssr: true, // Next.js renders on the server first → avoids hydration mismatches
});

export { activeChain, anvil, avalancheFuji, isLocal } from "./chains";
