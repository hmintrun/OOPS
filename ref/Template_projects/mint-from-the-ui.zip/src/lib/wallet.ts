"use client";

import { useEffect, useState, useSyncExternalStore } from "react";
import { useConnectors } from "wagmi";

const noop = () => () => {};

// ❓ How does this "mounted" hook work?
// → useSyncExternalStore with an empty (noop) subscribe: during SSR getServerSnapshot → false, in the browser getSnapshot → true.
//   Result: the hydrate render sees false and later true, with no useEffect + setState and no hydration mismatch.
export function useMounted() {
  return useSyncExternalStore(noop, () => true, () => false);
}

// ❓ How do we detect mobile?
// → Two signals: the userAgent contains Android/iPhone/iPad/iPod, OR the pointer is "coarse" (a touch screen) and the screen is narrower than
//   1024px (catching an iPad pretending to be a desktop in its userAgent). Guard with `typeof navigator` because this function is also called during SSR.
function detectMobile() {
  if (typeof navigator === "undefined") return false;
  return (
    /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) ||
    (matchMedia("(pointer: coarse)").matches && window.innerWidth < 1024)
  );
}

// ❓ Why not call detectMobile() directly in the component?
// → The server has no navigator → it must return false during SSR (the 3rd argument), and only then does the browser recompute. Calling it directly would make the
//   server and client HTML differ → a hydration error.
export function useIsMobile() {
  return useSyncExternalStore(noop, detectMobile, () => false);
}

type EthWindow = { ethereum?: unknown };

export function useHasInjected() {
  const connectors = useConnectors();
  const mounted = useMounted();
  // ❓ What is the useState "bump" for when its value is never used?
  // → A trick to force a re-render: each time a wallet "appears" we call bump(n + 1) → React re-renders and reads window.ethereum
  //   one more time.
  const [, bump] = useState(0);

  // ❓ Why listen for events instead of reading window.ethereum once?
  // → Wallet extensions inject window.ethereum asynchronously, possibly after React has rendered. MetaMask emits
  //   "ethereum#initialized", modern wallets emit "eip6963:announceProvider" (EIP-6963: several wallets coexist without fighting over
  //   window.ethereum). The setTimeout of 1500ms is a safety net for wallets that emit no event; cleanup removes the listener on unmount.
  useEffect(() => {
    const on = () => bump((n) => n + 1);
    window.addEventListener("ethereum#initialized", on);
    window.addEventListener("eip6963:announceProvider", on);
    const t = setTimeout(on, 1500);
    return () => {
      window.removeEventListener("ethereum#initialized", on);
      window.removeEventListener("eip6963:announceProvider", on);
      clearTimeout(t);
    };
  }, []);

  // ❓ Why return false when not yet mounted?
  // → The server has no window (reading window.ethereum would crash with "window is not defined"), and the hydrate render must
  //   produce the same result as the server.
  if (!mounted) return false;
  // ❓ How do the two ways of detecting a wallet differ?
  // → injectedFound: the old way, where a wallet overwrites window.ethereum. discovered: the new way, where wagmi listens to EIP-6963 and creates a separate connector
  //   for each wallet (id ≠ "injected"). We OR them to support both old and new wallets; if both are false → do not show "Connect wallet".
  const injectedFound = !!(window as unknown as EthWindow).ethereum;
  const discovered = connectors.some(
    (c) => c.type === "injected" && c.id !== "injected",
  );
  return injectedFound || discovered;
}

export function currentUrl() {
  return typeof window === "undefined" ? "https://team1vn.xyz" : window.location.href;
}

// ❓ How does the MetaMask deep link work?
// → https://metamask.app.link/dapp/<host+path> opens the MetaMask app on the phone and loads this page in the wallet's built-in browser,
//   where window.ethereum is available. Guard window so SSR does not crash; the fallback is the production domain.
export function metamaskDeepLink() {
  if (typeof window === "undefined") return "https://metamask.app.link/dapp/team1vn.xyz";
  const { host, pathname, search } = window.location;
  return `https://metamask.app.link/dapp/${host}${pathname}${search}`;
}
