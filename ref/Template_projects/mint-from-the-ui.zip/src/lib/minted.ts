"use client";

import { useMemo } from "react";
import { useReadContract } from "wagmi";
import { activeChain, POLL_MS } from "./chains";
import { CATS } from "./cats";
import { AVAXCATS_ABI } from "./contract";
import { useContractAddress } from "./deployed";

export function useMintedCats() {
  const { address, isConfigured } = useContractAddress();
  const { data: bitmap, refetch } = useReadContract({
    abi: AVAXCATS_ABI,
    address,
    chainId: activeChain.id,
    // ❓ Why call just one mintedBitmap function?
    // → One RPC call returns 48 bits of state instead of 48 catMinted calls. refetchInterval lets the grid update by itself when others mint.
    functionName: "mintedBitmap",

    query: { enabled: isConfigured, refetchInterval: POLL_MS },
  });

  return useMemo(() => {
    const bits = bitmap ?? 0n;
    // ❓ How does this line decode the bitmap?
    // → Shift right by i bits then AND with 1: if a 1 remains, cat i is minted. BigInt is required because uint256 exceeds JavaScript's Number.
    const taken = CATS.map((_, i) => ((bits >> BigInt(i)) & 1n) === 1n);
    const available = taken.reduce<number[]>((acc, t, i) => (t ? acc : [...acc, i]), []);
    return { taken, available, mintedCount: taken.filter(Boolean).length, refetch };
  }, [bitmap, refetch]);
}
