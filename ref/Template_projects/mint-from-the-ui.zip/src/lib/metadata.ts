import type { Cat } from "./cats";
import { CHAIN_LABEL } from "./chains";

// ❓ What does a standard ERC-721 tokenURI need?
// → A URL that returns JSON with name, description, image, attributes (the OpenSea standard).
//   Here we use no http/IPFS URL and put the JSON straight into a data URI.
export function buildTokenURI(cat: Cat): string {
  const meta = {
    name: `${cat.name} - Team1 VN`,
    description:
      "AvaxCats - pixel summit cat of Team Avalanche (Team1 VN). " +
      `Minted on ${CHAIN_LABEL} for the academy demo.`,
    image: cat.image,
    attributes: cat.attributes,
  };

  // ❓ Why base64 and not the raw JSON?
  // → A data URI needs a safe string (no brackets, no odd unicode); btoa encodes the JSON as base64.
  //   cat.image inside is itself data:image/png;base64, so the NFT is fully self-contained and depends on no server.
  return "data:application/json;base64," + btoa(JSON.stringify(meta));
}

export type TokenMeta = {
  name: string;
  image: string;
  attributes: { trait_type: string; value: string }[];
};

// ❓ Where is parseTokenURI used?
// → To read a tokenURI back from the chain and decode it for display. That way the image on screen
//   comes from on-chain data, not from the cats.ts file in the repo.
export function parseTokenURI(uri: string): TokenMeta | null {
  const prefix = "data:application/json;base64,";
  if (!uri?.startsWith(prefix)) return null;
  try {
    const m = JSON.parse(atob(uri.slice(prefix.length)));

    if (typeof m?.name !== "string" || typeof m?.image !== "string") return null;
    return {
      name: m.name,
      image: m.image,
      attributes: Array.isArray(m.attributes) ? m.attributes : [],
    };
  } catch {
    return null;
  }
}
