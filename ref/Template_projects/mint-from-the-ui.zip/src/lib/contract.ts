import { EXPLORER, isLocal } from "./chains";

// ❓ What is an ABI and why is it hand-written here?
// → The ABI describes function names, parameters and return types so viem can encode/decode call data. We only declare the functions
//   the frontend uses (mint, mintedBitmap, ownerOf, tokenURI...) to keep it short; the other ERC-721 functions need not be listed.
export const AVAXCATS_ABI = [
  {
    type: "function",
    name: "mint",
    stateMutability: "nonpayable",
    inputs: [
      { name: "catId", type: "uint256" },
      { name: "uri", type: "string" },
    ],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "mintedBitmap",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "catMinted",
    stateMutability: "view",
    inputs: [{ name: "catId", type: "uint256" }],
    outputs: [{ name: "", type: "bool" }],
  },
  {
    type: "function",
    name: "COLLECTION_SIZE",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "totalMinted",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "MAX_SUPPLY",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint256" }],
  },

  {
    type: "function",
    name: "ownerOf",
    stateMutability: "view",
    inputs: [{ name: "tokenId", type: "uint256" }],
    outputs: [{ name: "", type: "address" }],
  },
  {
    type: "function",
    name: "tokenURI",
    stateMutability: "view",
    inputs: [{ name: "tokenId", type: "uint256" }],
    outputs: [{ name: "", type: "string" }],
  },
  {
    type: "function",
    name: "balanceOf",
    stateMutability: "view",
    inputs: [{ name: "owner", type: "address" }],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "event",
    name: "Minted",
    inputs: [
      { name: "to", type: "address", indexed: true },
      { name: "tokenId", type: "uint256", indexed: true },
      { name: "catId", type: "uint256", indexed: true },
    ],
  },
// ❓ What does "as const" at the end of the ABI array do?
// → It keeps the literal types so TypeScript can infer that functionName can only be "mint" | "ownerOf"...,
//   args have the right types (bigint, string) and results have the right types. Drop "as const" and all type safety is lost.
] as const;

export const explorerTx = (hash: string) =>
  EXPLORER ? `${EXPLORER}/tx/${hash}` : null;
export const explorerNft = (address: string, tokenId: bigint | string) =>
  EXPLORER ? `${EXPLORER}/nft/${address}/${tokenId}` : null;

// ❓ Why do the explorer helpers return null on anvil?
// → Anvil is a local chain with no block explorer. A component that receives null shows the raw hash instead of a link.
export const explorerAddress = (address: string) =>
  EXPLORER ? `${EXPLORER}/address/${address}` : null;

export { EXPLORER, isLocal };
