"use client";

import { useSyncExternalStore } from "react";
import { activeChain } from "./chains";

// ❓ Why does the localStorage key include the chainId?
// → A contract deployed on anvil and one deployed on Fuji have two different addresses; splitting by chainId means switching network never uses the wrong one.
const KEY = `avaxcats:contract:${activeChain.id}`;
const ENV_ADDRESS = (process.env.NEXT_PUBLIC_CONTRACT_ADDRESS ?? "").trim();

const listeners = new Set<() => void>();
let snapshot: string | undefined;

// ❓ What is the priority order for the contract address?
// → localStorage (a contract you deployed yourself on the web) first, then NEXT_PUBLIC_CONTRACT_ADDRESS in .env.local
//   (a shared contract set by the instructor). try/catch because localStorage can be blocked (private mode).
function read(): string {
  try {
    return localStorage.getItem(KEY) ?? ENV_ADDRESS;
  } catch {
    return ENV_ADDRESS;
  }
}

function getSnapshot(): string {
  if (snapshot === undefined) snapshot = read();
  return snapshot;
}

function getServerSnapshot(): string {
  return ENV_ADDRESS;
}

function emit() {
  for (const l of listeners) l();
}

function subscribe(onChange: () => void) {
  listeners.add(onChange);
  const onStorage = (e: StorageEvent) => {
    if (e.key === KEY) {
      snapshot = undefined;
      onChange();
    }
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(onChange);
    window.removeEventListener("storage", onStorage);
  };
}

export function setDeployedAddress(address: string) {
  try {
    localStorage.setItem(KEY, address);
  } catch {}
  snapshot = address;
  emit();
}

export function clearDeployedAddress() {
  try {
    localStorage.removeItem(KEY);
  } catch {}
  snapshot = ENV_ADDRESS;
  emit();
}

export const isAddress = (v: string) => /^0x[a-fA-F0-9]{40}$/.test(v);

// ❓ Why useSyncExternalStore instead of useState?
// → localStorage lives outside React. This hook lets React subscribe to it and read a snapshot that is
//   consistent between server and client, avoiding a hydration error when the page is rendered statically.
export function useContractAddress() {
  const address = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  return {
    address: address as `0x${string}`,
    isConfigured: isAddress(address),
    fromEnv: address !== "" && address === ENV_ADDRESS,
  };
}
