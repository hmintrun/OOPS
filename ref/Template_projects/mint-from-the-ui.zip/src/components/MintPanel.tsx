"use client";

import { useEffect, useMemo, useState } from "react";
import { parseEventLogs } from "viem";
import {
  useAccount,
  useWaitForTransactionReceipt,
  useWriteContract,
} from "wagmi";
import type { Cat } from "@/lib/cats";
import { activeChain, isLocal } from "@/lib/chains";
import { AVAXCATS_ABI, explorerNft, explorerTx } from "@/lib/contract";
import { useContractAddress } from "@/lib/deployed";
import { buildTokenURI } from "@/lib/metadata";
import { Button, Icon, Mono, Pillar, Status } from "./ui";

// ❓ Why "translate" errors instead of showing error.message?
// → viem's error.message is very long (with the request body and docs links). We merge shortMessage (a one-line summary) with message and
//   look for a few familiar patterns to return a short, readable sentence; if none matches, cut it to 180 characters.
function explainError(error: Error): string {
  const raw = `${(error as { shortMessage?: string }).shortMessage ?? ""} ${error.message}`;

  if (/insufficient funds/i.test(raw)) {
    return isLocal
      ? "wallet has no AVAX on anvil. Use the dev wallet, or run `npm run fund <wallet address>`."
      : "wallet doesn't have enough test AVAX for gas. Top up at the faucet and try again.";
  }
  // ❓ Where does "CatAlreadyMinted" come from?
  // → It is the name of a custom error in the contract (`revert CatAlreadyMinted(catId)`). When estimating gas or sending a tx the node returns
  //   the revert data and the error name appears in the message → matched with a regex. It happens when two people pick the same cat and the other
  //   one mints first; the UI only learns after POLL_MS so we still have to guard against it here.
  if (/CatAlreadyMinted/i.test(raw))
    return "someone just minted this one. Pick another cat.";
  if (/CatDoesNotExist/i.test(raw)) return "invalid catId.";
  // ❓ Is rejecting in the wallet an on-chain error?
  // → No. The wallet returns error 4001 (User rejected) before anything is sent to the network, and no gas is spent. It is caught separately so we do not scare the user.
  if (/User rejected|denied transaction/i.test(raw))
    return "you rejected the transaction in your wallet.";

  const short = (error as { shortMessage?: string }).shortMessage ?? error.message;
  return short.length > 180 ? short.slice(0, 180) + "…" : short;
}

function Attrs({ cat, className = "" }: { cat: Cat; className?: string }) {
  return (
    <dl className={`grid gap-x-4 gap-y-2 ${className}`}>
      {cat.attributes.map((a) => (
        <div key={a.trait_type} className="min-w-0">
          <dt className="eyebrow text-steel/70">{a.trait_type}</dt>
          <dd className="truncate text-[13px] text-white/90">{a.value}</dd>
        </div>
      ))}
    </dl>
  );
}

type Props = {
  cat: Cat;
  catId: number;
  taken: boolean;
  onRandom: () => void;
  onMinted: () => void;
  onMintStart: () => void;
};

export function MintPanel({
  cat,
  catId,
  taken,
  onRandom,
  onMinted,
  onMintStart,
}: Props) {
  const { isConnected, chainId } = useAccount();
  const { address: contract, isConfigured } = useContractAddress();
  // ❓ How is useWriteContract different from useReadContract?
  // → Read = eth_call, free. Write = a transaction that changes state → it must be signed by the wallet and pay gas. writeContract() opens the wallet;
  //   data (the hash) is available as soon as the wallet sends; isPending = waiting for the signature; error = the wallet refused or it reverted during gas estimation;
  //   reset() clears everything so you can mint another cat.
  const { writeContract, data: hash, isPending, error, reset } = useWriteContract();
  // ❓ Why still wait for the receipt after getting the hash?
  // → The hash only means the tx was sent. The receipt arrives when the tx is in a block: it has the status "success"/"reverted" and the logs
  //   (containing the Minted event → tokenId). Without waiting for the receipt you do not know whether the mint succeeded.
  const { data: receipt, isLoading: confirming } = useWaitForTransactionReceipt({
    hash,
    chainId: activeChain.id,
  });

  const [pendingName, setPendingName] = useState<string | null>(null);

  // ❓ Why reset when the cat changes?
  // → hash/receipt/error belong to the PREVIOUS mint. If not cleared, picking a new cat would still show "Minted · token #N" or the old error,
  //   and the Mint button would be stuck busy. wagmi's reset() has a stable reference, so putting it in deps does not cause pointless re-runs.
  useEffect(() => {
    reset();
  }, [cat, reset]);

  // ❓ How do we get the tokenId of the NFT that was just minted?
  // → The mint() function has `return tokenId` but the return value of a transaction is NOT stored on-chain. The only way is to
  //   read the Minted(to, tokenId, catId) event in receipt.logs: parseEventLogs uses the ABI to filter the right topic and decode the args.
  //   useMemo avoids re-parsing on every render; logs[0] because each mint tx emits exactly one Minted event.
  const tokenId = useMemo(() => {
    if (!receipt) return undefined;
    const logs = parseEventLogs({
      abi: AVAXCATS_ABI,
      logs: receipt.logs,
      eventName: "Minted",
    });
    return logs[0]?.args.tokenId;
  }, [receipt]);

  // ❓ What is onMinted called for?
  // → It tells the page to refetch mintedBitmap immediately (instead of waiting for POLL_MS) so the cat just minted is greyed out in CatGrid right away.
  //   It is in a useEffect because calling the parent's callback (which has setState) during render is an anti-pattern and React will warn.
  useEffect(() => {
    if (receipt) onMinted();
  }, [receipt, onMinted]);

  const wrongChain = isConnected && chainId !== activeChain.id;
  const busy = isPending || confirming;
  // ❓ Does having a receipt mean success?
  // → Not necessarily: the tx was mined but may have reverted (status "reverted") and still cost gas. Only status === "success"
  //   counts as minted and shows the NFT link.
  const success = receipt?.status === "success";
  // ❓ When is the Mint button allowed to be pressed?
  // → All 5 conditions: a contract address exists, the wallet is connected, it is the right network, this cat is not yet minted (taken = false) and no
  //   tx is running. Missing one means the tx would fail (revert or wallet refusal) → block it from the UI so no gas is wasted.
  const readyToMint = isConfigured && isConnected && !wrongChain && !taken && !busy;

  function mint() {
    // ❓ Why store the cat name in separate state?
    // → If the user presses Random while waiting for the receipt, the `cat` prop changes but the success message must still show the
    //   cat that was just minted.
    setPendingName(cat.name);
    onMintStart();
    // ❓ What are mint's args?
    // → They match the Solidity signature `mint(uint256 catId, string uri)`: catId must be a BigInt (uint256), uri is a tokenURI in the form
    //   data:application/json;base64 holding name/image/attributes, so the metadata lives fully on-chain and no IPFS is needed.
    //   chainId forces wagmi to send on the right network; a wallet on another network is refused instead of minting on the wrong chain.
    writeContract({
      abi: AVAXCATS_ABI,
      address: contract,
      functionName: "mint",
      args: [BigInt(catId), buildTokenURI(cat)],
      chainId: activeChain.id,
    });
  }

  const txLink = hash ? explorerTx(hash) : null;
  const nftLink = tokenId !== undefined ? explorerNft(contract, tokenId) : null;
  const shortHash = hash ? `${hash.slice(0, 10)}…${hash.slice(-8)}` : "";

  const barStatus = busy
    ? { text: isLocal ? "Sending transaction…" : "Confirm in your wallet…", cls: "text-muted" }
    : success && tokenId !== undefined
      ? { text: `Minted · token #${tokenId.toString()}`, cls: "text-emerald-400" }
      : error
        ? { text: "Mint failed. See details below", cls: "text-avax" }
        : taken
          ? { text: "Already minted. Pick another cat", cls: "text-amber-400" }
          : !isConnected
            ? { text: "Connect a wallet to mint", cls: "text-amber-400" }
            : wrongChain
              ? { text: "Wrong network. Switch first", cls: "text-amber-400" }
              : { text: `${cat.attributes.length} traits · ready to mint`, cls: "text-muted" };

  return (
    <>
      <div className="pb-safe fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface backdrop-blur-sm sm:hidden">
        <div className="flex items-center gap-3 px-4 py-2.5">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            className="px size-11 shrink-0 border border-line bg-surface-solid"
            src={cat.image}
            alt=""
          />
          <div className="min-w-0 flex-1">
            <div className="truncate text-[13px] font-medium text-fg">{cat.name}</div>
            <div className={`truncate text-[11px] ${barStatus.cls}`}>{barStatus.text}</div>
          </div>
          <Button
            variant="primary"
            onClick={mint}
            disabled={!readyToMint}
            className={busy ? "anim-sweep" : ""}
          >
            {busy ? "Minting…" : taken ? "Minted" : "Mint"}
          </Button>
        </div>
      </div>

      <Pillar className="mt-6">
        <div className="flex flex-col gap-6 p-5 md:flex-row md:items-start md:gap-8 md:p-7">
          <div className="flex items-center justify-between md:w-8 md:flex-col md:items-start md:justify-start md:gap-4">
            <span className="font-mono text-[11px] tracking-[0.18em] text-steel">02</span>
            <span className="eyebrow text-steel/80 md:hidden">Selected cat</span>
            <span className="hidden rotate-180 font-mono text-[10px] tracking-[0.18em] text-steel/80 [writing-mode:vertical-rl] md:block">
              SELECTED CAT
            </span>
          </div>

          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            key={cat.name}
            className="px anim-settle size-36 shrink-0 self-start rounded-lg border border-white/10 bg-black/30 md:size-44"
            src={cat.image}
            alt={cat.name}
          />

          <div className="min-w-0 flex-1">
            <h3 className="text-2xl font-light tracking-[-0.02em] md:text-3xl">{cat.name}</h3>
            <Attrs cat={cat} className="mt-4 hidden grid-cols-2 sm:grid sm:grid-cols-3 sm:gap-x-6" />
            <details className="group mt-4 sm:hidden">
              <summary className="eyebrow flex cursor-pointer list-none items-center gap-2 py-1 text-steel">
                {cat.attributes.length} traits
                <Icon name="arrow" className="size-3 transition-transform group-open:rotate-90" />
              </summary>
              <Attrs cat={cat} className="mt-3 grid-cols-2" />
            </details>

            <div className="mt-5 space-y-1.5">
              {isPending && (
                <Status tone="busy" dark>
                  {isLocal ? "Sending transaction" : "Confirm the transaction in your wallet"}
                </Status>
              )}
              {hash && confirming && (
                <Status tone="busy" dark>
                  Waiting for confirmation{" "}
                  {txLink ? (
                    <a className="underline hover:text-white" href={txLink} target="_blank" rel="noreferrer">
                      view tx
                    </a>
                  ) : (
                    <Mono className="text-steel">{shortHash}</Mono>
                  )}
                </Status>
              )}
              {success && tokenId !== undefined && (
                <Status tone="ok" dark>
                  {pendingName ?? cat.name} is token #{tokenId.toString()}
                  {txLink && nftLink ? (
                    <>
                      {" · "}
                      <a className="underline hover:text-white" href={txLink} target="_blank" rel="noreferrer">
                        tx
                      </a>
                      {" · "}
                      <a className="underline hover:text-white" href={nftLink} target="_blank" rel="noreferrer">
                        NFT
                      </a>
                    </>
                  ) : (
                    <>
                      {" · "}
                      <Mono className="text-steel">{shortHash}</Mono>
                    </>
                  )}
                </Status>
              )}
              {error && (
                <Status tone="err" dark>
                  Mint failed: {explainError(error)}
                </Status>
              )}
              {taken && !hash && (
                <Status tone="warn" dark>
                  {cat.name} is already minted, and each cat can be minted once. Pick another.
                </Status>
              )}
              {!isConnected && (
                <Status tone="warn" dark>
                  {isLocal
                    ? "Use the Dev wallet (anvil) button above to mint."
                    : "Connect a wallet to mint."}
                </Status>
              )}
              {wrongChain && (
                <Status tone="warn" dark>
                  Switch to the right network first.
                </Status>
              )}
            </div>
          </div>

          <div className="flex shrink-0 flex-col gap-3 md:w-[220px]">
            <Button
              variant="primary"
              size="lg"
              onClick={mint}
              disabled={!readyToMint}
              className={`sm:min-w-0 ${busy ? "anim-sweep" : ""}`}
            >
              {busy ? "Minting…" : taken ? "Already minted" : "Mint NFT"}
            </Button>
            <Button
              variant="inverse"
              size="lg"
              arrow={false}
              className="justify-center sm:min-w-0"
              onClick={onRandom}
            >
              Random
            </Button>
          </div>
        </div>
      </Pillar>
    </>
  );
}
