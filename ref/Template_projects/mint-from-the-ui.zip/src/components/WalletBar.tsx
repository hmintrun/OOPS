"use client";

import { useSyncExternalStore } from "react";
import { formatEther } from "viem";
import {
  useAccount,
  useBalance,
  useDisconnect,
  useSwitchChain,
} from "wagmi";
import { activeChain, CHAIN_LABEL, FAUCET, isLocal } from "@/lib/chains";
import { ConnectButtons, MobileConnectHelp } from "./ConnectButtons";
import { SupplyBadge } from "./SupplyBadge";
import { Button, Icon, PulseDot, Stat } from "./ui";

export function WalletBar() {
  // ❓ Why do we need to know whether the component has "mounted", and why not use useState + useEffect?
  // → Next.js renders this page on the server first (SSR); there is no wallet then, so isConnected is always false. This hook returns
  //   false during SSR (the 3rd argument) and true in the browser, so the server and client HTML match → no
  //   hydration mismatch when the wallet reconnects on its own right as the page loads.
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );

  // ❓ What does useAccount tell us?
  // → wagmi's hook reading the current wallet state: address, isConnected and chainId (the network the WALLET has selected, not necessarily
  //   the network the dApp wants). Every cell in this status bar is derived from those three values.
  const { address, isConnected, chainId } = useAccount();
  // ❓ Does "Disconnect" really disconnect from the wallet?
  // → No. disconnect() only clears the connection on the dApp side (wagmi forgets the connector and address). The access already granted in
  //   MetaMask/Core stays; to revoke it fully the user has to do it in the wallet.
  const { disconnect } = useDisconnect();
  // ❓ What does switchChain do, and what is isPending for?
  // → switchChain sends a wallet_switchEthereumChain request to the wallet; the wallet shows a popup asking the user to agree (and offers to add the
  //   network if it is missing). isPending = true while waiting for the user to press → used to disable the button and show "Switching…".
  const { switchChain, isPending: switching } = useSwitchChain();
  // ❓ Why pass chainId: activeChain.id instead of letting wagmi use the wallet's chain?
  // → We want the balance on the dApp's own network (anvil/Fuji) even when the wallet is on another one. Without chainId, a wallet sitting on
  //   Ethereum mainnet would show ETH in the Balance cell instead of test AVAX: the user thinks there is enough money and minting still fails.
  const { data: balance } = useBalance({ address, chainId: activeChain.id });

  // ❓ How do we know the user is on the wrong network?
  // → Compare the wallet's chainId with the chainId the dApp is configured for (activeChain). It only counts as "wrong" once CONNECTED, because before
  //   connecting chainId is undefined and always different. This is the condition that turns on the "Switch network" button below.
  const wrongChain = isConnected && chainId !== activeChain.id;
  // ❓ Why compare with 0n and not 0?
  // → balance.value is a bigint (wei, 18 decimal places) so you must use the bigint literal 0n; `=== 0` is always false.
  //   An empty wallet → show the faucet banner below so the user can ask for test AVAX before deploying/minting.
  const empty = balance?.value === 0n;
  // ❓ Why not use isConnected directly?
  // → On the SSR render and the first hydrate render, mounted = false so online = false even though the wallet is connected. That way the server and
  //   client render the same HTML; after hydration React re-renders and only then shows the real address and balance.
  const online = mounted && isConnected;

  return (
    <section className="border-y border-line" aria-label="Wallet status">
      <div className="mx-auto grid w-full max-w-7xl grid-cols-2 gap-px bg-line lg:grid-cols-[1.2fr_1fr_1fr_1fr_auto]">
        <Stat
          label="Network"
          wrap
          dot={
            <PulseDot
              color={!online ? "bg-zinc-400" : wrongChain ? "bg-amber-500" : "bg-avax"}
              ping={online && !wrongChain}
            />
          }
          valueClassName={
            wrongChain ? "text-amber-400 text-[13px] md:text-base" : "text-[13px] md:text-base"
          }
          value={
            !mounted
              ? "…"
              : wrongChain
                ? `Wrong network: need ${CHAIN_LABEL}`
                : online
                  ? "Connected"
                  : "Not connected"
          }
        />
        <Stat
          label="Wallet"
          value={
            online && address ? (
              `${address.slice(0, 6)}…${address.slice(-4)}`
            ) : (
              <span className="text-muted">Not connected</span>
            )
          }
        />
        <Stat
          label="Balance"
          value={
            online && balance ? (
              <>
                {Number(formatEther(balance.value)).toFixed(3)}
                <span className="text-muted"> AVAX</span>
              </>
            ) : (
              <span className="text-muted">-</span>
            )
          }
        />
        <SupplyBadge />

        <div className="col-span-2 flex flex-wrap items-center gap-2 bg-surface-solid px-5 py-4 md:px-6 lg:col-span-1 lg:justify-end">
          {!mounted ? null : wrongChain ? (
            <Button
              variant="primary"
              disabled={switching}
              onClick={() => switchChain({ chainId: activeChain.id })}
            >
              {switching ? "Switching…" : "Switch network"}
            </Button>
          ) : isConnected ? (
            <Button variant="ghost" onClick={() => disconnect()}>
              Disconnect
            </Button>
          ) : (
            <ConnectButtons />
          )}
        </div>
      </div>

      {mounted && !isConnected && <MobileConnectHelp />}

      {online && empty && (
        <div className="border-t border-line bg-amber-500/10">
          <div className="mx-auto flex w-full max-w-7xl items-center gap-2 px-5 py-2.5 text-[12.5px] text-amber-400 md:px-6">
            <Icon name="alert" />
            {isLocal ? (
              <span>
                This wallet has no AVAX on anvil. Use <b>Dev wallet (anvil)</b>, or run{" "}
                <code className="border border-amber-500/30 px-1.5 py-0.5 font-mono text-[12px] break-all">
                  npm run fund {address}
                </code>
              </span>
            ) : (
              <a
                className="inline-flex items-center gap-1.5 hover:underline"
                href={FAUCET}
                target="_blank"
                rel="noreferrer"
              >
                No test AVAX yet. Get some from the faucet
                <Icon name="external" />
              </a>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
