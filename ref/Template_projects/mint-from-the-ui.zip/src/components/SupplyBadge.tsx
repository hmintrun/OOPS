"use client";

import { useReadContract } from "wagmi";
import { activeChain, POLL_MS } from "@/lib/chains";
import { AVAXCATS_ABI } from "@/lib/contract";
import { useContractAddress } from "@/lib/deployed";
import { PulseDot, Stat } from "./ui";

export function SupplyBadge({ className = "" }: { className?: string }) {
  // ❓ Where does the contract address come from?
  // → From localStorage (after you deploy in step 1) or from the env NEXT_PUBLIC_CONTRACT_ADDRESS (see lib/deployed.ts).
  //   isConfigured = true when that string is a valid 0x… address; with no address every query below must be switched off.
  const { address, isConfigured } = useContractAddress();
  const common = { abi: AVAXCATS_ABI, address, chainId: activeChain.id } as const;

  // ❓ How does useReadContract work? Does it cost gas?
  // → It calls the view function `totalMinted` over RPC (eth_call): read-only, creates no transaction, costs no gas and needs no wallet.
  //   query.enabled blocks the call when there is no address (avoiding an "address undefined" error); refetchInterval: POLL_MS re-reads
  //   every few seconds so the "Minted" number updates when others mint.
  const { data: minted, error } = useReadContract({
    ...common,
    functionName: "totalMinted",
    query: { enabled: isConfigured, refetchInterval: POLL_MS },
  });
  // ❓ Why does MAX_SUPPLY not need refetchInterval?
  // → It is a `constant` in the contract, written straight into the bytecode and never changes → reading once is enough and saves RPC.
  const { data: max } = useReadContract({
    ...common,
    functionName: "MAX_SUPPLY",
    query: { enabled: isConfigured },
  });

  // ❓ What does "live" mean?
  // → There is an address, the RPC call did not error and the first data has arrived (minted !== undefined). Used to turn on the blinking
  //   green dot; if there is an error (wrong address, wrong network, dead RPC) the dot turns yellow and shows "Can't read contract".
  const live = isConfigured && !error && minted !== undefined;

  return (
    <Stat
      className={className}
      label="Minted"
      dot={
        <PulseDot
          color={!isConfigured ? "bg-zinc-400" : error ? "bg-amber-500" : "bg-emerald-500"}
          ping={live}
        />
      }
      valueClassName={error ? "text-amber-400 text-sm md:text-sm" : ""}
      value={
        !isConfigured ? (
          <span className="text-muted">-</span>
        ) : error ? (
          "Can't read contract"
        ) : minted === undefined || max === undefined ? (
          <span className="text-muted">…</span>
        ) : (
          <>
            {minted.toString()}
            <span className="text-muted"> / {max.toString()}</span>
          </>
        )
      }
    />
  );
}
