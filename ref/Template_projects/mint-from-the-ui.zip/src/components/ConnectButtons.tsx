"use client";

import { useState } from "react";
import { useConnect } from "wagmi";
import { currentUrl, metamaskDeepLink, useHasInjected, useIsMobile } from "@/lib/wallet";
import { Button, Icon } from "./ui";

type Size = "md" | "lg";

export function useWalletOptions() {
  // ❓ What are connectors and where do they come from?
  // → The list of wallet connection methods declared in lib/wagmi.ts (injected, walletConnect, mock). connect({ connector })
  //   opens the matching wallet; isPending = true while waiting for the user to press "Connect" in the wallet → disable every button so two popups do not open.
  // ❓ How is connectAsync different from connect?
  // → connect() fires and forgets; connectAsync() returns a Promise with the account list. The "Get test AVAX" button needs the latter:
  //   once connected you have the address straight away to call the faucet, without waiting for useAccount to update on the next render.
  const { connect, connectAsync, connectors, isPending } = useConnect();
  // ❓ What is the "mock" connector?
  // → A fake wallet provided by wagmi that uses anvil account #0 (holding 10,000 AVAX), so no MetaMask is needed for local dev.
  //   It is only added when isLocal (see lib/wagmi.ts); on Fuji find() returns undefined, so the "Dev wallet" button does not show.
  const devWallet = connectors.find((c) => c.id === "mock");
  const wc = connectors.find((c) => c.id === "walletConnect");
  // ❓ Why look first for a connector of type "injected" whose id is NOT "injected"?
  // → Wallets installed in the browser (Core, MetaMask…) "announce" themselves through EIP-6963 and wagmi creates a separate connector for each
  //   (an id like "app.core.extension"). We prefer that connector to open the right wallet; fall back to the generic "injected" connector
  //   (reading window.ethereum) for old wallets that do not support EIP-6963.
  const injected =
    connectors.find((c) => c.type === "injected" && c.id !== "injected") ??
    connectors.find((c) => c.id === "injected");
  // ❓ There is already an injected connector, so why do we still need useHasInjected?
  // → wagmi ALWAYS creates an "injected" connector, even when the browser has no wallet installed. useHasInjected checks reality
  //   (window.ethereum or an EIP-6963 event) to decide whether the "Connect wallet" button should be shown.
  const hasInjected = useHasInjected();
  const mobile = useIsMobile();
  // ❓ When is pickConnector used?
  // → When another place only needs "just connect, any wallet will do" instead of showing every button (the faucet button, for example).
  //   The priority order is identical to ConnectButtons below: the dev wallet on anvil → a wallet installed in the browser → WalletConnect.
  const pickConnector = () =>
    devWallet ?? (hasInjected ? injected : undefined) ?? wc;

  return {
    connect,
    connectAsync,
    isPending,
    devWallet,
    wc,
    injected,
    hasInjected,
    mobile,
    pickConnector,
  };
}

export function ConnectButtons({ size = "md" }: { size?: Size }) {
  const { connect, isPending, devWallet, wc, injected, hasInjected, mobile } =
    useWalletOptions();

  // ❓ Which button is the primary one?
  // → If a wallet is installed in the browser → "Connect wallet" (injected) is primary; otherwise WalletConnect or the Dev wallet
  //   takes its place. It needs both: a real wallet is detected AND wagmi has a matching connector; missing either one and pressing does nothing.
  const primaryIsInjected = hasInjected && !!injected;

  return (
    <>
      {devWallet && (
        <Button
          variant={primaryIsInjected || wc ? "outline" : "primary"}
          size={size}
          arrow={size === "lg" && !primaryIsInjected && !wc}
          disabled={isPending}
          onClick={() => connect({ connector: devWallet })}
        >
          Dev wallet (anvil)
        </Button>
      )}
      {primaryIsInjected && (
        <Button
          variant="primary"
          size={size}
          disabled={isPending}
          onClick={() => connect({ connector: injected! })}
        >
          {isPending ? "Connecting…" : "Connect wallet"}
        </Button>
      )}
      {wc && (
        <Button
          variant={primaryIsInjected ? "secondary" : "primary"}
          size={size}
          disabled={isPending}
          onClick={() => connect({ connector: wc })}
        >
          {mobile ? "Core / MetaMask" : "Scan QR with Core mobile"}
        </Button>
      )}
      {!primaryIsInjected && !wc && !devWallet && !mobile && (
        <a
          className="inline-flex h-10 items-center gap-1.5 border border-line-strong px-4 text-[13px] font-semibold text-fg transition-colors hover:bg-hover"
          href="https://core.app"
          target="_blank"
          rel="noreferrer"
        >
          Install Core Wallet
          <Icon name="external" />
        </a>
      )}
    </>
  );
}

export function MobileConnectHelp() {
  const { hasInjected, mobile, wc } = useWalletOptions();
  const [copied, setCopied] = useState(false);

  // ❓ When is the "Mint on your phone" guide shown?
  // → Only on mobile and when there is NO injected wallet, that is, when opened in ordinary Safari/Chrome. If the page is running inside
  //   the Core/MetaMask app's browser, window.ethereum already exists → connect like on desktop, no guide needed.
  if (!mobile || hasInjected) return null;

  async function copy() {
    try {
      // ❓ Why copy the link instead of opening the Core app directly?
      // → Pasting the link into the Browser tab of the Core app runs the page inside the wallet → window.ethereum is available. clipboard.writeText
      //   only works on HTTPS and after a user action, so it is wrapped in try/catch so nothing crashes if it is blocked.
      await navigator.clipboard.writeText(currentUrl());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  }

  return (
    <div className="border-t border-line bg-surface-solid">
      <div className="mx-auto w-full max-w-7xl px-5 py-4 md:px-6">
        <p className="eyebrow mb-3 text-muted">Mint on your phone</p>
        <ol className="space-y-3 text-[13px] leading-relaxed text-fg">
          {wc && (
            <li className="flex gap-3">
              <span className="font-mono text-[11px] tracking-[0.18em] text-avax">01</span>
              <span>
                Tap <b>Core / MetaMask</b> above and pick your wallet. The wallet app opens
                so you can approve the connection (WalletConnect).
              </span>
            </li>
          )}
          <li className="flex gap-3">
            <span className="font-mono text-[11px] tracking-[0.18em] text-avax">
              {wc ? "02" : "01"}
            </span>
            <span className="min-w-0">
              {wc ? "Or open" : "Open"} this page <b>inside the Core app</b>: Core →{" "}
              <b>Browser</b> tab → paste the link into the address bar.{" "}
              <button
                type="button"
                onClick={copy}
                className="inline-flex cursor-pointer items-center gap-1 border border-line-strong px-2 py-0.5 font-mono text-[11px] tracking-wide text-fg transition-colors hover:bg-hover"
              >
                {copied ? "Copied" : "Copy link"}
              </button>
            </span>
          </li>
          <li className="flex gap-3">
            <span className="font-mono text-[11px] tracking-[0.18em] text-avax">
              {wc ? "03" : "02"}
            </span>
            <span>
              Using MetaMask?{" "}
              <a
                className="inline-flex items-center gap-1 underline hover:text-avax"
                href={metamaskDeepLink()}
                rel="noreferrer"
              >
                Open in MetaMask <Icon name="external" className="size-3" />
              </a>
            </span>
          </li>
        </ol>
      </div>
    </div>
  );
}
