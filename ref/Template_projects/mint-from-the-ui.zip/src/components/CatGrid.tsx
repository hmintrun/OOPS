"use client";

import { CATS } from "@/lib/cats";
import { Icon } from "./ui";

type Props = {
  selected: number;
  onSelect: (i: number) => void;
  // ❓ Why take taken from props instead of reading the contract here?
  // → CatGrid is pure UI. Reading mintedBitmap lives in the page (useMintedCats in lib/minted.ts) so CatGrid, MintPanel
  //   and SupplyBadge share one source, instead of each component making its own RPC calls.
  taken: boolean[];
  rolling?: boolean;
};

export function CatGrid({ selected, onSelect, taken, rolling }: Props) {
  return (
    <div className="grid grid-cols-[repeat(auto-fill,minmax(72px,1fr))] gap-px border border-line bg-surface-solid">
      {CATS.map((cat, i) => {
        // ❓ Why use the index i as the catId instead of an id in the data?
        // → The contract numbers cats in the exact order of CATS (0..47) and the bitmap follows that index too; selected/onSelect/taken
        //   all share this index, so it must stay consistent: reorder CATS and you mint the wrong cat.
        const on = i === selected;
        // ❓ How do we know this cat is "already minted"?
        // → taken is a boolean[] that useMintedCats builds from mintedBitmap: bit i of the uint256 = 1 means catId i is minted.
        //   `?? false` covers the moment before the bitmap has loaded (taken is empty) → every cat counts as free instead of undefined.
        const gone = taken[i] ?? false;
        return (
          <button
            key={cat.name}
            type="button"
            title={gone ? `${cat.name} (already minted)` : cat.name}
            aria-pressed={on}
            onClick={() => onSelect(i)}
            className={`relative cursor-pointer p-1.5 transition-colors duration-150 ${
              on
                ? "z-10 bg-surface-solid outline-2 outline-avax"
                : gone
                  ? "bg-surface-solid outline-1 outline-line"
                  : "bg-surface-solid outline-1 outline-line hover:bg-hover"
            }`}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              className={`px w-full transition-opacity duration-150 ${
                gone ? "opacity-25 grayscale" : rolling ? "opacity-90" : ""
              }`}
              src={cat.image}
              alt={cat.name}
            />
            {gone && (
              <span className="pointer-events-none absolute inset-0 grid place-items-center text-muted">
                <Icon name="lock" />
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
