# Vibe coding 2: Whale watch

One `index.html`, written by Claude Code from three prompts. Nobody edited it by hand. It lists the latest swaps on Avalanche, shows swaps over $1,000 big and red with a sound, and when you click a whale it finds the wallet behind it and says whether that wallet is up or down.

No wallet and no money are involved. The replay above is the real session from 10 October 2026: 8½ minutes of AI time, about $3.56.

## Run it
Press **Open the app** above, or download `index.html` and open it in a browser. There is nothing to install.

## Build it yourself
1. Install Claude Code and make an empty folder.
2. In that folder, run the command below once. It lets the AI read the getchord API docs instead of guessing.
3. Run `claude` and type the three prompts, one at a time. Open `index.html` after each.

```bash
claude mcp add --transport http chord-docs https://getchord.xyz/docs/mcp
```

Prompt 1 took 2m41s in our run:
```
make a simple web page (one html file) that shows the latest swaps on
Avalanche from the getchord API. newest on top, refresh every 10 seconds
```

Prompt 2 took 3m06s:
```
swaps over $1,000 are whales. make them big and red, and play a sound
when one lands
```

Prompt 3 took 2m44s:
```
when I click a whale, show the wallet behind it and if it made money
this week
```

The AI writes different code every time, so your page will not match this one line for line.

## Watch out
- Keep the wording of prompt 1. Our first try asked for "a live feed of every swap": it ran for 31 minutes and built a terminal app. "Simple web page", "one html file" and "latest swaps" are what keep it to three minutes.
- The feed keeps only the 3 newest swaps per token. Busy tokens like WAVAX lose most of their whales between refreshes (1 caught out of 5 when the AI measured it).
- Browsers block sound until you click the page. That is why the page has a "Turn on whale sound" button.
- "This week" is not exactly 7 days. getchord picks the window for each wallet (8 and 18 days in our run) and the panel says which.
- Some swaps come back with no wallet because they went through a router. Click another whale.
- Without a key, getchord allows 60 requests a minute per IP, and a class on one wifi shares one IP. Get a free key at getchord.xyz/developer, and never publish a page with your key inside it.

## Make it yours
Move the $1,000 line, watch a single token, or keep a list of the wallets you clicked.
