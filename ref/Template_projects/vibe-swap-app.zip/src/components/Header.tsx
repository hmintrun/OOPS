import { useEffect, useRef, useState } from 'react'
import { formatEther } from 'viem'
import type { CoreWallet } from '../hooks/useCoreWallet'
import { CORE_DOWNLOAD_URL, EXPLORER_URL } from '../lib/core'
import { formatAmount, shortAddress } from '../lib/format'

export function Header({ wallet }: { wallet: CoreWallet }) {
  const wrongNetwork = wallet.address != null && wallet.chainId != null && !wallet.onAvalanche

  return (
    <header className="header">
      <div className="brand">
        <span className="brand-mark" aria-hidden />
        Snowline
      </div>
      <nav className="nav">
        <a className="nav-link active" href="/" aria-current="page">
          Swap
        </a>
        <span className="nav-link" aria-disabled title="Coming soon">
          Tokens
        </span>
        <span className="nav-link" aria-disabled title="Coming soon">
          Portfolio
        </span>
      </nav>
      <div className="header-right">
        {wrongNetwork ? (
          <button className="network-pill warn" onClick={wallet.switchNetwork}>
            <span className="dot" />
            Switch to Avalanche
          </button>
        ) : (
          <div className="network-pill">
            <span className="dot" />
            Avalanche C-Chain
          </div>
        )}
        <WalletButton wallet={wallet} />
      </div>
    </header>
  )
}

function WalletButton({ wallet }: { wallet: CoreWallet }) {
  if (wallet.provider === null) {
    return (
      <a className="btn btn-primary" href={CORE_DOWNLOAD_URL} target="_blank" rel="noreferrer">
        Install Core
      </a>
    )
  }
  if (!wallet.address) {
    return (
      <button className="btn btn-primary" onClick={wallet.connect} disabled={!wallet.provider || wallet.connecting}>
        {wallet.connecting ? 'Connecting…' : 'Connect Core'}
      </button>
    )
  }
  return <AccountMenu wallet={wallet} address={wallet.address} />
}

function AccountMenu({ wallet, address }: { wallet: CoreWallet; address: string }) {
  const [open, setOpen] = useState(false)
  const [copied, setCopied] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!open) return
    const onPointer = (e: PointerEvent) => !ref.current?.contains(e.target as Node) && setOpen(false)
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    document.addEventListener('pointerdown', onPointer)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('pointerdown', onPointer)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  const copy = async () => {
    await navigator.clipboard.writeText(address)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  return (
    <div className="account" ref={ref}>
      <button className="account-pill" onClick={() => setOpen((o) => !o)} aria-expanded={open} title={address}>
        <span className="account-balance">
          {wallet.balance == null ? '…' : formatAmount(Number(formatEther(wallet.balance)))} AVAX
        </span>
        <span className="account-address">{shortAddress(address)}</span>
      </button>
      {open && (
        <div className="account-menu" role="menu">
          <div className="account-menu-label">Connected with Core</div>
          <div className="account-menu-address">{address}</div>
          <button role="menuitem" onClick={copy}>
            {copied ? 'Copied' : 'Copy address'}
          </button>
          <a role="menuitem" href={`${EXPLORER_URL}/address/${address}`} target="_blank" rel="noreferrer">
            View on Snowtrace
          </a>
          <button
            role="menuitem"
            className="danger"
            onClick={() => {
              setOpen(false)
              wallet.disconnect()
            }}
          >
            Disconnect
          </button>
        </div>
      )}
    </div>
  )
}
