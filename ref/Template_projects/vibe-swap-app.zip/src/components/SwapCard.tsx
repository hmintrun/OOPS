import { useMemo, useState } from 'react'
import { formatEther, formatUnits, parseEther } from 'viem'
import { useDebounced } from '../hooks/useDebounced'
import { usePolled } from '../hooks/usePolled'
import type { CoreWallet } from '../hooks/useCoreWallet'
import { useSwap, type SwapStatus } from '../hooks/useSwap'
import { getQuote, providerName, USDC_DECIMALS, venueName } from '../lib/chord'
import { CORE_DOWNLOAD_URL, EXPLORER_URL } from '../lib/core'
import { formatAmount, formatUsd } from '../lib/format'

const SLIPPAGE_BPS = 50
const QUOTE_REFRESH_MS = 20_000 // quotes expire after 30 s
const TYPING_DEBOUNCE_MS = 300
const SHOW_IMPACT_FROM_PCT = 1
const HIGH_IMPACT_PCT = 3

export function SwapCard({ wallet }: { wallet: CoreWallet }) {
  const [amount, setAmount] = useState('0.1')

  const amountWei = useMemo(() => {
    try {
      const wei = parseEther(amount)
      return wei > 0n ? wei : null
    } catch {
      return null
    }
  }, [amount])
  const quotedWei = useDebounced(amountWei, TYPING_DEBOUNCE_MS)

  const quote = usePolled(
    (signal) => (quotedWei ? getQuote(quotedWei, SLIPPAGE_BPS, signal) : Promise.resolve(null)),
    [quotedWei],
    QUOTE_REFRESH_MS,
  )
  const { status, swap, clearError } = useSwap(wallet, SLIPPAGE_BPS, quote.reload)

  // The aggregator echoes amountIn, so we know exactly which input a quote answers.
  const q = quote.data
  const isCurrent = q != null && amountWei != null && q.amountIn === amountWei.toString()
  // While the next quote loads, keep the previous one on screen (dimmed); drop it on error.
  const shown = amountWei != null && q != null && (isCurrent || !quote.error) ? q : null
  const loading = amountWei != null && !isCurrent && !quote.error
  const noRoute = shown != null && shown.provider == null
  const routed = shown != null && shown.provider != null ? shown : null

  const out = routed ? Number(formatUnits(BigInt(routed.amountOut), USDC_DECIMALS)) : null
  const minOut = routed ? Number(formatUnits(BigInt(routed.minAmountOut), USDC_DECIMALS)) : null
  // Dust outputs are rounded to USDC's 6 decimals, which makes a rate from them meaningless.
  const rate = routed && out != null && out >= 0.01 ? out / Number(formatEther(BigInt(routed.amountIn))) : null
  const impact = routed?.priceImpactPct != null ? Number(routed.priceImpactPct) : null
  const venues = routed?.route?.venues.map(venueName).join(' + ')
  const route = routed?.provider ? [venues, `via ${providerName(routed.provider)}`].filter(Boolean).join(' ') : null

  const insufficient = wallet.balance != null && amountWei != null && amountWei > wallet.balance
  // Only swap what's on screen: a routed quote for exactly the amount typed.
  const swapReady = routed != null && isCurrent

  return (
    <section className="card swap-card">
      <div className="well">
        <div className="well-row">
          <span className="label">You pay</span>
          <span className="label">
            Balance {wallet.balance == null ? '—' : formatAmount(Number(formatEther(wallet.balance)))}
          </span>
        </div>
        <div className="well-row">
          <input
            className="amount-input"
            value={amount}
            onChange={(e) => {
              const next = e.target.value.replace(',', '.')
              if (!/^\d*\.?\d{0,18}$/.test(next)) return
              setAmount(next)
              clearError()
            }}
            disabled={status.step === 'building' || status.step === 'signing'}
            inputMode="decimal"
            placeholder="0"
            aria-label="Amount of AVAX to pay"
          />
          <span className="token-pill">AVAX</span>
        </div>
      </div>

      <div className="swap-arrow" aria-hidden>
        ↓
      </div>

      <div className="well">
        <div className="well-row">
          <span className="label">You receive</span>
          <span className="label" aria-live="polite">
            {loading ? 'Quoting…' : noRoute ? 'No route' : out != null ? (out < 0.01 ? '< $0.01' : `≈ ${formatUsd(out)}`) : ''}
          </span>
        </div>
        <div className="well-row">
          {loading && out == null ? (
            <span className="skeleton amount-skeleton" />
          ) : (
            <span className={`amount ${loading ? 'stale' : ''}`} aria-live="polite">
              {out != null ? formatUsdc(out) : amountWei == null ? '0' : '—'}
            </span>
          )}
          <span className="token-pill">USDC</span>
        </div>
      </div>

      <dl className={`details ${loading ? 'stale' : ''}`}>
        <div>
          <dt>Rate</dt>
          <dd>{rate != null ? `1 AVAX = ${rate.toFixed(2)} USDC` : '—'}</dd>
        </div>
        <div>
          <dt>Route</dt>
          <dd title={routed?.fallbackReason ? `getchord router: ${routed.fallbackReason}` : undefined}>
            {noRoute ? 'No route for this amount' : (route ?? '—')}
          </dd>
        </div>
        {impact != null && impact >= SHOW_IMPACT_FROM_PCT && (
          <div>
            <dt>Price impact</dt>
            <dd className={impact >= HIGH_IMPACT_PCT ? 'down' : ''}>{impact.toFixed(2)}%</dd>
          </div>
        )}
        <div>
          <dt>Min. received</dt>
          <dd>{minOut != null ? `${formatUsdc(minOut)} USDC` : '—'}</dd>
        </div>
      </dl>
      {quote.error && <p className="quote-error">Quote unavailable: {quote.error}</p>}

      <SwapAction
        wallet={wallet}
        hasAmount={amountWei != null}
        insufficient={insufficient}
        ready={swapReady}
        status={status}
        onSwap={() => amountWei != null && routed != null && isCurrent && swap(amountWei, routed)}
      />
      <SwapStatusLine status={status} />
    </section>
  )
}

/** Four decimals like the design; up to USDC's six for dust so it never reads 0.0000. */
function formatUsdc(value: number) {
  return value.toLocaleString('en-US', {
    minimumFractionDigits: 4,
    maximumFractionDigits: value > 0 && value < 0.01 ? 6 : 4,
  })
}

type SwapActionProps = {
  wallet: CoreWallet
  hasAmount: boolean
  insufficient: boolean
  ready: boolean
  status: SwapStatus
  onSwap: () => void
}

function SwapAction({ wallet, hasAmount, insufficient, ready, status, onSwap }: SwapActionProps) {
  if (wallet.provider === null) {
    return (
      <a className="btn btn-primary btn-swap" href={CORE_DOWNLOAD_URL} target="_blank" rel="noreferrer">
        Install Core
      </a>
    )
  }
  if (!wallet.address) {
    return (
      <button className="btn btn-primary btn-swap" onClick={wallet.connect} disabled={!wallet.provider || wallet.connecting}>
        {wallet.connecting ? 'Connecting…' : 'Connect Core'}
      </button>
    )
  }
  const busyLabel = { building: 'Building transaction…', signing: 'Confirm in Core…', pending: 'Swapping…' } as const
  if (status.step in busyLabel) {
    return (
      <button className="btn btn-primary btn-swap" disabled>
        {busyLabel[status.step as keyof typeof busyLabel]}
      </button>
    )
  }
  if (!wallet.onAvalanche) {
    return (
      <button className="btn btn-primary btn-swap" onClick={wallet.switchNetwork}>
        Switch to Avalanche
      </button>
    )
  }
  if (!hasAmount || insufficient) {
    return (
      <button className="btn btn-primary btn-swap" disabled>
        {insufficient ? 'Insufficient AVAX' : 'Enter an amount'}
      </button>
    )
  }
  return (
    <button className="btn btn-primary btn-swap" onClick={onSwap} disabled={!ready}>
      Swap
    </button>
  )
}

function SwapStatusLine({ status }: { status: SwapStatus }) {
  switch (status.step) {
    case 'idle':
      return null
    case 'building':
      return <p className="swap-status">Asking getchord to build your transaction…</p>
    case 'signing':
      return <p className="swap-status">Review and sign the swap in Core.</p>
    case 'error':
      return (
        <p className="swap-status error" role="alert">
          {status.message}
        </p>
      )
  }
  const text = {
    pending: 'Submitted. Waiting for confirmation…',
    confirmed:
      status.step === 'confirmed' && status.receivedUsdc != null
        ? `Swap confirmed. Received ${formatUsdc(status.receivedUsdc)} USDC.`
        : 'Swap confirmed.',
    reverted: 'The swap failed on-chain (reverted).',
    unconfirmed: 'Submitted, but not confirmed yet.',
  }[status.step]
  const tone = status.step === 'confirmed' ? 'ok' : status.step === 'reverted' ? 'error' : ''
  return (
    <p className={`swap-status ${tone}`} role="status">
      {text}{' '}
      <a href={`${EXPLORER_URL}/tx/${status.hash}`} target="_blank" rel="noreferrer">
        View on Snowtrace ↗
      </a>
    </p>
  )
}
