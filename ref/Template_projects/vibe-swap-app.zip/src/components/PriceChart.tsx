import { usePolled } from '../hooks/usePolled'
import { getToken, WAVAX } from '../lib/chord'
import { formatPct, formatUsd, tone } from '../lib/format'

const W = 1000
const H = 200

export function PriceChart() {
  const { data, error } = usePolled((signal) => getToken(WAVAX, 24, signal), [], 60_000)

  const prices = (data?.series ?? []).map((p) => p.priceLast).filter((p): p is number => p != null)
  const change = data?.stats24h.change24hPct ?? null

  return (
    <section className="card chart-card">
      <div className="chart-head">
        <div className="token-title">
          <strong>{data?.token.symbol ?? 'WAVAX'}</strong>
          <span>{data?.token.name ?? 'Wrapped AVAX'}</span>
        </div>
        <span className="range-pill">24h</span>
      </div>

      <div className="price-row">
        {data ? (
          <>
            <span className="price">{formatUsd(data.stats24h.priceUsd)}</span>
            <span className={`change ${tone(change)}`}>{formatPct(change)}</span>
          </>
        ) : (
          <span className="skeleton" style={{ width: 180, height: 44 }} />
        )}
      </div>

      <div className="chart">
        {prices.length > 1 ? (
          <Sparkline values={prices} />
        ) : error ? (
          <p className="muted">Couldn't load the WAVAX chart from getchord: {error}</p>
        ) : (
          <span className="skeleton" style={{ width: '100%', height: '100%' }} />
        )}
      </div>
    </section>
  )
}

function Sparkline({ values }: { values: number[] }) {
  const lo = Math.min(...values)
  const hi = Math.max(...values)
  const pad = (hi - lo) * 0.12 || hi * 0.005
  const x = (i: number) => (i / (values.length - 1)) * W
  const y = (v: number) => H - ((v - (lo - pad)) / (hi - lo + 2 * pad)) * H

  const line = values.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join('')
  const area = `${line}L${W},${H}L0,${H}Z`
  const lastY = (y(values[values.length - 1]) / H) * 100

  return (
    <div className="sparkline">
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" aria-label="WAVAX price, last 24 hours">
        <defs>
          <linearGradient id="spark-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--chart)" stopOpacity="0.45" />
            <stop offset="100%" stopColor="var(--chart)" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={area} fill="url(#spark-fill)" />
        <path d={line} fill="none" stroke="var(--chart)" strokeWidth="2.5" vectorEffect="non-scaling-stroke" strokeLinejoin="round" />
      </svg>
      <span className="spark-dot" style={{ top: `${lastY}%` }} />
    </div>
  )
}
