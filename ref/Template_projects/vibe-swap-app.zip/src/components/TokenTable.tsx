import { usePolled } from '../hooks/usePolled'
import { getBoard } from '../lib/chord'
import { formatCompactUsd, formatPct, formatUsd, tone } from '../lib/format'

const ROWS = 3

export function TokenTable() {
  const { data, error } = usePolled((signal) => getBoard(ROWS, signal), [], 60_000)

  return (
    <section className="card table-card">
      <table className="token-table">
        <thead>
          <tr>
            <th>Token</th>
            <th>Price</th>
            <th>24h</th>
            <th>Volume</th>
          </tr>
        </thead>
        <tbody>
          {data
            ? data.tokens.map((t) => (
                <tr key={t.address} title={t.name ?? undefined}>
                  <td className="symbol">{t.symbol ?? `${t.address.slice(0, 8)}…`}</td>
                  <td>{formatUsd(t.priceUsd)}</td>
                  <td className={tone(t.change24hPct)}>{formatPct(t.change24hPct)}</td>
                  <td className="muted-num">{formatCompactUsd(t.volume24h)}</td>
                </tr>
              ))
            : Array.from({ length: ROWS }, (_, i) => (
                <tr key={i}>
                  <td colSpan={4}>
                    {error && i === 0 ? (
                      <span className="muted">Couldn't load the board from getchord: {error}</span>
                    ) : (
                      <span className="skeleton" style={{ width: '100%', height: 22 }} />
                    )}
                  </td>
                </tr>
              ))}
        </tbody>
      </table>
    </section>
  )
}
