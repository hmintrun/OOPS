import { useEffect } from 'react'
import { Header } from './components/Header'
import { PriceChart } from './components/PriceChart'
import { SwapCard } from './components/SwapCard'
import { TokenTable } from './components/TokenTable'
import { useCoreWallet } from './hooks/useCoreWallet'

export default function App() {
  const wallet = useCoreWallet()
  const { error, clearError } = wallet

  useEffect(() => {
    if (!error) return
    const timer = setTimeout(clearError, 5000)
    return () => clearTimeout(timer)
  }, [error, clearError])

  return (
    <div className="app">
      <Header wallet={wallet} />
      <main className="main">
        <div className="market">
          <PriceChart />
          <TokenTable />
        </div>
        <SwapCard wallet={wallet} />
      </main>
      {error && (
        <div className="toast" role="alert">
          {error}
          <button onClick={clearError} aria-label="Dismiss">
            ×
          </button>
        </div>
      )}
    </div>
  )
}
