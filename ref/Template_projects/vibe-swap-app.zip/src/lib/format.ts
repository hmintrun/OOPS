const MINUS = '−'

export function formatUsd(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return '—'
  const digits = value >= 10_000 ? 0 : value >= 1 ? 2 : 4
  return value.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  })
}

export function formatCompactUsd(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return '—'
  return value.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    notation: 'compact',
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  })
}

export function formatPct(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return '—'
  const sign = value > 0 ? '+' : value < 0 ? MINUS : ''
  return `${sign}${Math.abs(value).toFixed(2)}%`
}

/** CSS class for a signed change: green up, red down. */
export function tone(value: number | null) {
  return value == null || value === 0 ? '' : value > 0 ? 'up' : 'down'
}

export function formatAmount(value: number, maxDigits = 4) {
  return value.toLocaleString('en-US', { maximumFractionDigits: maxDigits })
}

export function shortAddress(address: string) {
  return `${address.slice(0, 6)}…${address.slice(-4)}`
}
