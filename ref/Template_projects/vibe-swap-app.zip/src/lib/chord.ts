import type { Address, Hex } from 'viem'

// Chord's public API. Reads need no key and CORS is open, so the browser calls it directly.
const API = 'https://api.getchord.xyz/v1'
const CHAIN = 'avalanche'

export const NATIVE: Address = '0x0000000000000000000000000000000000000000'
export const WAVAX: Address = '0xb31f66aa3c1e785363f0875a1b74e27b85fd66c7'
export const USDC: Address = '0xb97ef9ef8734c71904d8002f8b6bc66dd9c48a6e'
export const USDC_DECIMALS = 6

export type BoardToken = {
  address: Address
  symbol: string | null
  name: string | null
  priceUsd: number | null
  change24hPct: number | null
  volume24h: number
}

export type TokenDetail = {
  token: { address: Address; symbol: string | null; name: string | null }
  stats24h: { priceUsd: number | null; change24hPct: number | null; volUsd: number }
  series: { hour: number; priceLast: number | null }[]
}

export type MetaQuote = {
  /** `chord` = getchord's own router; otherwise the fallback aggregator that answered; null = no route. */
  provider: string | null
  fallbackReason: string | null
  tokenIn: Address
  tokenOut: Address
  amountIn: string
  amountOut: string
  minAmountOut: string
  priceImpactPct: string | null
  route: { venues: string[] } | null
  warnings: string[]
  expiresAt: number
}

/** `/meta/swap` answer: the quote plus an unsigned transaction simulated as `taker`. */
export type SwapBuild = MetaQuote & {
  taker: Address | null
  tx: { to: Address; data: Hex; value: string; gas: string | null; chainId: number } | null
  approval: { token: Address; spender: Address; amount: string } | null
  simulation: { ok: boolean | null; amountOut?: string; revert?: string; reason?: string } | null
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API}${path}`, init)
  if (!res.ok) {
    const body = await res.json().catch(() => null)
    throw new Error(body?.message ?? body?.error ?? `getchord answered ${res.status}`)
  }
  return res.json() as Promise<T>
}

function get<T>(path: string, signal?: AbortSignal) {
  return request<T>(path, { signal })
}

export function getBoard(limit: number, signal?: AbortSignal) {
  return get<{ tokens: BoardToken[] }>(`/chains/${CHAIN}/tokens?limit=${limit}&sort=volume`, signal)
}

export function getToken(address: Address, hours: number, signal?: AbortSignal) {
  return get<TokenDetail>(`/chains/${CHAIN}/token/${address}?hours=${hours}`, signal)
}

/**
 * Price-only quote (no taker): AVAX → USDC on Avalanche, from getchord's meta
 * aggregator. `/v1/quote` (the bare router) doesn't serve Avalanche; this
 * endpoint asks getchord's router first and falls back to KyberSwap, LI.FI or
 * Relay only when it can't route.
 */
export function getQuote(amountInWei: bigint, slippageBps: number, signal?: AbortSignal) {
  const q = new URLSearchParams({
    chain: CHAIN,
    tokenIn: NATIVE,
    tokenOut: USDC,
    amount: amountInWei.toString(),
    slippageBps: String(slippageBps),
  })
  return get<MetaQuote>(`/meta/quote?${q}`, signal)
}

/**
 * Builds the unsigned AVAX → USDC transaction for `taker`, simulated as that
 * wallet. getchord never signs; the wallet does.
 */
export function buildSwap(amountInWei: bigint, slippageBps: number, taker: Address) {
  return request<SwapBuild>('/meta/swap', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chain: CHAIN,
      tokenIn: NATIVE,
      tokenOut: USDC,
      amount: amountInWei.toString(),
      slippageBps,
      taker,
    }),
  })
}

/**
 * The only contracts a swap may target on Avalanche, per provider: a second,
 * independent check on top of getchord's own allowlist. Pinned from getchord's
 * Agent Skill client (META_ROUTERS in scripts/chord.py), 2026-10-10.
 */
export const AVALANCHE_ROUTERS: Record<string, readonly string[]> = {
  chord: ['0x1b1fee89a381e595fe6536b99ba91f3e16e9601a'],
  kyberswap: ['0x6131b5fae19ea4f9d964eac0408e4408b66337b5'],
  lifi: ['0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae'],
  relay: ['0xccc88a9d1b4ed6b0eaba998850414b24f1c315be', '0xb92fe925dc43a0ecde6c8b1a2709c170ec4fff4f'],
}

const PROVIDER_NAMES: Record<string, string> = {
  chord: 'getchord',
  kyberswap: 'KyberSwap',
  lifi: 'LI.FI',
  relay: 'Relay',
  monorail: 'Monorail',
}

export function providerName(id: string) {
  return PROVIDER_NAMES[id] ?? id
}

const VENUE_NAMES: Record<string, string> = {
  uniswap_v4: 'Uniswap V4',
  uniswap_v3: 'Uniswap V3',
  uniswap_v2: 'Uniswap V2',
  pharaoh_v3: 'Pharaoh V3',
  pharaoh_dlmm: 'Pharaoh DLMM',
  lfj_v2: 'LFJ',
  pangolin: 'Pangolin',
  pangolin_v3: 'Pangolin V3',
  okx: 'OKX',
  '0x': '0x',
  '1inch': '1inch',
}

/** Chord has no published Avalanche venue list; unknown ids are prettified. */
export function venueName(id: string) {
  return (
    VENUE_NAMES[id] ??
    id
      .split('_')
      .map((part) => (/^v\d/.test(part) || part.length <= 4 ? part.toUpperCase() : part[0].toUpperCase() + part.slice(1)))
      .join(' ')
  )
}
