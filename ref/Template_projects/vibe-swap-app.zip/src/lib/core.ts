import { createPublicClient, http, toHex, type Address, type EIP1193Provider, type Hash, type Hex } from 'viem'
import { avalanche } from 'viem/chains'

export const AVALANCHE_CHAIN_ID = avalanche.id // 43114
const AVALANCHE_HEX = `0x${AVALANCHE_CHAIN_ID.toString(16)}` as const
const CORE_RDNS = 'app.core.extension'

export const CORE_DOWNLOAD_URL = 'https://core.app/'
export const EXPLORER_URL = 'https://snowtrace.io'

// Balances are read from Avalanche mainnet directly, so they stay correct
// even while the wallet is pointed at another network.
export const avalancheClient = createPublicClient({ chain: avalanche, transport: http() })

type ProviderDetail = {
  info: { uuid: string; name: string; icon: string; rdns: string }
  provider: EIP1193Provider
}

declare global {
  interface Window {
    avalanche?: EIP1193Provider
    ethereum?: EIP1193Provider & { isAvalanche?: boolean }
  }
  interface WindowEventMap {
    'eip6963:announceProvider': CustomEvent<ProviderDetail>
  }
}

/**
 * Finds the Core extension's provider. Core announces itself over EIP-6963;
 * older builds only inject `window.avalanche`. Resolves null when Core is not
 * installed, never to some other wallet.
 */
export function findCoreProvider(timeoutMs = 400): Promise<EIP1193Provider | null> {
  return new Promise((resolve) => {
    let settled = false
    const settle = (provider: EIP1193Provider | null) => {
      if (settled) return
      settled = true
      window.removeEventListener('eip6963:announceProvider', onAnnounce)
      resolve(provider)
    }
    const onAnnounce = (event: CustomEvent<ProviderDetail>) => {
      const { info, provider } = event.detail
      if (info.rdns === CORE_RDNS || info.name === 'Core') settle(provider)
    }

    window.addEventListener('eip6963:announceProvider', onAnnounce)
    window.dispatchEvent(new Event('eip6963:requestProvider'))
    setTimeout(() => {
      const injected = window.avalanche ?? (window.ethereum?.isAvalanche ? window.ethereum : undefined)
      settle(injected ?? null)
    }, timeoutMs)
  })
}

export async function switchToAvalanche(provider: EIP1193Provider) {
  try {
    await provider.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: AVALANCHE_HEX }] })
  } catch (err) {
    // 4902: the wallet doesn't know the chain yet.
    if (errorCode(err) !== 4902) throw err
    await provider.request({
      method: 'wallet_addEthereumChain',
      params: [
        {
          chainId: AVALANCHE_HEX,
          chainName: 'Avalanche C-Chain',
          nativeCurrency: { name: 'Avalanche', symbol: 'AVAX', decimals: 18 },
          rpcUrls: [avalanche.rpcUrls.default.http[0]],
          blockExplorerUrls: [EXPLORER_URL],
        },
      ],
    })
  }
}

/** Switches Core to Avalanche if needed, and fails unless it really is there afterwards. */
export async function ensureAvalanche(provider: EIP1193Provider) {
  const chainId = async () => Number.parseInt(await provider.request({ method: 'eth_chainId' }), 16)
  if ((await chainId()) === AVALANCHE_CHAIN_ID) return
  await switchToAvalanche(provider)
  if ((await chainId()) !== AVALANCHE_CHAIN_ID) throw new Error('Core is not on Avalanche C-Chain.')
}

/** Opens Core's signing prompt for `tx`; resolves with the hash once Core has submitted it. */
export function sendTransaction(
  provider: EIP1193Provider,
  from: Address,
  tx: { to: Address; data: Hex; value: string; gas: string | null; chainId: number },
): Promise<Hash> {
  return provider.request({
    method: 'eth_sendTransaction',
    params: [
      {
        from,
        to: tx.to,
        data: tx.data,
        value: toHex(BigInt(tx.value)),
        ...(tx.gas ? { gas: toHex(BigInt(tx.gas)) } : {}),
        chainId: toHex(tx.chainId),
      },
    ],
  })
}

export function getAvaxBalance(address: Address) {
  return avalancheClient.getBalance({ address })
}

export function errorCode(err: unknown): number | undefined {
  return typeof err === 'object' && err !== null && 'code' in err ? Number((err as { code: unknown }).code) : undefined
}

export function errorMessage(err: unknown): string {
  if (errorCode(err) === 4001) return 'Request rejected in Core.'
  if (errorCode(err) === -32002) return 'Core already has a pending request. Open the extension to continue.'
  if (err instanceof Error) return err.message
  return 'Something went wrong talking to Core.'
}
