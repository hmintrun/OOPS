import { useCallback, useEffect, useState } from 'react'
import { getAddress, type Address, type EIP1193Provider } from 'viem'
import { AVALANCHE_CHAIN_ID, errorMessage, findCoreProvider, getAvaxBalance, switchToAvalanche } from '../lib/core'

const BALANCE_REFRESH_MS = 15_000
// Set when the user disconnects, so a reload doesn't silently reconnect them.
const DISCONNECTED_KEY = 'snowline:disconnected'

export type CoreWallet = {
  /** undefined while still looking for the extension, null when Core isn't installed. */
  provider: EIP1193Provider | null | undefined
  address: Address | null
  chainId: number | null
  onAvalanche: boolean
  balance: bigint | null
  connecting: boolean
  error: string | null
  connect: () => Promise<void>
  switchNetwork: () => Promise<void>
  disconnect: () => void
  clearError: () => void
  /** Re-reads the AVAX balance now (e.g. after a swap lands). */
  refreshBalance: () => void
}

export function useCoreWallet(): CoreWallet {
  const [provider, setProvider] = useState<EIP1193Provider | null | undefined>(undefined)
  const [address, setAddress] = useState<Address | null>(null)
  const [chainId, setChainId] = useState<number | null>(null)
  const [balance, setBalance] = useState<bigint | null>(null)
  const [connecting, setConnecting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [balanceReads, setBalanceReads] = useState(0)

  // Find Core, restore an existing authorization without prompting, and follow its events.
  useEffect(() => {
    let cancelled = false
    let detach = () => {}

    findCoreProvider().then(async (found) => {
      if (cancelled) return
      setProvider(found)
      if (!found) return

      const onAccounts = (accounts: string[]) => setAddress(accounts[0] ? getAddress(accounts[0]) : null)
      const onChain = (hex: string) => setChainId(Number.parseInt(hex, 16))
      found.on('accountsChanged', onAccounts)
      found.on('chainChanged', onChain)
      detach = () => {
        found.removeListener('accountsChanged', onAccounts)
        found.removeListener('chainChanged', onChain)
      }

      try {
        onChain(await found.request({ method: 'eth_chainId' }))
        if (localStorage.getItem(DISCONNECTED_KEY)) return
        const accounts = await found.request({ method: 'eth_accounts' })
        if (!cancelled) onAccounts(accounts)
      } catch {
        // A locked or busy wallet just stays disconnected until the user clicks Connect.
      }
    })

    return () => {
      cancelled = true
      detach()
    }
  }, [])

  // Poll the AVAX balance while an account is connected.
  useEffect(() => {
    if (!address) {
      setBalance(null)
      return
    }
    let cancelled = false
    const load = () =>
      getAvaxBalance(address)
        .then((wei) => !cancelled && setBalance(wei))
        .catch(() => {}) // keep the last known balance on a transient RPC failure
    load()
    const timer = setInterval(load, BALANCE_REFRESH_MS)
    return () => {
      cancelled = true
      clearInterval(timer)
    }
  }, [address, balanceReads])

  const switchNetwork = useCallback(async () => {
    if (!provider) return
    setError(null)
    try {
      await switchToAvalanche(provider)
    } catch (err) {
      setError(errorMessage(err))
    }
  }, [provider])

  const connect = useCallback(async () => {
    if (!provider) return
    setConnecting(true)
    setError(null)
    try {
      const accounts = await provider.request({ method: 'eth_requestAccounts' })
      localStorage.removeItem(DISCONNECTED_KEY)
      setAddress(accounts[0] ? getAddress(accounts[0]) : null)
      const current = Number.parseInt(await provider.request({ method: 'eth_chainId' }), 16)
      setChainId(current)
      if (current !== AVALANCHE_CHAIN_ID) await switchToAvalanche(provider)
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setConnecting(false)
    }
  }, [provider])

  const disconnect = useCallback(() => {
    localStorage.setItem(DISCONNECTED_KEY, '1')
    setAddress(null)
    // Not every Core build supports revoking; the local flag is what matters.
    provider
      ?.request({ method: 'wallet_revokePermissions', params: [{ eth_accounts: {} }] })
      .catch(() => {})
  }, [provider])

  const clearError = useCallback(() => setError(null), [])
  const refreshBalance = useCallback(() => setBalanceReads((n) => n + 1), [])

  return {
    provider,
    address,
    chainId,
    onAvalanche: chainId === AVALANCHE_CHAIN_ID,
    balance,
    connecting,
    error,
    connect,
    switchNetwork,
    disconnect,
    clearError,
    refreshBalance,
  }
}
