import { useCallback, useEffect, useState, type DependencyList } from 'react'

/**
 * Runs `load` now and every `intervalMs`, aborting stale requests. The last
 * good value is kept through refreshes, transient errors and `deps` changes
 * (stale-while-revalidate), so callers that care must check what it answers.
 */
export function usePolled<T>(load: (signal: AbortSignal) => Promise<T>, deps: DependencyList, intervalMs: number) {
  const [data, setData] = useState<T | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [reloads, setReloads] = useState(0)

  useEffect(() => {
    setError(null)
    let controller = new AbortController()
    const run = () => {
      controller.abort()
      controller = new AbortController()
      const { signal } = controller
      load(signal)
        .then((value) => {
          if (signal.aborted) return
          setData(value)
          setError(null)
        })
        .catch((err: unknown) => {
          if (signal.aborted) return
          setError(err instanceof Error ? err.message : String(err))
        })
    }
    run()
    const timer = setInterval(run, intervalMs)
    return () => {
      clearInterval(timer)
      controller.abort()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, reloads])

  const reload = useCallback(() => setReloads((n) => n + 1), [])
  return { data, error, reload }
}
