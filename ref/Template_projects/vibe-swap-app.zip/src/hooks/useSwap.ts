import { useCallback, useState } from 'react'
import { erc20Abi, formatUnits, parseEventLogs, type Address, type Hash } from 'viem'
import type { CoreWallet } from './useCoreWallet'
import {
  AVALANCHE_ROUTERS,
  buildSwap,
  NATIVE,
  providerName,
  USDC,
  USDC_DECIMALS,
  type MetaQuote,
  type SwapBuild,
} from '../lib/chord'
import { AVALANCHE_CHAIN_ID, avalancheClient, ensureAvalanche, errorCode, errorMessage, sendTransaction } from '../lib/core'
import { formatAmount } from '../lib/format'

const RECEIPT_TIMEOUT_MS = 120_000

export type SwapStatus =
  | { step: 'idle' }
  | { step: 'building' }
  | { step: 'signing' }
  | { step: 'pending'; hash: Hash }
  | { step: 'confirmed'; hash: Hash; receivedUsdc: number | null }
  | { step: 'reverted'; hash: Hash }
  | { step: 'unconfirmed'; hash: Hash }
  | { step: 'error'; message: string }

/**
 * Why a built swap must not be signed, or null if it passed every check.
 * getchord runs its own allowlist and simulation; this is the app's
 * independent check before anything reaches Core.
 */
export function findSwapProblem(build: SwapBuild, expected: { amountWei: bigint; taker: Address }): string | null {
  const { tx, provider } = build
  if (!provider || !tx) return 'getchord found no route for this amount.'
  if (!(AVALANCHE_ROUTERS[provider] ?? []).includes(tx.to.toLowerCase()))
    return `Refused: the transaction targets ${tx.to}, which isn't a known ${providerName(provider)} router on Avalanche.`
  if (tx.chainId !== AVALANCHE_CHAIN_ID) return `Refused: the transaction is for chain ${tx.chainId}, not Avalanche.`
  if (BigInt(tx.value) !== expected.amountWei) return 'Refused: the transaction would send a different AVAX amount than you entered.'
  if (build.taker?.toLowerCase() !== expected.taker.toLowerCase()) return 'Refused: the transaction was built for a different wallet.'
  if (build.tokenIn.toLowerCase() !== NATIVE || build.tokenOut.toLowerCase() !== USDC)
    return 'Refused: the transaction swaps different tokens than AVAX → USDC.'
  if (build.approval) return 'Refused: an AVAX swap should never ask for a token approval.'
  if (build.simulation?.ok === false)
    return `getchord's simulation of this swap failed${build.simulation.revert ? `: ${build.simulation.revert}` : ''}.`
  if (build.simulation?.ok !== true && provider !== 'chord') return 'Refused: a third-party route without a passing simulation.'
  if (build.warnings.some((w) => w.startsWith('INSUFFICIENT_BALANCE'))) return 'Not enough AVAX in this wallet for this swap.'
  if (BigInt(build.minAmountOut) <= 0n) return 'Refused: the transaction has no minimum output.'
  return null
}

/**
 * Press Swap → getchord builds the transaction for the connected wallet → the
 * app checks it → Core asks the user to sign → we wait for the receipt.
 */
export function useSwap(wallet: CoreWallet, slippageBps: number, onPriceMoved: () => void) {
  const [status, setStatus] = useState<SwapStatus>({ step: 'idle' })
  const { provider, address, refreshBalance } = wallet

  const swap = useCallback(
    async (amountWei: bigint, shownQuote: MetaQuote) => {
      if (!provider || !address) return

      setStatus({ step: 'building' })
      let build: SwapBuild
      try {
        build = await buildSwap(amountWei, slippageBps, address)
      } catch (err) {
        setStatus({ step: 'error', message: `getchord couldn't build the swap: ${errorMessage(err)}` })
        return
      }

      const problem = findSwapProblem(build, { amountWei, taker: address })
      if (problem) {
        setStatus({ step: 'error', message: problem })
        return
      }
      // The build re-prices at the current state. If it now gives less than the
      // minimum the user was shown, let them see the new quote before signing.
      if (BigInt(build.amountOut) < BigInt(shownQuote.minAmountOut)) {
        onPriceMoved()
        const now = formatAmount(Number(formatUnits(BigInt(build.amountOut), USDC_DECIMALS)))
        setStatus({ step: 'error', message: `The price moved: you'd now get ${now} USDC. Check the new quote and press Swap again.` })
        return
      }

      setStatus({ step: 'signing' })
      let hash: Hash
      try {
        await ensureAvalanche(provider)
        hash = await sendTransaction(provider, address, build.tx!)
      } catch (err) {
        setStatus({ step: 'error', message: errorCode(err) === 4001 ? 'Swap rejected in Core.' : errorMessage(err) })
        return
      }

      setStatus({ step: 'pending', hash })
      try {
        const receipt = await avalancheClient.waitForTransactionReceipt({ hash, timeout: RECEIPT_TIMEOUT_MS })
        if (receipt.status !== 'success') {
          setStatus({ step: 'reverted', hash })
          return
        }
        const received = parseEventLogs({ abi: erc20Abi, eventName: 'Transfer', logs: receipt.logs })
          .filter((log) => log.address.toLowerCase() === USDC && log.args.to.toLowerCase() === address.toLowerCase())
          .reduce((sum, log) => sum + log.args.value, 0n)
        setStatus({
          step: 'confirmed',
          hash,
          receivedUsdc: received > 0n ? Number(formatUnits(received, USDC_DECIMALS)) : null,
        })
      } catch {
        setStatus({ step: 'unconfirmed', hash })
      } finally {
        refreshBalance()
      }
    },
    [provider, address, refreshBalance, slippageBps, onPriceMoved],
  )

  const clearError = useCallback(() => setStatus((s) => (s.step === 'error' ? { step: 'idle' } : s)), [])

  return { status, swap, clearError }
}
