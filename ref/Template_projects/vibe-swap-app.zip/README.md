# Vibe coding 1: a swap app on Avalanche

Claude Code wrote this app from a screenshot of the design (`design.png`) and a few plain prompts. Nobody edited the code by hand. It shows live prices, quotes AVAX to USDC through the getchord API, and hands the swap to the Core wallet to sign.

The replay above is the real session from 10 October 2026: five prompts, 22 minutes of AI time, about $7.85.

## Run it
```bash
npm install
npm run dev        # http://localhost:3000
```

Prices and quotes work without a wallet. To connect and swap you need the Core extension from core.app.

## Build it yourself
1. Install Claude Code, make an empty folder and save `design.png` into it.
2. In that folder, run the command below once. It lets the AI read the getchord API docs instead of guessing.
3. Run `claude` and type the three prompts, one at a time.

```bash
claude mcp add --transport http chord-docs https://getchord.xyz/docs/mcp
```

Prompt 1 took 7m09s in our run:
```
build this design as a web app design.png. Avalanche mainnet. connect the
Core wallet and show my address and AVAX balance
```

Prompt 2 took 3m39s:
```
make the swap card work. as I type an AVAX amount, show how much I'll get.
use the getchord DEX aggregator for the quote
```

Prompt 3 took 7m13s:
```
when I press Swap, build the transaction with getchord and open the Core
wallet so I can sign it. show the Snowtrace link after
```

Two of the five prompts in the replay changed nothing, so only three are listed here. One asked for real data in the chart and token list (the first prompt had already done that), and one asked to fix an error (the AI found no bug and said so).

The AI writes different code every time, so your result will not match this folder line for line.

## Watch out
- This app swaps **real AVAX on mainnet**. Use a separate wallet with about 0.1 AVAX in it.
- We have not signed a swap with it. The recording uses a read-only test wallet that refuses to sign, so everything up to the Core popup is tested and the swap itself is not.
- Before you sign, check three things in the Core popup: the network (Avalanche C-Chain), the amount (the AVAX you typed) and the address it sends to. The app only allows the router addresses listed in `src/lib/chord.ts`.
- Never paste a seed phrase or a private key into an AI.

## Where to look
- `src/lib/chord.ts` has every getchord call: the token list, the price history, the quote and the swap.
- `src/hooks/useSwap.ts` has the checks the app runs on a transaction before Core sees it.
- `src/lib/core.ts` finds the Core extension and switches it to Avalanche.

## Make it yours
Swap other pairs, add a slippage setting (it is fixed at 0.5%), or keep only the prices and quotes as the start of a dashboard.
