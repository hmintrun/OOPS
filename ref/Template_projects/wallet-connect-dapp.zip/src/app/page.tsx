import { WalletBar } from "@/components/WalletBar";
import { CHAIN_LABEL } from "@/lib/chains";

export default function Home() {
  return (
    <main className="min-w-0 flex-1">
      <section className="mx-auto w-full max-w-7xl px-5 pt-16 pb-10 md:px-6 md:pt-24">
        <h1 className="display text-4xl text-fg md:text-6xl">Connect a wallet</h1>
        <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted md:text-base">
          This app is set to {CHAIN_LABEL}. Connect a wallet and the bar below shows its address, its
          balance on that network, and a button to switch if the wallet is on another network.
        </p>
      </section>
      {/* ❓ Where is the wallet logic? → All of it is in WalletBar and ConnectButtons; this page only places them. */}
      <WalletBar />
    </main>
  );
}
