# Connect a wallet (Core, MetaMask, mobile)

A small Next.js app built from the wallet layer of this site's mint dApp. It connects Core or MetaMask in the browser, uses WalletConnect for phone wallets, shows the address and balance, and asks the wallet to switch when it is on the wrong network. It runs as it is, so you can start your own dApp from it.

## Run it
1. Install the packages. You need Node 22.9 or newer.
2. Copy `.env.example` to `.env.local`. It is set to the Fuji testnet.
3. Start the app and open http://localhost:3000.

```bash
npm install
cp .env.example .env.local
npm run dev
```

With Core or MetaMask installed, press **Connect wallet**. The bar shows the address and its test AVAX balance, and offers **Switch network** when the wallet is on another chain.

No wallet yet? Use a local chain. Install Foundry, set `NEXT_PUBLIC_CHAIN=anvil` in `.env.local`, run the two commands below in two terminals, and press **Dev wallet (anvil)**.

```bash
npm run anvil
npm run dev
```

## Where to look
- `src/lib/wagmi.ts` lists the chains and the three ways to connect: a browser wallet, WalletConnect, and the dev wallet for anvil.
- `src/components/ConnectButtons.tsx` decides which connect button to show on a desktop and on a phone.
- `src/components/WalletBar.tsx` shows network, address and balance, and handles the wrong network.
- `src/lib/chains.ts` picks Fuji or anvil from `NEXT_PUBLIC_CHAIN`.

## Watch out
- Phone wallets need a WalletConnect project id. Create one for free at dashboard.reown.com and put it in `NEXT_PUBLIC_WC_PROJECT_ID`. Without it the WalletConnect button is hidden.
- Every `NEXT_PUBLIC_` value is built into the page and is public. Never put a private key in one.
- **Disconnect** only makes this app forget the wallet. The permission stays in the wallet until the user removes it there.
- The balance is read on the app's network, not the wallet's. A wallet sitting on another chain still shows its Fuji balance.
- An empty wallet on anvil can be topped up with `npm run fund 0xYourAddress`. On Fuji you need a faucet.
- `npm run build` writes a static site to `out/` that any static host can serve.

## Make it yours
Change the app name and description in `src/lib/wagmi.ts`, add Avalanche mainnet to the chain list, or pair it with *Read and write a contract from the UI* to send transactions.
