# Google sign-in setup

The page shows a **Sign in with Google** button once the Worker knows your OAuth Client ID. Google hands the browser an ID token, the page posts it to `/api/hack/auth`, and the Worker verifies it before it sets the session cookie.

## 1. Create an OAuth Client ID
Open [Google Cloud Console, Credentials](https://console.cloud.google.com/apis/credentials), then Create Credentials, OAuth client ID, type **Web application**.

Under **Authorized JavaScript origins** add every origin the page is served from. Without this the button does not work.

```
http://localhost:8787
https://google-login-community-app.YOUR-SUBDOMAIN.workers.dev
https://your-domain.example
```

Origins must match exactly: the right scheme, no path and no trailing `/`. You can leave *Authorized redirect URIs* empty, because this flow runs in the browser and never redirects.

## 2. Publish the app
The OAuth consent screen starts in **Testing** mode. In that mode only the test users you add by hand (100 at most) can sign in, and Google turns everyone else away. Open the consent screen settings and choose **Publish app**.

This flow asks only for three non-sensitive scopes (`openid`, `userinfo.email`, `userinfo.profile`), so Google does not ask for a review and publishing takes effect at once.

## 3. Give the Client ID to the Worker
Copy the Client ID (it looks like `xxx.apps.googleusercontent.com`) into `GOOGLE_CLIENT_ID` in `wrangler.toml`, then restart or redeploy.

The Client ID is public: every browser that opens the page receives it. The Client *Secret* is the private one, and this flow does not use it.

## 4. What the Worker checks
`verifyGoogle()` in `src/hackathon.ts` never trusts the token as it arrives. In order:
- It reads the `kid` in the token header and finds that key among Google's published keys (`https://www.googleapis.com/oauth2/v3/certs`). If the key is unknown it fetches the list once more, because Google rotates its keys.
- It checks the RS256 signature with WebCrypto.
- It checks that `aud` is your Client ID, so a token issued to another app is refused.
- It checks `iss`, `exp` and `email_verified`.

Anyone can build a JWT that looks right. Only the signature proves that Google issued it, and that can only be checked on a server.

## Notes
- A Google ID token lives for one hour. The Worker needs it once, at sign-in. After that the session cookie takes over for 7 days.
- A verified email proves that the person owns that Google account and nothing more. If you have to match people to another system, you still need to cross-check.
- When a sign-in is refused, `npx wrangler tail` shows which check failed, for example `verifyGoogle: aud mismatch` or `verifyGoogle: expired`.
