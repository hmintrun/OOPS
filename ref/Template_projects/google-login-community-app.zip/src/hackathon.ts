import type { Env } from "./index";

// ❓ Where does the hackathon page store participants?
// → KV, under a "hack:" prefix (the binding is APP_KV in wrangler.toml).
//   Lists of people/teams are read with KV.list() and all the data shown on a card is put into the key's METADATA
//   (max 1KB), so a single list is enough to build the whole page without a get per person (a free Worker only
//   allows 50 subrequests per request).
//   The full detail (long bio, contact) lives in the value and is only read when a profile is opened.
//   Trade-off: KV has no transactions. Two people pressing join in the same millisecond can overwrite each other. At a scale of
//   a few hundred students that is acceptable; at thousands, move to D1.

const SESSION_DAYS = 7;
const COOKIE = "hk_session";
const MAX_TEAM = 3; // a team has at most three people
const U = "hack:u:";
const T = "hack:t:";
const ORPHAN_GRACE_MS = 10 * 60_000; // how long a new team stays listed before a profile must point to it

const TRACKS = ["social", "game", "agent", "x402", "open"] as const;

type Profile = {
  id: string;
  email: string;
  name: string;
  picture: string;
  university: string;
  major: string;
  year: string;
  skills: string[];
  bio: string;
  telegram: string;
  github: string;
  track: string;
  looking: boolean;
  teamId: string | null;
  /** Steps the student ticks themselves in the dashboard (keys live in STEPS). */
  progress?: Record<string, boolean>;
  /** Built-in avatar id: "cat-00" … "cat-47" (on the hackathon site the images live in /avatars/; this starter ships none). Empty = use the Google photo or the first letter. */
  avatar?: string;
  /** Team invitations sent to this person. */
  invites?: { teamId: string; at: number }[];
  createdAt: number;
  updatedAt: number;
};

// Only the steps students confirm themselves. "profile", "team", "submit" are derived by the client from real data.
const STEPS = ["builderhub", "faucet", "idea", "contract", "repo"] as const;

type Project = { idea: string; summary: string; repo: string; demo: string; tx: string; updatedAt: number };

type Team = {
  id: string;
  name: string;
  pitch: string;
  track: string;
  lookingFor: string[];
  owner: string;
  members: string[];
  requests: { id: string; msg: string; at: number }[];
  project?: Project;
  /** Token of the invite link. Anyone with the link who has a profile joins the team directly (until it is full); the owner rotates the token to revoke it. */
  inviteToken?: string;
  /** People the owner invited directly who have not answered yet. */
  invited?: string[];
  createdAt: number;
};

type Session = { id: string; e: string; n: string; p: string; exp: number };

const enc = new TextEncoder();

function json(body: unknown, status = 200, extra: HeadersInit = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...extra },
  });
}
const fail = (error: string, status = 400) => json({ ok: false, error }, status);

// ── base64url / HMAC ────────────────────────────────────────────────────────
function b64u(bytes: ArrayBuffer | Uint8Array): string {
  const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let s = "";
  for (const b of arr) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function unb64u(s: string): Uint8Array {
  const b = s.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(b + "=".repeat((4 - (b.length % 4)) % 4));
  return Uint8Array.from(bin, (c) => c.charCodeAt(0));
}
function utf8FromB64u(s: string): string {
  return new TextDecoder().decode(unb64u(s));
}
function b64uFromUtf8(s: string): string {
  return b64u(enc.encode(s));
}

async function sha256Hex(s: string): Promise<string> {
  const d = await crypto.subtle.digest("SHA-256", enc.encode(s));
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

// ❓ Why not use Google's "sub" directly as the public id?
// → This id appears in URLs and in list JSON anyone can see. A one-way hash avoids exposing a student's
//   Google identity; hashing the same sub always gives the same id so signing in again still finds the profile.
async function userId(sub: string): Promise<string> {
  return (await sha256Hex("hack-user:" + sub)).slice(0, 20);
}

function secret(env: Env): string | null {
  if (env.SESSION_SECRET) return env.SESSION_SECRET;
  if (env.DEV_AUTH === "true") return "dev-only-secret";
  return null;
}

async function hmacKey(sec: string) {
  return crypto.subtle.importKey("raw", enc.encode(sec), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}

async function signSession(env: Env, s: Session): Promise<string | null> {
  const sec = secret(env);
  if (!sec) return null;
  const body = b64uFromUtf8(JSON.stringify(s));
  const sig = await crypto.subtle.sign("HMAC", await hmacKey(sec), enc.encode(body));
  return `${body}.${b64u(sig)}`;
}

async function readSession(request: Request, env: Env): Promise<Session | null> {
  const sec = secret(env);
  if (!sec) return null;
  const raw = (request.headers.get("cookie") ?? "").split(/;\s*/).find((c) => c.startsWith(COOKIE + "="));
  if (!raw) return null;
  const [body, sig] = raw.slice(COOKIE.length + 1).split(".");
  if (!body || !sig) return null;
  // ❓ Why is the signature check inside the try as well?
  // → atob() throws on characters that are not base64. A cookie someone edited by hand must read as
  //   "signed out", not turn every request into a 500.
  try {
    const ok = await crypto.subtle.verify("HMAC", await hmacKey(sec), unb64u(sig), enc.encode(body));
    if (!ok) return null;
    const s = JSON.parse(utf8FromB64u(body)) as Session;
    return s.exp * 1000 > Date.now() ? s : null;
  } catch {
    return null;
  }
}

function cookie(value: string, maxAge: number, url: URL): string {
  const secure = url.protocol === "https:" ? "; Secure" : "";
  return `${COOKIE}=${value}; Path=/api/hack; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure}`;
}

// ── Verifying the Google ID token ───────────────────────────────────────────
type Jwk = JsonWebKey & { kid: string };
let jwksCache: { keys: Jwk[]; at: number } | null = null;

async function googleKeys(force = false): Promise<Jwk[]> {
  if (!force && jwksCache && Date.now() - jwksCache.at < 3600_000) return jwksCache.keys;
  const r = await fetch("https://www.googleapis.com/oauth2/v3/certs");
  if (!r.ok) throw new Error("jwks " + r.status);
  const data = (await r.json()) as { keys: Jwk[] };
  jwksCache = { keys: data.keys, at: Date.now() };
  return data.keys;
}

type GoogleClaims = { sub: string; email: string; name: string; picture: string };

// ❓ Why verify ourselves instead of trusting the token the client sends?
// → Anyone can build a JWT that looks identical. An RS256 signature checked against Google's public key proves Google issued the token;
//   then we check aud (our own Client ID), iss, exp and email_verified.
async function verifyGoogle(credential: string, env: Env): Promise<GoogleClaims | null> {
  // Dev mode: "dev:email:name". Only enabled when DEV_AUTH=true; never set it in production.
  if (env.DEV_AUTH === "true" && credential.startsWith("dev:")) {
    const [, email, name] = credential.split(":");
    if (!email) return null;
    return { sub: "dev-" + email, email, name: name || email.split("@")[0], picture: "" };
  }
  const clientId = env.GOOGLE_CLIENT_ID;
  if (!clientId) return null;
  const parts = credential.split(".");
  if (parts.length !== 3) return null;
  try {
    const header = JSON.parse(utf8FromB64u(parts[0])) as { kid?: string; alg?: string };
    if (header.alg !== "RS256") return null;
    // ❓ Why fetch the keys a second time when the kid is not found?
    // → Google rotates its signing keys. A token signed with a newer key than the one this isolate cached
    //   must trigger one refresh, not a 401 for every sign-in until the hour-long cache expires.
    let jwk = (await googleKeys()).find((k) => k.kid === header.kid);
    if (!jwk) jwk = (await googleKeys(true)).find((k) => k.kid === header.kid);
    // The warnings below show up in `wrangler tail`: they say which check failed without telling the caller.
    if (!jwk) { console.warn("verifyGoogle: unknown kid"); return null; }
    const key = await crypto.subtle.importKey("jwk", jwk, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
    const ok = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, unb64u(parts[2]), enc.encode(parts[0] + "." + parts[1]));
    if (!ok) { console.warn("verifyGoogle: bad signature"); return null; }
    const c = JSON.parse(utf8FromB64u(parts[1])) as Record<string, unknown>;
    if (c.aud !== clientId) { console.warn("verifyGoogle: aud mismatch"); return null; }
    if (c.iss !== "https://accounts.google.com" && c.iss !== "accounts.google.com") { console.warn("verifyGoogle: bad iss"); return null; }
    if (typeof c.exp !== "number" || c.exp * 1000 < Date.now()) { console.warn("verifyGoogle: expired"); return null; }
    if (c.email_verified !== true || typeof c.email !== "string" || typeof c.sub !== "string") { console.warn("verifyGoogle: email not verified"); return null; }
    return {
      sub: c.sub,
      email: c.email,
      name: typeof c.name === "string" ? c.name : c.email.split("@")[0],
      picture: typeof c.picture === "string" ? c.picture : "",
    };
  } catch (e) {
    console.warn("verifyGoogle: error", String(e));
    return null;
  }
}

// ── Sanitising input ────────────────────────────────────────────────────────
function str(v: unknown, max: number): string {
  return typeof v === "string" ? v.replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, max) : "";
}
function strList(v: unknown, count: number, each: number): string[] {
  if (!Array.isArray(v)) return [];
  const out: string[] = [];
  for (const x of v) {
    const s = str(x, each);
    if (s && !out.some((o) => o.toLowerCase() === s.toLowerCase())) out.push(s);
    if (out.length >= count) break;
  }
  return out;
}
function handle(v: unknown): string {
  return str(v, 40).replace(/^@/, "").replace(/[^\w.\-]/g, "");
}
// Only https links are accepted. This blocks javascript:, data: and plain http before they reach the public page.
function httpsUrl(v: unknown, max = 200): string {
  const t = str(v, max);
  try {
    const u = new URL(t);
    return u.protocol === "https:" ? u.toString().slice(0, max) : "";
  } catch {
    return "";
  }
}
// Only exact file names in /avatars/ (cat-00 … cat-47) are accepted, never free-form paths.
function avatarId(v: unknown): string {
  const t = str(v, 10);
  return /^cat-(?:0\d|[1-3]\d|4[0-7])$/.test(t) ? t : "";
}
function picture(v: string): string {
  return /^https:\/\/[\w.\-]+\.googleusercontent\.com\//.test(v) ? v.slice(0, 300) : "";
}

// ── Metadata (the display card) ─────────────────────────────────────────────
// A KV key only allows 1024 bytes of metadata, so trim the bio to fit instead of letting put() blow up.
function fitMeta<T extends Record<string, unknown>>(meta: T, key: keyof T): T {
  let m = { ...meta };
  while (enc.encode(JSON.stringify(m)).length > 1000 && typeof m[key] === "string" && (m[key] as string).length > 0) {
    m = { ...m, [key]: (m[key] as string).slice(0, Math.max(0, (m[key] as string).length - 12)) };
  }
  return m;
}

// Leaderboard score: profile (1) + steps ticked + being in a team (1). It lives in metadata so one list is enough to build the board.
function score(p: Profile): number {
  const done = STEPS.filter((k) => p.progress?.[k]).length;
  return 1 + done + (p.teamId ? 1 : 0);
}

function userMeta(p: Profile) {
  return fitMeta(
    { id: p.id, n: p.name, pic: p.picture, u: p.university, m: p.major, y: p.year, s: p.skills, l: p.looking, t: p.teamId, k: p.track, x: score(p), at: p.createdAt, av: p.avatar ?? "", b: p.bio.slice(0, 110) },
    "b",
  );
}
function teamMeta(t: Team, ownerName: string) {
  return fitMeta(
    { id: t.id, n: t.name, k: t.track, lf: t.lookingFor, c: t.members.length, o: ownerName, at: t.createdAt, p: t.pitch.slice(0, 140), s: !!(t.project?.repo && t.project?.demo) },
    "p",
  );
}

async function getUser(env: Env, id: string): Promise<Profile | null> {
  return env.APP_KV.get<Profile>(U + id, "json");
}
async function putUser(env: Env, p: Profile) {
  await env.APP_KV.put(U + p.id, JSON.stringify(p), { metadata: userMeta(p) });
}
async function getTeam(env: Env, id: string): Promise<Team | null> {
  return env.APP_KV.get<Team>(T + id, "json");
}
async function putTeam(env: Env, t: Team) {
  const owner = await getUser(env, t.owner);
  await env.APP_KV.put(T + t.id, JSON.stringify(t), { metadata: teamMeta(t, owner?.name ?? "") });
}

async function listAll<M>(env: Env, prefix: string): Promise<M[]> {
  const out: M[] = [];
  let cursor: string | undefined;
  for (let i = 0; i < 10; i++) {
    const r = await env.APP_KV.list<M>({ prefix, cursor, limit: 1000 });
    for (const k of r.keys) if (k.metadata) out.push(k.metadata);
    if (r.list_complete) break;
    cursor = r.cursor;
  }
  return out;
}

const publicUser = (m: ReturnType<typeof userMeta>) => ({
  id: m.id, name: m.n, picture: m.pic, university: m.u, major: m.m, year: m.y, skills: m.s, looking: m.l, teamId: m.t, track: m.k, bio: m.b, score: m.x ?? 1, joinedAt: m.at ?? 0, avatar: m.av ?? "",
});
const publicTeam = (m: ReturnType<typeof teamMeta>) => ({
  id: m.id, name: m.n, track: m.k, lookingFor: m.lf, size: m.c, max: MAX_TEAM, owner: m.o, pitch: m.p, submitted: m.s === true, createdAt: m.at ?? 0,
});

// ❓ Why cache the two public list endpoints?
// → Each list is a KV.list() call and every page view triggers both, so without this a busy event day could
//   exhaust the KV read/list quota. The price: a new profile or team can take up to `ttl` seconds to show up.
async function cachedList(url: URL, ttl: number, make: () => Promise<Response>): Promise<Response> {
  const key = new Request(url.origin + url.pathname);
  const hit = await caches.default.match(key);
  if (hit) return hit;
  const res = await make();
  const copy = new Response(res.body, res);
  copy.headers.set("cache-control", `public, max-age=${ttl}`);
  await caches.default.put(key, copy.clone());
  return copy;
}

// ── Router ──────────────────────────────────────────────────────────────────
export async function handleHackathon(request: Request, env: Env, url: URL): Promise<Response> {
  const path = url.pathname.replace(/^\/api\/hack\/?/, "").replace(/\/$/, "");
  const parts = path.split("/").filter(Boolean);
  const method = request.method;

  if (method === "GET" && path === "config") {
    return json({ ok: true, googleClientId: env.GOOGLE_CLIENT_ID ?? "", devAuth: env.DEV_AUTH === "true", ready: secret(env) !== null });
  }

  // The SameSite=Lax cookie blocks most CSRF; add an Origin check for every write request.
  if (method !== "GET") {
    const origin = request.headers.get("origin");
    let originHost = "";
    try { originHost = origin ? new URL(origin).host : ""; } catch { originHost = "invalid"; } // "Origin: null" must be a 403, not an exception
    if (origin && originHost !== url.host) return fail("bad_origin", 403);
  }

  if (method === "POST" && path === "auth") {
    if (!secret(env)) return fail("not_configured", 503);
    const body = (await request.json().catch(() => null)) as { credential?: string } | null;
    const g = body?.credential ? await verifyGoogle(body.credential, env) : null;
    if (!g) return fail("invalid_credential", 401);
    const id = await userId(g.sub);
    const token = await signSession(env, { id, e: g.email, n: g.name, p: picture(g.picture), exp: Math.floor(Date.now() / 1000) + SESSION_DAYS * 86400 });
    const profile = await getUser(env, id);
    return json({ ok: true, profile: profile ? await meFull(env, profile) : null, google: { name: g.name, picture: picture(g.picture) } }, 200, {
      "set-cookie": cookie(token!, SESSION_DAYS * 86400, url),
    });
  }

  if (method === "POST" && path === "logout") {
    return json({ ok: true }, 200, { "set-cookie": cookie("", 0, url) });
  }

  const session = await readSession(request, env);

  if (method === "GET" && path === "me") {
    if (!session) return json({ ok: true, signedIn: false });
    const profile = await getUser(env, session.id);
    return json({ ok: true, signedIn: true, google: { name: session.n, picture: session.p }, profile: profile ? await meFull(env, profile) : null });
  }

  // Viewing lists: open to everyone (name, school, skills). Contact details only appear once signed in with a profile.
  if (method === "GET" && path === "participants") {
    return cachedList(url, 30, async () => {
      const all = (await listAll<ReturnType<typeof userMeta>>(env, U)).map(publicUser);
      all.sort((a, b) => a.name.localeCompare(b.name));
      return json({ ok: true, total: all.length, participants: all });
    });
  }
  if (method === "GET" && parts[0] === "participants" && parts[1]) {
    const p = await getUser(env, parts[1]);
    if (!p) return fail("not_found", 404);
    const viewer = session ? await getUser(env, session.id) : null;
    return json({ ok: true, participant: { ...pub(p), telegram: viewer ? p.telegram : null, github: viewer ? p.github : null, locked: !viewer } });
  }

  if (method === "GET" && path === "teams") {
    return cachedList(url, 30, async () => {
      const [teams, users] = await Promise.all([listAll<ReturnType<typeof teamMeta>>(env, T), listAll<ReturnType<typeof userMeta>>(env, U)]);
      // ❓ Why drop teams that no profile points to?
      // → KV has no transactions, so a team record can be left behind with nobody in it (seen in production: a double
      //   click on "Create team" made two teams and the creator's profile kept only the second). The lead never sees
      //   that record, so a join request sent to it would go unanswered. A new team gets a few minutes of grace because
      //   KV.list() can lag behind the write that set its creator's teamId.
      const claimed = new Set(users.map((u) => u.t).filter(Boolean));
      const all = teams.filter((t) => claimed.has(t.id) || Date.now() - (t.at ?? 0) < ORPHAN_GRACE_MS).map(publicTeam);
      return json({ ok: true, total: all.length, teams: all });
    });
  }
  if (method === "GET" && parts[0] === "teams" && parts[1] && parts.length === 2) {
    const t = await getTeam(env, parts[1]);
    if (!t) return fail("not_found", 404);
    const viewer = session ? await getUser(env, session.id) : null;
    const members = (await Promise.all(t.members.map((id) => getUser(env, id)))).filter((x): x is Profile => !!x);
    const isOwner = viewer?.id === t.owner;
    const reqs = isOwner ? (await Promise.all(t.requests.map(async (r) => ({ r, u: await getUser(env, r.id) })))).filter((x) => x.u) : [];
    return json({
      ok: true,
      team: {
        id: t.id, name: t.name, pitch: t.pitch, track: t.track, lookingFor: t.lookingFor, max: MAX_TEAM, owner: t.owner, project: t.project ?? null,
        members: members.map((m) => ({ ...pub(m), telegram: viewer ? m.telegram : null })),
        locked: !viewer,
        isOwner,
        inviteToken: isOwner ? (t.inviteToken ?? null) : null,
        invited: isOwner ? (await Promise.all((t.invited ?? []).map(async (id) => { const u = await getUser(env, id); return u ? { id: u.id, name: u.name } : null; }))).filter(Boolean) : [],
        isMember: !!viewer && t.members.includes(viewer.id),
        requested: !!viewer && t.requests.some((r) => r.id === viewer.id),
        requests: reqs.map((x) => ({ ...pub(x.u!), message: x.r.msg, telegram: x.u!.telegram })),
      },
    });
  }

  // ── everything from here down needs sign-in ──
  if (!session) return fail("unauthorized", 401);

  if (method === "PUT" && path === "me") {
    const b = (await request.json().catch(() => null)) as Record<string, unknown> | null;
    if (!b) return fail("bad_json");
    const university = str(b.university, 80);
    const name = str(b.name, 60) || session.n;
    const telegram = handle(b.telegram);
    if (!university) return fail("university_required");
    if (!telegram) return fail("telegram_required");
    const prev = await getUser(env, session.id);
    const track = str(b.track, 20);
    const p: Profile = {
      id: session.id,
      email: session.e,
      name,
      picture: session.p,
      university,
      major: str(b.major, 60),
      year: str(b.year, 20),
      skills: strList(b.skills, 8, 20),
      bio: str(b.bio, 400),
      telegram,
      github: handle(b.github),
      track: (TRACKS as readonly string[]).includes(track) ? track : "open",
      looking: b.looking === true,
      avatar: avatarId(b.avatar),
      invites: prev?.invites ?? [],
      progress: prev?.progress,
      teamId: prev?.teamId ?? null,
      createdAt: prev?.createdAt ?? Date.now(),
      updatedAt: Date.now(),
    };
    await putUser(env, p);
    return json({ ok: true, profile: await meFull(env, p), created: !prev });
  }

  const self = await getUser(env, session.id);
  if (!self) return fail("profile_required", 403);

  if (method === "PUT" && path === "me/progress") {
    const b = (await request.json().catch(() => null)) as { key?: string; done?: boolean } | null;
    if (!b?.key || !(STEPS as readonly string[]).includes(b.key)) return fail("bad_step");
    const progress = { ...(self.progress ?? {}), [b.key]: b.done === true };
    await putUser(env, { ...self, progress, updatedAt: Date.now() });
    return json({ ok: true, progress });
  }

  if (method === "PUT" && path === "me/track") {
    const b = (await request.json().catch(() => null)) as { track?: string } | null;
    const track = str(b?.track, 20);
    if (!(TRACKS as readonly string[]).includes(track)) return fail("bad_track");
    await putUser(env, { ...self, track, updatedAt: Date.now() });
    return json({ ok: true, track });
  }

  // Every member of a team can edit the submission (the whole team shares one project).
  if (method === "PUT" && parts[0] === "teams" && parts[2] === "project" && parts[1]) {
    const t = await getTeam(env, parts[1]);
    if (!t) return fail("not_found", 404);
    if (!t.members.includes(self.id)) return fail("forbidden", 403);
    const b = (await request.json().catch(() => null)) as Record<string, unknown> | null;
    t.project = {
      idea: str(b?.idea, 100),
      summary: str(b?.summary, 600),
      repo: httpsUrl(b?.repo),
      demo: httpsUrl(b?.demo),
      tx: httpsUrl(b?.tx),
      updatedAt: Date.now(),
    };
    await putTeam(env, t);
    return json({ ok: true, project: t.project });
  }

  // Put `u` into team `t`: check it is not full, clear related invitations/requests, write both records.
  async function joinTeam(u: Profile, t: Team): Promise<Response | null> {
    if (u.teamId) return fail("already_in_team", 409);
    if (t.members.length >= MAX_TEAM) return fail("team_full", 409);
    t.members.push(u.id);
    t.invited = (t.invited ?? []).filter((x) => x !== u.id);
    t.requests = t.requests.filter((r) => r.id !== u.id);
    await putTeam(env, t);
    await putUser(env, { ...u, teamId: t.id, looking: false, invites: [], updatedAt: Date.now() });
    return null;
  }

  if (method === "POST" && path === "teams") {
    if (self.teamId) return fail("already_in_team", 409);
    const b = (await request.json().catch(() => null)) as Record<string, unknown> | null;
    const name = str(b?.name, 40);
    if (!name) return fail("name_required");
    // ❓ Why is the id derived from the profile instead of being random?
    // → Two requests from a double click both read the profile before either has written `teamId`, so both pass the
    //   check above; with a random id that created the team twice. They read the same profile version, though, so
    //   hashing its `updatedAt` gives both the same id: the second one finds the team already there, or writes the
    //   same record again. Leaving a team bumps `updatedAt`, so the next team this person starts gets a new id.
    const id = (await sha256Hex(`${self.id}:team:${self.updatedAt}`)).slice(0, 12);
    if (await getTeam(env, id)) return json({ ok: true, teamId: id });
    const t: Team = {
      id,
      name,
      pitch: str(b?.pitch, 400),
      track: (TRACKS as readonly string[]).includes(str(b?.track, 20)) ? str(b?.track, 20) : "open",
      lookingFor: strList(b?.lookingFor, 6, 24),
      owner: self.id,
      members: [self.id],
      requests: [],
      createdAt: Date.now(),
    };
    await putTeam(env, t);
    await putUser(env, { ...self, teamId: t.id, looking: false, invites: [], updatedAt: Date.now() });
    return json({ ok: true, teamId: t.id });
  }

  if (method === "POST" && path === "teams/leave") {
    if (!self.teamId) return fail("no_team", 409);
    const t = await getTeam(env, self.teamId);
    await putUser(env, { ...self, teamId: null, updatedAt: Date.now() });
    if (t) {
      t.members = t.members.filter((m) => m !== self.id);
      if (t.members.length === 0) await env.APP_KV.delete(T + t.id);
      else {
        if (t.owner === self.id) t.owner = t.members[0]; // hand over to the earliest member
        await putTeam(env, t);
      }
    }
    return json({ ok: true });
  }

  if (method === "POST" && parts[0] === "teams" && parts[2] === "join" && parts[1]) {
    if (self.teamId) return fail("already_in_team", 409);
    const t = await getTeam(env, parts[1]);
    if (!t) return fail("not_found", 404);
    if (t.members.length >= MAX_TEAM) return fail("team_full", 409);
    const b = (await request.json().catch(() => null)) as Record<string, unknown> | null;
    if (!t.requests.some((r) => r.id === self.id)) {
      if (t.requests.length >= 30) return fail("too_many_requests", 429);
      t.requests.push({ id: self.id, msg: str(b?.message, 240), at: Date.now() });
      await putTeam(env, t);
    }
    return json({ ok: true });
  }

  if (method === "POST" && parts[0] === "teams" && parts[2] === "requests" && parts[1] && parts[3]) {
    const t = await getTeam(env, parts[1]);
    if (!t) return fail("not_found", 404);
    if (t.owner !== self.id) return fail("forbidden", 403);
    const b = (await request.json().catch(() => null)) as { action?: string } | null;
    const idx = t.requests.findIndex((r) => r.id === parts[3]);
    if (idx < 0) return fail("not_found", 404);
    t.requests.splice(idx, 1);
    if (b?.action === "accept") {
      const u = await getUser(env, parts[3]);
      if (!u || u.teamId) {
        await putTeam(env, t);
        return fail("already_in_team", 409);
      }
      if (t.members.length >= MAX_TEAM) return fail("team_full", 409);
      t.members.push(u.id);
      t.invited = (t.invited ?? []).filter((x) => x !== u.id);
      await putUser(env, { ...u, teamId: t.id, looking: false, invites: [], updatedAt: Date.now() });
    }
    await putTeam(env, t);
    return json({ ok: true });
  }

  // The team owner invites one participant directly.
  if (method === "POST" && parts[0] === "teams" && parts[2] === "invite" && parts[1]) {
    const t = await getTeam(env, parts[1]);
    if (!t) return fail("not_found", 404);
    if (t.owner !== self.id) return fail("forbidden", 403);
    if (t.members.length >= MAX_TEAM) return fail("team_full", 409);
    const b = (await request.json().catch(() => null)) as { userId?: string } | null;
    const target = b?.userId ? await getUser(env, str(b.userId, 40)) : null;
    if (!target) return fail("not_found", 404);
    if (target.teamId) return fail("already_in_team", 409);
    if ((target.invites ?? []).some((i) => i.teamId === t.id)) return json({ ok: true, already: true });
    if ((target.invites ?? []).length >= 10) return fail("too_many_requests", 429);
    target.invites = [...(target.invites ?? []), { teamId: t.id, at: Date.now() }];
    await putUser(env, { ...target, updatedAt: Date.now() });
    t.invited = [...(t.invited ?? []), target.id].slice(-30);
    await putTeam(env, t);
    return json({ ok: true });
  }

  // Invite link: create (or rotate to revoke) the token. Owner only.
  if (method === "POST" && parts[0] === "teams" && parts[2] === "invite-link" && parts[1]) {
    const t = await getTeam(env, parts[1]);
    if (!t) return fail("not_found", 404);
    if (t.owner !== self.id) return fail("forbidden", 403);
    const b = (await request.json().catch(() => null)) as { reset?: boolean } | null;
    if (!t.inviteToken || b?.reset === true) {
      t.inviteToken = (await sha256Hex(t.id + Date.now() + Math.random() + self.id)).slice(0, 20);
      await putTeam(env, t);
    }
    return json({ ok: true, token: t.inviteToken });
  }

  // Join a team through an invite link.
  if (method === "POST" && parts[0] === "teams" && parts[2] === "join-link" && parts[1]) {
    const t = await getTeam(env, parts[1]);
    const b = (await request.json().catch(() => null)) as { token?: string } | null;
    if (!t || !t.inviteToken || b?.token !== t.inviteToken) return fail("invalid_invite", 403);
    const err = await joinTeam(self, t);
    return err ?? json({ ok: true, teamId: t.id });
  }

  // The invited person accepts or declines.
  if (method === "POST" && parts[0] === "invites" && parts[2] === "respond" && parts[1]) {
    const inv = (self.invites ?? []).find((i) => i.teamId === parts[1]);
    if (!inv) return fail("not_found", 404);
    const b = (await request.json().catch(() => null)) as { action?: string } | null;
    const t = await getTeam(env, parts[1]);
    if (b?.action === "accept") {
      if (!t) return fail("not_found", 404);
      const err = await joinTeam(self, t);
      return err ?? json({ ok: true, teamId: t.id });
    }
    await putUser(env, { ...self, invites: (self.invites ?? []).filter((i) => i.teamId !== parts[1]), updatedAt: Date.now() });
    if (t) { t.invited = (t.invited ?? []).filter((x) => x !== self.id); await putTeam(env, t); }
    return json({ ok: true });
  }

  return fail("not_found", 404);
}

function pub(p: Profile) {
  return {
    id: p.id, name: p.name, picture: p.picture, university: p.university, major: p.major, year: p.year,
    skills: p.skills, bio: p.bio, track: p.track, looking: p.looking, teamId: p.teamId, avatar: p.avatar ?? "",
  };
}
// The profile owner sees everything, including email; other people never see the email.
// An invitation comes with the team name; invitations to deleted teams are dropped.
async function meFull(env: Env, p: Profile) {
  const list: { teamId: string; teamName: string; at: number }[] = [];
  for (const inv of (p.invites ?? []).slice(0, 10)) {
    const t = await getTeam(env, inv.teamId);
    if (t) list.push({ teamId: t.id, teamName: t.name, at: inv.at });
  }
  return { ...me(p), invites: list };
}
function me(p: Profile) {
  return { ...pub(p), email: p.email, telegram: p.telegram, github: p.github, progress: p.progress ?? {} };
}
