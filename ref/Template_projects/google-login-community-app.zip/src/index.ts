import { handleHackathon } from "./hackathon";

// ❓ What do you gain when one Worker serves both the page and the API?
// → SAME ORIGIN. The page and /api/hack live on one host, so the browser does not treat the calls as
//   cross-origin: no preflight, no CORS headers, and the session cookie can be SameSite=Lax.
//   One `wrangler deploy` ships the front end and the back end together.

export interface Env {
  /** The static page in ./public, configured under [assets] in wrangler.toml. */
  ASSETS: Fetcher;
  /** Profiles and teams, under the "hack:" prefix. */
  APP_KV: KVNamespace;
  /** OAuth Client ID (public). Used to check the `aud` of the Google ID token. */
  GOOGLE_CLIENT_ID?: string;
  /** Key that signs the session cookie. Secret: `wrangler secret put SESSION_SECRET`. */
  SESSION_SECRET?: string;
  /** "true" only on your own machine: allows a fake sign-in so you can try the API without Google. */
  DEV_AUTH?: string;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname.startsWith("/api/hack")) {
      return handleHackathon(request, env, url);
    }

    // ❓ Why answer other /api/ paths here instead of passing them to the assets?
    // → A mistyped API path should come back as JSON the caller can read, not as an HTML 404 page.
    if (url.pathname.startsWith("/api/")) {
      return new Response(JSON.stringify({ ok: false, error: "not_found" }), {
        status: 404,
        headers: { "content-type": "application/json; charset=utf-8" },
      });
    }

    // ❓ When does this line run, if static files are served before the Worker?
    // → Only for a path that matched no file in ./public. Handing it back to the assets returns their 404.
    return env.ASSETS.fetch(request);
  },
} satisfies ExportedHandler<Env>;
