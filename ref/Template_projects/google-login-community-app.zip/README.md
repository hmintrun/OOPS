# Google login + profiles + teams on a Worker

The sign-in and team API from this hackathon site in its original Workers KV form, cut down to its core: sign in with Google, a signed session cookie, profiles, teams and join requests. One Cloudflare Worker serves the API and a small test page.

## Run it
1. Install the tools.
2. Copy `.dev.vars.example` to `.dev.vars`. It sets `DEV_AUTH=true`, which adds a fake sign-in so you can try everything without a Google account.
3. Start the Worker and open http://localhost:8787.

```bash
npm install
cp .dev.vars.example .dev.vars
npx wrangler dev
```

On the page, use the dev sign-in, save a profile and create a team. Then open a private window, sign in as a second person and ask to join: the first person sees the request and accepts it. Local data stays in the `.wrangler` folder and never reaches Cloudflare.

## Turn on Google sign-in
1. Create an OAuth Client ID and add your origins. The steps are in `docs/google-signin.md`.
2. Put the Client ID in `GOOGLE_CLIENT_ID` in `wrangler.toml`. It is public, so it can sit in the file.
3. Restart `npx wrangler dev`. The page now shows the Google button.

## Deploy it
```bash
npx wrangler kv namespace create APP_KV       # paste the id it prints into wrangler.toml
npx wrangler secret put SESSION_SECRET        # a long random string
npx wrangler deploy
```

## Where to look
- `verifyGoogle()` in `src/hackathon.ts` checks the token's signature against Google's public keys, then `aud`, `iss`, `exp` and `email_verified`.
- `signSession()` and `readSession()` make the session an HMAC-signed cookie, `HttpOnly` and `SameSite=Lax`. Every write also checks the `Origin` header.
- `userMeta()` and `teamMeta()` put what a list shows into KV metadata, so one `list()` call builds a whole page.
- `public/index.html` is one plain HTML file that calls the API.

## Watch out
- Never set `DEV_AUTH` on a deployed Worker. With it anyone can sign in as any email. Keep it in `.dev.vars`, which is never deployed.
- Without `SESSION_SECRET` a deployed Worker answers `not_configured` to every sign-in.
- Never trust a Google token you did not verify on the server. The page only passes it along.
- KV has no transactions. Two people who join the same team in the same instant can overwrite each other. That is acceptable for a few hundred people; beyond that, move to D1.
- The two public lists are cached for 30 seconds, so a new team or profile can take that long to appear.
- A team that no profile points to is dropped from the public list after 10 minutes.

## Make it yours
Change the profile fields, `TRACKS` and `MAX_TEAM` (3) to fit your event, or keep only the sign-in half and store your own data behind the session.
