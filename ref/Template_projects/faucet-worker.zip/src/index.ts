import { handleFaucet } from "./faucet";

// ❓ What do you gain from one Worker that serves the page and also runs the API?
// → SAME ORIGIN. The page (public/index.html) and the API (/api/faucet) share one domain, so the browser
//   does not treat the call as cross-origin: no preflight, no CORS headers, no separate subdomain or
//   extra DNS record. One `wrangler deploy` ships the front end and the back end together.

export interface Env {
  /** The static page: the public/ folder, configured under [assets] in wrangler.toml. */
  ASSETS: Fetcher;
  /** Remembers who has claimed. Created with `wrangler kv namespace create FAUCET_KV`. */
  FAUCET_KV: KVNamespace;
  /** Key of the hot wallet. Secret: `wrangler secret put FAUCET_PRIVATE_KEY` (locally: .dev.vars). */
  FAUCET_PRIVATE_KEY: string;
  /** Optional captcha. Secret: `wrangler secret put TURNSTILE_SECRET`. */
  TURNSTILE_SECRET?: string;
  DRIP_AMOUNT?: string;
  COOLDOWN_HOURS?: string;
  COOLDOWN_BY_IP?: string;
  ALLOWED_ORIGINS?: string;
  RPC_URL?: string;
}

const JSON_HEADERS = { "content-type": "application/json; charset=utf-8" };

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    // ❓ Why check the path here when wrangler.toml already has run_worker_first = ["/api/*"]?
    // → run_worker_first only decides which requests reach the Worker BEFORE the static files. The Worker
    //   also receives every request that matches no file, so it has to route by itself. Without this
    //   check a mistyped path would fall into the faucet.
    if (url.pathname === "/api/faucet" || url.pathname.startsWith("/api/faucet/")) {
      // ❓ Why wrap the handler in try/catch?
      // → The handler talks to an RPC node and to KV, and either can fail. An uncaught error becomes
      //   Cloudflare's HTML error page, which the page's fetch().json() cannot read. Returning JSON keeps
      //   the front end's error handling in one shape.
      try {
        return await handleFaucet(request, env, url);
      } catch (e) {
        console.error("faucet error", e);
        return new Response(
          JSON.stringify({
            ok: false,
            error: "server_error",
            message: "The faucet hit an unexpected error. Try again in a minute.",
          }),
          { status: 500, headers: JSON_HEADERS },
        );
      }
    }

    if (url.pathname.startsWith("/api/")) {
      return new Response(JSON.stringify({ ok: false, error: "not_found" }), {
        status: 404,
        headers: JSON_HEADERS,
      });
    }

    // ❓ What is env.ASSETS.fetch for, when static files are already served before the Worker?
    // → It is the fallback for a path that matched no file: hand the request back to the asset
    //   server so it answers with its own 404 instead of the Worker returning a blank page.
    return env.ASSETS.fetch(request);
  },
} satisfies ExportedHandler<Env>;
