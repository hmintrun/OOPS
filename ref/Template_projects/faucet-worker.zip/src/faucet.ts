import {
  createPublicClient,
  createWalletClient,
  formatEther,
  getAddress,
  http,
  isAddress,
  parseEther,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { avalancheFuji } from "viem/chains";
import type { Env } from "./index";

// ❓ Why must the faucet run on a server instead of in the web page?
// → Sending AVAX means SIGNING a transaction with a private key. Anything in a JS bundle can be read
//   with View Source → a bot drains the wallet within minutes. The key may only live in the Worker's secret.
//
// ❓ Why not build the faucet as a contract so no server is needed?
// → A freshly created student wallet has 0 AVAX, so it cannot pay the gas to call claim(). Exactly when the faucet
//   is needed most, a contract-only design is stuck. So a hot wallet that signs on their behalf is still needed.

type ClaimRecord = { at: number; hash: string };

const JSON_HEADERS = { "content-type": "application/json; charset=utf-8" };

// ❓ Same origin, so why is there still CORS code?
// → When the page and the API come from the same Worker (as in this starter) you do NOT need CORS, and
//   ALLOWED_ORIGINS is empty by default, so the Worker returns no CORS headers: a browser on a foreign
//   domain is blocked right at the preflight. Only set this variable when the page lives on another
//   origin, for example a front end on localhost:3000 that calls the deployed Worker.
function corsHeaders(origin: string | null, env: Env): Record<string, string> {
  const allowed = (env.ALLOWED_ORIGINS ?? "")
    .split(",")
    .map((o) => o.trim())
    .filter(Boolean);
  if (!allowed.length || !origin || !allowed.includes(origin)) return {};
  return {
    "access-control-allow-origin": origin,
    "access-control-allow-methods": "POST, GET, OPTIONS",
    "access-control-allow-headers": "content-type",
    "access-control-max-age": "86400",
    vary: "Origin",
  };
}

function json(body: unknown, status: number, extra: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...JSON_HEADERS, ...extra },
  });
}

async function verifyTurnstile(token: string, secret: string, ip: string | null) {
  const form = new FormData();
  form.append("secret", secret);
  form.append("response", token);
  if (ip) form.append("remoteip", ip);
  const r = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
    method: "POST",
    body: form,
  });
  const data = (await r.json()) as { success?: boolean };
  return data.success === true;
}

export async function handleFaucet(
  request: Request,
  env: Env,
  url: URL,
): Promise<Response> {
  const origin = request.headers.get("Origin");
  const cors = corsHeaders(origin, env);

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: cors });
  }

  const rpc = env.RPC_URL ?? "https://api.avax-test.network/ext/bc/C/rpc";
  const publicClient = createPublicClient({
    chain: avalancheFuji,
    transport: http(rpc),
  });

  // ─── GET /api/faucet: status, so you can check how much is left in the wallet ─────────
  if (request.method === "GET") {
    if (!env.FAUCET_PRIVATE_KEY) {
      return json({ ok: false, error: "not_configured" }, 503, cors);
    }
    const account = privateKeyToAccount(env.FAUCET_PRIVATE_KEY as `0x${string}`);
    const balance = await publicClient.getBalance({ address: account.address });
    const drip = parseEther(env.DRIP_AMOUNT ?? "0.005");
    return json(
      {
        ok: true,
        faucet: account.address,
        balance: formatEther(balance),
        drip: formatEther(drip),
        claimsLeft: drip > 0n ? Number(balance / drip) : 0,
        cooldownHours: Number(env.COOLDOWN_HOURS ?? "24"),
        chain: "avalanche-fuji",
      },
      200,
      cors,
    );
  }

  if (request.method !== "POST" || !url.pathname.endsWith("/claim")) {
    return json({ ok: false, error: "not_found" }, 404, cors);
  }

  // ─── POST /api/faucet/claim ──────────────────────────────────────────────────
  if (!env.FAUCET_PRIVATE_KEY) {
    return json({ ok: false, error: "not_configured" }, 503, cors);
  }

  let body: { address?: string; turnstileToken?: string };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return json({ ok: false, error: "bad_json" }, 400, cors);
  }

  const raw = (body.address ?? "").trim();
  if (!isAddress(raw)) {
    return json(
      { ok: false, error: "bad_address", message: "That wallet address is not valid." },
      400,
      cors,
    );
  }
  // ❓ Why call getAddress first and only then lowercase?
  // → getAddress both normalises to the checksum form and rejects bad addresses. The KV key uses the lowercase copy
  //   so "0xAbC…" and "0xabc…" cannot sneak through as two different claims.
  const address = getAddress(raw);
  const addrKey = `addr:${address.toLowerCase()}`;

  const ip = request.headers.get("CF-Connecting-IP");
  // ❓ Why is IP blocking OFF by default?
  // → A whole workshop room on one wifi shares one IP: once the first person has claimed, everyone
  //   else is locked out. This bug happened for real in a trial run.
  //   Trade-off: a bot creating unlimited new wallets can then only be stopped by the per-address cooldown, so if you get farmed
  //   turn on TURNSTILE_SECRET (captcha) first instead of turning IP blocking back on.
  const byIp = (env.COOLDOWN_BY_IP ?? "false").toLowerCase() === "true";
  const ipKey = byIp && ip ? `ip:${ip}` : null;

  if (env.TURNSTILE_SECRET) {
    const token = (body.turnstileToken ?? "").trim();
    if (!token || !(await verifyTurnstile(token, env.TURNSTILE_SECRET, ip))) {
      return json(
        { ok: false, error: "captcha_failed", message: "Captcha verification failed." },
        403,
        cors,
      );
    }
  }

  const cooldownHours = Number(env.COOLDOWN_HOURS ?? "24");
  const cooldownSec = Math.max(60, Math.round(cooldownHours * 3600));
  const now = Date.now();

  // ❓ Why can the loop check both the address and the IP?
  // → Blocking only the address lets a bot create unlimited new wallets (free). Blocking only the IP makes a whole workshop
  //   room on shared wifi block each other. The address is always checked; the IP key exists only when
  //   COOLDOWN_BY_IP is "true" (see above), and a null key is skipped.
  for (const [key, label] of [
    [addrKey, "this address"],
    [ipKey, "this IP"],
  ] as const) {
    if (!key) continue;
    const hit = await env.FAUCET_KV.get(key, "json");
    if (hit) {
      const rec = hit as ClaimRecord;
      const waitSec = Math.max(0, cooldownSec - Math.floor((now - rec.at) / 1000));
      // ❓ Why vary the message by the cooldown length?
      // → team1vn.xyz runs with 8760 hours (1 year) so each wallet claims exactly once. Saying "try again
      //   after 8760 hours" is both confusing and misleading, as if waiting would work. Beyond 48 hours we
      //   say plainly that it is a one-time claim.
      const oneShot = cooldownSec > 48 * 3600;
      const message = oneShot
        ? `Each ${label === "this IP" ? "IP" : "wallet"} can only claim once, and ${label} has already claimed.`
        : `Already sent to ${label}. Try again in ${Math.ceil(waitSec / 3600)} hours.`;
      return json(
        {
          ok: false,
          error: "cooldown",
          message,
          retryAfterSeconds: waitSec,
          previousHash: rec.hash,
        },
        429,
        { ...cors, "retry-after": String(waitSec) },
      );
    }
  }

  const account = privateKeyToAccount(env.FAUCET_PRIVATE_KEY as `0x${string}`);
  const drip = parseEther(env.DRIP_AMOUNT ?? "0.005");

  // ❓ Why subtract 21000 gas when comparing the balance?
  // → A plain AVAX transfer costs exactly 21000 gas. A wallet holding exactly the drip would fail for lack of gas;
  //   we report "out of funds" first to be clear. This check comes BEFORE writing KV, so an empty faucet does not lock anyone out unfairly.
  const gasPrice = await publicClient.getGasPrice();
  const reserve = 21_000n * gasPrice;
  const balance = await publicClient.getBalance({ address: account.address });
  if (balance < drip + reserve) {
    return json(
      {
        ok: false,
        error: "faucet_empty",
        message: "The faucet is out of test AVAX. Please tell the organisers to refill it.",
        balance: formatEther(balance),
      },
      503,
      cors,
    );
  }

  // ❓ Why write KV BEFORE sending the transaction?
  // → To reserve the slot. If we wrote it afterwards, two requests pressed at the same moment would both see "not claimed" and claim twice.
  //   If sending fails, the key is deleted below so the user can try again.
  const record: ClaimRecord = { at: now, hash: "" };
  await env.FAUCET_KV.put(addrKey, JSON.stringify(record), {
    expirationTtl: cooldownSec,
  });
  if (ipKey) {
    await env.FAUCET_KV.put(ipKey, JSON.stringify(record), {
      expirationTtl: cooldownSec,
    });
  }

  const wallet = createWalletClient({
    account,
    chain: avalancheFuji,
    transport: http(rpc),
  });

  try {
    // ❓ Why fetch the "pending" nonce ourselves and retry?
    // → When many people press at once the requests read the same nonce → only one tx goes through and the rest fail
    //   with "nonce too low". Taking the pending nonce and retrying twice is enough for a workshop-sized crowd.
    let hash: `0x${string}` | undefined;
    let lastErr: unknown;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const nonce = await publicClient.getTransactionCount({
          address: account.address,
          blockTag: "pending",
        });
        hash = await wallet.sendTransaction({
          to: address,
          value: drip,
          gas: 21_000n,
          nonce,
        });
        break;
      } catch (e) {
        lastErr = e;
        const msg = String(e);
        if (!/nonce|replacement|already known/i.test(msg)) throw e;
        await new Promise((r) => setTimeout(r, 300 * (attempt + 1)));
      }
    }
    if (!hash) throw lastErr ?? new Error("send failed");

    const done: ClaimRecord = { at: now, hash };
    await env.FAUCET_KV.put(addrKey, JSON.stringify(done), {
      expirationTtl: cooldownSec,
    });
    if (ipKey) {
      await env.FAUCET_KV.put(ipKey, JSON.stringify(done), {
        expirationTtl: cooldownSec,
      });
    }

    return json(
      {
        ok: true,
        hash,
        amount: formatEther(drip),
        to: address,
        explorer: `https://testnet.snowtrace.io/tx/${hash}`,
      },
      200,
      cors,
    );
  } catch (e) {
    // Sending failed → release the reserved slot so the user can try again right away.
    await env.FAUCET_KV.delete(addrKey);
    if (ipKey) await env.FAUCET_KV.delete(ipKey);
    return json(
      {
        ok: false,
        error: "send_failed",
        message: "Sending the transaction failed. Please try again in a few minutes.",
        detail: String(e).slice(0, 200),
      },
      502,
      cors,
    );
  }
}
