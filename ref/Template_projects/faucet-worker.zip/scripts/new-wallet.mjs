// Prints a brand-new wallet for the faucet: `npm run new-wallet`.
//
// ❓ Why make a new wallet instead of using the one you already have?
// → The key sits in a Worker secret, and anyone who can deploy the Worker can read it. A wallet made
//   only for the faucet, holding only test AVAX, has nothing worth stealing.
import { generatePrivateKey, privateKeyToAccount } from "viem/accounts";

const key = generatePrivateKey();
const { address } = privateKeyToAccount(key);

console.log("Private key (put it in .dev.vars, never in git):");
console.log(`FAUCET_PRIVATE_KEY=${key}`);
console.log("");
console.log("Address (send test AVAX here to fill the faucet):");
console.log(address);
