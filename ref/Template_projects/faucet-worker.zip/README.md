# A faucet on a Cloudflare Worker

The faucet behind this site, as a project you can run. One Worker serves a small page (`public/index.html`) and the API (`/api/faucet`). The wallet key lives in a Worker secret, so the browser never sees it.

## Run it
1. Install the packages.
2. Copy `.dev.vars.example` to `.dev.vars`. This file holds your local secrets.
3. Run `npm run new-wallet` and paste the `FAUCET_PRIVATE_KEY=...` line it prints into `.dev.vars`.
4. Start the Worker and open the address it prints, http://localhost:8787 by default.

```bash
npm install
cp .dev.vars.example .dev.vars
npm run new-wallet
npm run dev
```

The page shows the faucet wallet with a balance of 0, and a claim answers "The faucet is out of test AVAX". Get test AVAX from the [Core faucet](https://core.app/tools/testnet-faucet), send it to the faucet address, and claims start to work.

If you change `.dev.vars` while the Worker is running, stop it and run `npm run dev` again.

## Deploy it
1. Log in to Cloudflare.
2. Create the KV namespace and paste the id it prints into `wrangler.toml`, in place of `REPLACE_WITH_YOUR_KV_NAMESPACE_ID`.
3. Deploy. The API answers `not_configured` until the next step.
4. Set the wallet key as a secret: paste the key from `.dev.vars` when it asks.

```bash
npx wrangler login
npx wrangler kv namespace create FAUCET_KV
npx wrangler deploy
npx wrangler secret put FAUCET_PRIVATE_KEY
```

## Watch out
- Fund the hot wallet with **testnet** AVAX only. Anyone who can deploy your Worker can read its secrets, so never reuse this pattern for a wallet with real value.
- The key is in `.dev.vars`. That file is in `.gitignore`; keep it out of git.
- The limit is one claim per address every `COOLDOWN_HOURS` (24 by default). Blocking by IP is off, because a class on one wifi shares one IP and the first claim would lock everyone else out.
- A bot can make new addresses for free. Before a public launch turn on the Turnstile captcha: set `TURNSTILE_SECRET` as a secret and put the site key in `TURNSTILE_SITE_KEY` in `public/index.html`.
- KV is eventually consistent, so two claims for one address in the same instant can both get through. That is fine for a workshop. Use a Durable Object if you need a hard limit.

## Where to look
- `src/faucet.ts` is the faucet itself, the same code this site runs: status, checks, cooldown and the transfer.
- `src/index.ts` routes `/api/faucet` to it and serves the page for everything else.
- `wrangler.toml` holds the settings: amount per claim, cooldown, RPC URL.

## Make it yours
Change `DRIP_AMOUNT` and `COOLDOWN_HOURS` in `wrangler.toml`, restyle `public/index.html`, or change the chain and the explorer link in `src/faucet.ts` to send tokens on your own L1.
