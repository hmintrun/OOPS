import { readFileSync } from "node:fs";
import { join } from "node:path";
import {
  createPublicClient,
  createWalletClient,
  http,
  parseEventLogs,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { compile, ROOT } from "./compile.mjs";
import {
  ANVIL_PRIVATE_KEY,
  ANVIL_PRIVATE_KEY_2,
  resolveNetwork,
} from "./chains.mjs";

const net = resolveNetwork();
// ❓ Why can the test only run on anvil?
// → The test deploys a new contract and mints all 48 cats: it burns real gas and pollutes data if you run it on Fuji.
// → anvil is its own free chain, and a restart makes it clean.
if (net.key !== "anvil") {
  console.error("❌ test:contract only runs on anvil (local) for safety.");
  process.exit(1);
}

let passed = 0;
const failures = [];
// ❓ What is check(), and why not jest/mocha?
// → A tiny hand-written test runner so we need no extra dependency: it counts passes, collects failures and prints each line.
// → At the end the exit code is 1 if anything failed → npm scripts / CI know the test failed.
function check(name, cond, detail = "") {
  if (cond) {
    passed++;
    console.log(`   ✅ ${name}`);
  } else {
    failures.push(name + (detail ? `: ${detail}` : ""));
    console.log(`   ❌ ${name}${detail ? `: ${detail}` : ""}`);
  }
}
// ❓ Why an eq function instead of ===?
// → A uint256 coming from the chain into JS is a BigInt: 1n !== 1 and 1n !== "1". eq compares BigInt to BigInt,
// → and strings/addresses via String() so a test does not fail just because of a type difference.
const eq = (a, b) => (typeof a === "bigint" ? a === b : String(a) === String(b));

const src = readFileSync(join(ROOT, "src", "lib", "cats.ts"), "utf8");
const CATS = JSON.parse(src.slice(src.indexOf("[{"), src.lastIndexOf("]") + 1));

const buildTokenURI = (cat) =>
  "data:application/json;base64," +
  Buffer.from(
    JSON.stringify({
      name: `${cat.name} - Team1 VN`,
      description:
        "AvaxCats - pixel summit cat of Team Avalanche (Team1 VN). " +
        "Minted on Anvil local (31337) for the academy demo.",
      image: cat.image,
      attributes: cat.attributes,
    }),
  ).toString("base64");

const { abi, bytecode } = compile({ quiet: true });
// ❓ Who are Alice and Bob?
// → Accounts #0 and #1 that anvil prints on start (fixed, public private keys). Two different wallets are used
// → to test that ownerOf/balanceOf point at the right owner and that tokenId increases across wallets.
const alice = privateKeyToAccount(ANVIL_PRIVATE_KEY);
const bob = privateKeyToAccount(ANVIL_PRIVATE_KEY_2);
const transport = http(net.rpcUrl);
const pub = createPublicClient({ chain: net.chain, transport });
const wallet = (account) =>
  createWalletClient({ account, chain: net.chain, transport });

try {
  await pub.getChainId();
} catch {
  console.error(`
❌ Could not connect to anvil at ${net.rpcUrl}
   Open another terminal tab and run:  npm run anvil
`);
  process.exit(1);
}

console.log(`\n🧪 AvaxCats: testing on ${net.label}\n`);

console.log("1. Deploy a fresh contract");
// ❓ Why deploy a new contract for every test run?
// → So each run starts with clean state (totalMinted = 0, bitmap = 0). Reusing an old contract would make the "mint cat 0" test fail because it was minted last time.
// → On anvil deploying is free and instant, so there is no reason to reuse one.
const deployHash = await wallet(alice).deployContract({ abi, bytecode });
const deployReceipt = await pub.waitForTransactionReceipt({ hash: deployHash });
const address = deployReceipt.contractAddress;
check("deploy succeeded", deployReceipt.status === "success", address);

const read = (functionName, args = []) =>
  pub.readContract({ address, abi, functionName, args });

console.log("\n2. Initial state");
check("name = 'AvaxCats - Team1 VN'", eq(await read("name"), "AvaxCats - Team1 VN"));
check("symbol = 'ACAT'", eq(await read("symbol"), "ACAT"));
// ❓ Where do these 48n constants come from?
// → The contract declares COLLECTION_SIZE = MAX_SUPPLY = 48 (each cat is 1-of-1). The n suffix is because read() returns BigInt.
// → If you change the number of cats in the .sol you must change this test and cats.ts as well.
check("COLLECTION_SIZE = 48", eq(await read("COLLECTION_SIZE"), 48n));
check("MAX_SUPPLY = 48 (each cat is 1-of-1)", eq(await read("MAX_SUPPLY"), 48n));
check("totalMinted = 0", eq(await read("totalMinted"), 0n));
check("mintedBitmap = 0 before any mint", eq(await read("mintedBitmap"), 0n));

console.log("\n3. Alice mints the first cat");
const cat0 = CATS[0];
const uri0 = buildTokenURI(cat0);
const mintHash = await wallet(alice).writeContract({
  address,
  abi,
  functionName: "mint",
  args: [0n, uri0],
});
const mintReceipt = await pub.waitForTransactionReceipt({ hash: mintHash });
check("mint transaction succeeded", mintReceipt.status === "success");

// ❓ What does parseEventLogs do with receipt.logs?
// → receipt.logs are the raw logs (topics + hex data) of EVERY event in the transaction: both ERC721's Transfer and our Minted.
// → parseEventLogs uses the abi to filter exactly the eventName "Minted" and decode it into args { to, tokenId, catId }.
// → It is the only way to get the tokenId from a write transaction: the return value of mint() is not in the receipt.
const [minted] = parseEventLogs({
  abi,
  logs: mintReceipt.logs,
  eventName: "Minted",
});
check("Minted event emitted", Boolean(minted));
check("first tokenId = 1", eq(minted?.args.tokenId, 1n));
check("event.catId = 0", eq(minted?.args.catId, 0n));
check("event.to = Alice's wallet", eq(minted?.args.to, alice.address));
check("catOf(1) = 0", eq(await read("catOf", [1n]), 0n));
check("catMinted(0) = true", (await read("catMinted", [0n])) === true);
// ❓ Why is the bitmap 1 after minting cat 0?
// → The bitmap is a uint256 and bit i = 1 means cat i is minted. Minting cat 0 sets bit 0 → 0b1 = 1n.
// → After Bob mints cat 1 → 0b11 = 3n (section 5). After all 48 are minted → (1n << 48n) - 1n (section 8).
check("mintedBitmap has exactly bit 0 set", eq(await read("mintedBitmap"), 1n));
check("totalMinted = 1", eq(await read("totalMinted"), 1n));
check("ownerOf(1) = Alice", eq(await read("ownerOf", [1n]), alice.address));
check("balanceOf(Alice) = 1", eq(await read("balanceOf", [alice.address]), 1n));
console.log(`   ⛽ mint gas: ${mintReceipt.gasUsed} (tokenURI ${uri0.length} chars)`);

console.log("\n4. tokenURI read back from chain matches the submitted data 100%");
// ❓ What does section 4 prove?
// → The tokenURI read back from the chain must be IDENTICAL to the string we sent (byte-for-byte), then decoding base64 → JSON confirms name/image/attributes are intact.
// → There is no IPFS: all metadata is on-chain, read with eth_call.
const onchainURI = await read("tokenURI", [1n]);
check("tokenURI matches byte-for-byte", onchainURI === uri0);
const meta = JSON.parse(
  Buffer.from(
    onchainURI.replace("data:application/json;base64,", ""),
    "base64",
  ).toString(),
);
check("metadata.name is correct", eq(meta.name, `${cat0.name} - Team1 VN`));
check("metadata.image is a PNG data URI", meta.image.startsWith("data:image/png;base64,"));
check("metadata.attributes has all 12 layers", meta.attributes.length === cat0.attributes.length);

console.log("\n5. Bob mints the second cat: tokenId must increment, Alice's untouched");
const cat1 = CATS[1];
const mint2 = await pub.waitForTransactionReceipt({
  hash: await wallet(bob).writeContract({
    address,
    abi,
    functionName: "mint",
    args: [1n, buildTokenURI(cat1)],
  }),
});
const [minted2] = parseEventLogs({ abi, logs: mint2.logs, eventName: "Minted" });
check("second tokenId = 2", eq(minted2?.args.tokenId, 2n));
check("ownerOf(2) = Bob", eq(await read("ownerOf", [2n]), bob.address));
check("ownerOf(1) is still Alice", eq(await read("ownerOf", [1n]), alice.address));
check("totalMinted = 2", eq(await read("totalMinted"), 2n));
check("mintedBitmap = 0b11", eq(await read("mintedBitmap"), 3n));

console.log("\n6. Minting an already-owned cat AGAIN → must REVERT");
let dupReverted = false;
try {
  await wallet(bob).writeContract({
    address, abi, functionName: "mint", args: [0n, uri0],
  });
} catch (e) {
  // ❓ How do we know the transaction reverted for the right reason?
  // → viem simulates the transaction (eth_estimateGas) before sending; the contract reverts with the custom error CatAlreadyMinted(catId) → viem decodes the error name
  // → thanks to the abi and throws an exception. The test checks the exact error NAME, not just "there was an error", so it cannot pass by accident on another failure (for example out of gas).
  dupReverted = /CatAlreadyMinted/.test(String(e));
}
check("duplicate mint of cat #0 reverts CatAlreadyMinted", dupReverted);
check("totalMinted still = 2", eq(await read("totalMinted"), 2n));

console.log("\n7. catId outside the collection → must REVERT");
let oobReverted = false;
try {
  await wallet(bob).writeContract({
    address, abi, functionName: "mint", args: [48n, uri0],
  });
} catch (e) {
  oobReverted = /CatDoesNotExist/.test(String(e));
}
check("mint catId 48 reverts CatDoesNotExist", oobReverted);

console.log("\n8. Once the collection is sold out, no more mints allowed");
// ❓ Is it OK to loop sending 46 transactions without waiting for each receipt?
// → On anvil, yes: every tx is mined as it arrives and viem takes the next nonce from the pending count, so they land in order.
// → But the node answers eth_sendRawTransaction before the block is sealed, so we wait for the LAST receipt before reading state:
//   same sender and rising nonces mean everything before it is mined too. The goal here: sell out so the next mint has to revert.
let lastHash;
for (let i = 2; i < 48; i++) {
  lastHash = await wallet(alice).writeContract({
    address, abi, functionName: "mint", args: [BigInt(i), buildTokenURI(CATS[i])],
  });
}
await pub.waitForTransactionReceipt({ hash: lastHash });
check("totalMinted = 48", eq(await read("totalMinted"), 48n));
check("mintedBitmap = all 48 bits set", eq(await read("mintedBitmap"), (1n << 48n) - 1n));
let soldOut = false;
try {
  await wallet(bob).writeContract({
    address, abi, functionName: "mint", args: [7n, buildTokenURI(CATS[7])],
  });
} catch (e) {
  soldOut = /CatAlreadyMinted/.test(String(e));
}
check("minting after sell-out reverts", soldOut);

console.log("\n9. Nonexistent token must revert");
let reverted = false;
try {
  await read("ownerOf", [999n]);
} catch {
  reverted = true;
}
check("ownerOf(999) revert", reverted);

console.log(
  `\n${failures.length === 0 ? "🎉" : "💥"} ${passed} pass, ${failures.length} fail\n`,
);
// ❓ Why process.exit(1)?
// → A non-zero exit code is the standard "test failed" signal for npm/CI. Without this line the script always "succeeds" even when tests fail.
if (failures.length) {
  for (const f of failures) console.error("   ❌ " + f);
  process.exit(1);
}
