import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { createPublicClient, createWalletClient, formatEther, http } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { compile, ROOT } from "./compile.mjs";
import { ANVIL_PRIVATE_KEY, resolveNetwork } from "./chains.mjs";

const ENV_FILE = join(ROOT, ".env.local");
// ❓ How does the script know whether to deploy to anvil or Fuji?
// → resolveNetwork() (chains.mjs) reads the --network flag, a bare "fuji"/"anvil" argument, or NEXT_PUBLIC_CHAIN from env; the default is anvil.
// → It returns { key, chain, rpcUrl, explorer, label } so the whole script shares it.
const net = resolveNetwork();

// ❓ Why compile right here in deploy?
// → It guarantees the bytecode always matches the current AvaxCats.sol, so you never deploy a stale build. The abi + bytecode are also the only two things deploying needs.
const { abi, bytecode } = compile();

const envKey = process.env.DEPLOYER_PRIVATE_KEY ?? "";
// ❓ Where does the deploy private key come from, and why does anvil need no configuration?
// → DEPLOYER_PRIVATE_KEY in .env.local wins (it must be 0x + 64 hex). Without it on anvil, we use account #0's key
// → that anvil prints on start (public, only worth anything locally). On Fuji you must supply your own key, otherwise the script stops below.
const pk =
  /^0x[0-9a-fA-F]{64}$/.test(envKey)
    ? envKey
    : net.key === "anvil"
      ? ANVIL_PRIVATE_KEY
      : "";

if (!pk) {
  console.error(`
❌ Missing or invalid DEPLOYER_PRIVATE_KEY in .env.local (required when deploying to Fuji)

   1. Create a SEPARATE TESTNET wallet in Core/MetaMask (don't use your real wallet!)
   2. Get test AVAX: https://build.avax.network/console/primary-network/faucet
   3. Export that wallet's private key (Core: Settings → Show private key)
   4. Add to .env.local:  DEPLOYER_PRIVATE_KEY=0x...

   💡 Want a quick try without a wallet? Run locally: npm run anvil + npm run deploy:anvil
`);
  process.exit(1);
}

// ❓ What does privateKeyToAccount do?
// → It derives the public key → address from the private key (secp256k1 + keccak256) and builds an account object that can sign transactions right in Node.
// → No wallet extension needed: this is a "local account", the key lives in the process, so use it only for testnet/local.
const account = privateKeyToAccount(pk);
// ❓ Why does viem split publicClient and walletClient?
// → publicClient only READS through RPC (getChainId, getBalance, waiting for receipts) and needs no key. walletClient SENDS transactions and needs an account to sign.
// → The split makes it obvious from the code where a signature is needed. Both share the same http(rpcUrl) transport.
const publicClient = createPublicClient({
  chain: net.chain,
  transport: http(net.rpcUrl),
});
const walletClient = createWalletClient({
  account,
  chain: net.chain,
  transport: http(net.rpcUrl),
});

console.log(`🌐 Network: ${net.label}`);

let chainId;
try {
  // ❓ Why ask for the chainId when we already know the network?
  // → It is the first request to the RPC: if it fails you know straight away that anvil is not running or the network is down, and we print instructions instead of a confusing ECONNREFUSED.
  chainId = await publicClient.getChainId();
} catch {
  if (net.key === "anvil") {
    console.error(`
❌ Could not connect to anvil at ${net.rpcUrl}

   Open another terminal tab and run:   npm run anvil
   (port 8545 already in use? use:      ANVIL_PORT=8546 npm run anvil
    then add NEXT_PUBLIC_RPC_URL=http://127.0.0.1:8546 to .env.local)
`);
  } else {
    console.error(`❌ Could not connect to RPC ${net.rpcUrl}. Check your internet connection.`);
  }
  process.exit(1);
}

// ❓ Can the chainId the RPC returns differ from what we configured?
// → Yes, if port 8545 runs a different anvil (for example a mainnet fork). A transaction signed with chainId 31337 would be rejected by the node (EIP-155).
// → Failing early here with a clear message beats a vague error at deploy time.
if (chainId !== net.chain.id) {
  console.error(
    `❌ RPC ${net.rpcUrl} reports chainId ${chainId}, not ${net.chain.id}.\n` +
      "   You may be running a different anvil (forking another chain) on the same port.",
  );
  process.exit(1);
}

// ❓ Why check the balance before deploying?
// → Deploying costs gas paid in the deployer's AVAX. With a zero balance the RPC only returns a hard-to-read "insufficient funds";
// → checking first lets us point to where to get funds (the faucet for Fuji, restart anvil for local). The result is a BigInt in wei → formatEther to print it.
const balance = await publicClient.getBalance({ address: account.address });
console.log(`👛 Deployer: ${account.address} (${formatEther(balance)} AVAX)`);
if (balance === 0n) {
  console.error(
    net.key === "anvil"
      ? "❌ The anvil account has no funds?! Try restarting anvil."
      : "❌ Wallet has no test AVAX. Get some at: https://build.avax.network/console/primary-network/faucet",
  );
  process.exit(1);
}

console.log(`🚀 Deploying to ${net.chain.name} (${net.chain.id})…`);
// ❓ What does deploying a contract actually mean?
// → It is a special transaction: `to` is empty and `data` = the bytecode (+ constructor args encoded by the abi, none here).
// → walletClient signs it with the account and sends eth_sendRawTransaction. It returns the tx hash immediately: the contract is NOT on the chain yet.
const hash = await walletClient.deployContract({ abi, bytecode });
console.log("   tx:", hash);

// ❓ Where is the contract address?
// → You have to wait for the transaction to be mined; only the receipt has status ("success"/"reverted"), gasUsed and contractAddress.
// → The address is computed from (deployer address, nonce), so the node fills it into the receipt and we cannot choose it.
const receipt = await publicClient.waitForTransactionReceipt({ hash });
if (receipt.status !== "success") {
  console.error("❌ Deploy failed. Receipt status:", receipt.status);
  process.exit(1);
}
const address = receipt.contractAddress;
console.log(`
✅ DEPLOY SUCCESSFUL
   contract : ${address}
   gas used : ${receipt.gasUsed}${
     net.explorer ? `\n   explorer : ${net.explorer}/address/${address}` : ""
   }
`);

let env = existsSync(ENV_FILE) ? readFileSync(ENV_FILE, "utf8") : "";
// ❓ Why not overwrite the whole .env.local file?
// → .env.local may already hold the student's DEPLOYER_PRIVATE_KEY. upsert uses a regex with the m (multiline) flag to replace exactly the KEY=... line
// → if it exists and appends otherwise. Every other line is left alone.
const upsert = (key, value) => {
  const line = `${key}=${value}`;
  const re = new RegExp(`^${key}=.*$`, "m");
  env = re.test(env)
    ? env.replace(re, line)
    : env + (env === "" || env.endsWith("\n") ? "" : "\n") + line + "\n";
};
upsert("NEXT_PUBLIC_CHAIN", net.key);
upsert("NEXT_PUBLIC_CONTRACT_ADDRESS", address);
// ❓ What is writing to .env.local for?
// → The address stays on disk after the terminal scrolls away, and a front end can pick it up: Next.js reads NEXT_PUBLIC_* variables
// → at start-up and embeds them in the page, so a Next.js app in this folder knows the contract address + network without copy-pasting by hand.
writeFileSync(ENV_FILE, env);
console.log("📝 Wrote NEXT_PUBLIC_CHAIN + NEXT_PUBLIC_CONTRACT_ADDRESS to .env.local");
console.log("   → a Next.js front end in this folder reads them when it starts");
