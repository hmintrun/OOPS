import { spawn } from "node:child_process";
import { LOCAL_RPC_URL } from "./chains.mjs";

const url = new URL(LOCAL_RPC_URL);
// ❓ Where does the port come from?
// → ANVIL_PORT wins (for when 8545 is taken), then the port in NEXT_PUBLIC_RPC_URL, and the default is 8545:
// → anvil's own default port, which every script points at through chains.mjs.
const port = process.env.ANVIL_PORT || url.port || "8545";
const host = url.hostname || "127.0.0.1";

console.log(`⛓  anvil → http://${host}:${port} (chainId 31337)`);
console.log("   Keep this tab running. In another tab: npm run deploy:anvil\n");

// ❓ Why use spawn instead of calling anvil straight from package.json?
// → spawn runs the anvil binary as a child process and keeps it alive until you press Ctrl+C; stdio: "inherit" sends anvil's log
// → (10 accounts + private keys, every mined block) straight to the terminal. This wrapper also catches the "not installed" error below.
const child = spawn(
  "anvil",
  // ❓ What do you get when anvil starts?
  // → An EVM chain in RAM: 10 accounts each funded with 10000 (shown as AVAX), private keys printed to the terminal, chainId 31337,
  // → and "instant mining": every tx goes into a block at once, so waiting for a receipt is almost instant. Stopping anvil loses all state → deploy again.
  ["--host", host, "--port", port, "--chain-id", "31337"],
  { stdio: "inherit" },
);

child.on("error", (err) => {
  // ❓ What does ENOENT mean?
  // → "No such file": Node cannot find the `anvil` binary in PATH → Foundry is not installed. We catch it to print install steps instead of a stack trace.
  if (err.code === "ENOENT") {
    console.error(`
❌ anvil is not installed (it's part of the Foundry toolkit).

   macOS / Linux:
     curl -L https://foundry.paradigm.xyz | bash
     foundryup

   Windows: install via WSL, or see https://getfoundry.sh
`);
  } else {
    console.error(err);
  }
  process.exit(1);
});

// ❓ What is the last line for?
// → When anvil stops (Ctrl+C or a crash), the wrapper exits with the same exit code so npm and the terminal know the result.
child.on("exit", (code) => process.exit(code ?? 0));
