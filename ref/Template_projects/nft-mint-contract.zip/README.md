# Your first smart contract

An ERC-721 contract, `AvaxCats`, with small Node scripts that compile it, start a local chain, deploy it and test it. It is the same contract this site's UniTour mint page deploys. There is no Hardhat or Foundry project to learn: the scripts call the Solidity compiler and viem directly, and every step is explained in the comments.

## Run it
You need Node 22.9 or newer. The local chain is anvil, which is part of Foundry (getfoundry.sh). If it is missing, `npm run anvil` prints the install commands.

```bash
npm install
npm run compile        # contracts/AvaxCats.sol -> ABI + bytecode
npm run anvil          # local chain on 127.0.0.1:8545, leave this tab running
```

In a second terminal:

```bash
npm run deploy:anvil   # deploys and prints the contract address
npm test               # deploys a fresh copy and runs 34 checks
```

## Deploy to Fuji
1. Make a separate testnet wallet in Core and copy its private key.
2. Get free test AVAX. [The faucet page](https://team1vn.xyz/faucet.html) shows how.
3. Create a file named `.env.local` in this folder with the line below, then run the deploy.

```bash
DEPLOYER_PRIVATE_KEY=0xYourTestnetPrivateKey
```

```bash
npm run deploy:fuji
```

The script checks the balance, deploys, and prints the contract address with a Snowtrace link. Deploying uses about 1.2 million gas.

## Where to look
- `contracts/AvaxCats.sol` is the contract: 48 cats, each can be minted once, metadata stored on-chain.
- `scripts/compile.mjs` runs the compiler, `scripts/deploy.mjs` sends the deploy transaction, `scripts/test-contract.mjs` is the test.
- `scripts/chains.mjs` picks the network: local by default, Fuji with `--network fuji`.
- `src/lib/cats.ts` is the collection data (names, traits and tiny PNG images) that the test mints.

## Watch out
- `.env.local` holds a private key. Use a wallet made only for the testnet, never one with real funds, and keep `.env.local` out of git.
- `npm test` only runs on the local chain, because it deploys a new contract and mints all 48 cats.
- anvil keeps the chain in memory. Stop it and the contract is gone, so deploy again.
- If port 8545 is busy, put `NEXT_PUBLIC_RPC_URL=http://127.0.0.1:8546` in `.env.local`. anvil and every script read it.
- Anyone can mint any cat that is still free. The contract has no owner, no price and no limit per wallet, which is fine for a workshop and not for a real launch.
- Keeping the image on-chain makes one mint cost about 1.66 million gas.
- The deploy script also writes the network and contract address to `.env.local`, so a Next.js front end in the same folder can read them.

## Make it yours
Change the name and symbol in the constructor, add a mint price or a limit per wallet, then build a front end for it (see *Connect a wallet* and *Read and write a contract from the UI*). If you change the number of cats, change `src/lib/cats.ts` and the test too.
