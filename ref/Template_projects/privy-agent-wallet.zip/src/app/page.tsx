import { AgentDemo } from "@/components/AgentDemo";
import { APP_ID_STATE } from "@/lib/app-id";

export default function Page() {
  return (
    <main>
      <h1>Privy agent wallet on Avalanche</h1>
      <p className="lead">
        Sign in, get a wallet, then let an agent on the server send small amounts of AVAX for you. It works on the Fuji
        testnet and on C-Chain mainnet.
      </p>
      {APP_ID_STATE === "ok" ? (
        <AgentDemo />
      ) : (
        <section className="card">
          <h2>Set up Privy first</h2>
          {APP_ID_STATE === "malformed" && (
            <p className="err">
              <code>NEXT_PUBLIC_PRIVY_APP_ID</code> in <code>.env.local</code> does not look right: a Privy app ID is 25
              characters long. Copy it again from the Dashboard.
            </p>
          )}
          <p>
            This app has no usable Privy app ID yet. Copy <code>.env.example</code> to <code>.env.local</code>, fill in{" "}
            <code>NEXT_PUBLIC_PRIVY_APP_ID</code> and <code>PRIVY_APP_SECRET</code>, run <code>npm run setup-agent</code>,
            then restart <code>npm run dev</code>.
          </p>
          <p className="muted">
            <code>docs/privy-setup.md</code> shows how to sign up for Privy and where to find both values.
          </p>
        </section>
      )}
    </main>
  );
}
