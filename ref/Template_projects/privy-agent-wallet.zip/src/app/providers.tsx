"use client";

import { PrivyProvider } from "@privy-io/react-auth";
import { avalanche, avalancheFuji } from "viem/chains";
import { APP_ID_STATE, PRIVY_APP_ID } from "@/lib/app-id";

export function Providers({ children }: { children: React.ReactNode }) {
  // Without a usable app ID the page shows the setup steps instead (see page.tsx), and Privy is not loaded.
  if (APP_ID_STATE !== "ok") return <>{children}</>;
  return (
    <PrivyProvider
      appId={PRIVY_APP_ID}
      config={{
        // ❓ What do defaultChain and supportedChains do?
        // → supportedChains is the list of networks a wallet may use in this app; anything else throws.
        //   defaultChain is where a new wallet starts. Fuji first, so nobody starts on real money by accident.
        defaultChain: avalancheFuji,
        supportedChains: [avalancheFuji, avalanche],
        // ❓ Why "all-users"?
        // → Every person who signs in gets an embedded wallet at once, also those who sign in with their
        //   own wallet. The agent can only be added to an embedded wallet, so everyone needs one.
        embeddedWallets: { ethereum: { createOnLogin: "all-users" } },
      }}
    >
      {children}
    </PrivyProvider>
  );
}
