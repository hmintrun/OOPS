import { APIError, isEmbeddedWalletLinkedAccount } from "@privy-io/node";
import { createViemAccount } from "@privy-io/node/viem";
import { createWalletClient, http, isAddress, parseEther, type Hex } from "viem";
import { isNetworkKey, NETWORKS, txUrl } from "@/lib/chains";
import { agentConfig, missingSettings, privy } from "@/lib/privy-server";

const fail = (status: number, error: string, message: string) => Response.json({ ok: false, error, message }, { status });

// POST /api/agent/send   { network: "fuji" | "mainnet", to: "0x…", amount: "0.001" }
// The agent sends AVAX from the signed-in user's wallet. The user is not asked to confirm:
// they agreed once, when they turned the agent on, and the policy at Privy limits what can happen.
export async function POST(request: Request) {
  const missing = missingSettings();
  if (missing.length) return fail(503, "not_configured", `Missing in .env.local: ${missing.join(", ")}`);

  // ❓ Why verify a token when the page already knows who is signed in?
  // → Anyone can call this URL with any body. The access token is a JWT signed by Privy; checking its
  //   signature here is the only proof of WHICH user is asking. The user id comes from the token,
  //   never from the request body.
  const token = request.headers.get("authorization")?.replace(/^Bearer /i, "") ?? "";
  let userId: string;
  try {
    userId = (await privy().utils().auth().verifyAccessToken(token)).user_id;
  } catch {
    return fail(401, "unauthorized", "Sign in again.");
  }

  const body = (await request.json().catch(() => null)) as { network?: unknown; to?: unknown; amount?: unknown } | null;
  if (!isNetworkKey(body?.network)) return fail(400, "bad_network", 'network must be "fuji" or "mainnet".');
  if (typeof body.to !== "string" || !isAddress(body.to)) return fail(400, "bad_address", "That recipient address is not valid.");
  let value: bigint;
  try {
    value = parseEther(String(body.amount ?? ""));
  } catch {
    return fail(400, "bad_amount", "amount must be a number of AVAX, for example 0.001.");
  }
  if (value <= 0n) return fail(400, "bad_amount", "amount must be more than 0.");
  // ❓ Why is the amount not compared with AGENT_MAX_AVAX here?
  // → On purpose. The limit lives in the policy at Privy, which checks every signature inside its
  //   secure enclave. A check in this file would only protect against honest mistakes; the policy
  //   still holds if this server is buggy or taken over. Ask for too much and Privy refuses below.

  // Find this user's embedded wallet, and make sure they turned the agent on for it.
  const user = await privy().users()._get(userId);
  const wallet = user.linked_accounts.find(
    (account) => isEmbeddedWalletLinkedAccount(account) && account.chain_type === "ethereum",
  );
  if (!wallet || !isEmbeddedWalletLinkedAccount(wallet) || !wallet.id) return fail(409, "no_wallet", "This account has no embedded wallet yet.");
  if (!wallet.delegated) return fail(409, "agent_off", "The agent is turned off for this wallet.");

  const network = NETWORKS[body.network];
  try {
    // ❓ What does createViemAccount give us?
    // → A viem account whose signing is done by Privy. viem prepares the transaction (nonce, gas, fees)
    //   and broadcasts it through the chain's RPC; only the signature is requested from Privy, signed
    //   with the agent's key so Privy knows the request comes from the signer the user approved.
    //   Because viem does the broadcast, this works on any EVM chain, Fuji and C-Chain included.
    const account = createViemAccount(privy(), {
      walletId: wallet.id,
      address: wallet.address as Hex,
      authorizationContext: { authorization_private_keys: [agentConfig.privateKey] },
    });
    const client = createWalletClient({ account, chain: network.chain, transport: http() });
    const hash = await client.sendTransaction({ to: body.to, value });
    return Response.json({ ok: true, hash, explorer: txUrl(network.key, hash), network: network.key });
  } catch (e) {
    // Privy answers with an API error when the policy refuses or the signer was removed.
    // viem throws when the chain refuses, for example when the wallet cannot pay for the transfer.
    if (e instanceof APIError) return fail(403, "privy_refused", `Privy refused to sign: ${e.message}`);
    const message = e instanceof Error ? ((e as { shortMessage?: string }).shortMessage ?? e.message) : "unknown error";
    return fail(502, "send_failed", message);
  }
}
