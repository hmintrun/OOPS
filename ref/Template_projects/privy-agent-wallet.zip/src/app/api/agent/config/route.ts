import { agentConfig, missingSettings } from "@/lib/privy-server";

// GET /api/agent/config
// Tells the page what the agent is, so the page can ask the user to add it as a signer.
// Everything returned here is public: ids, not keys.
export async function GET() {
  const missing = missingSettings();
  return Response.json({
    configured: missing.length === 0,
    missing,
    signerId: agentConfig.signerId,
    policyId: agentConfig.policyId,
    maxAvax: agentConfig.maxAvax,
    allowedTo: agentConfig.allowedTo,
  });
}
