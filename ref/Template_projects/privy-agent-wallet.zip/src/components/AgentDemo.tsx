"use client";

import { usePrivy, useSigners, type WalletWithMetadata } from "@privy-io/react-auth";
import { useCallback, useEffect, useState } from "react";
import { createPublicClient, formatEther, http } from "viem";
import { addressUrl, NETWORKS, type NetworkKey } from "@/lib/chains";

type AgentConfig = { configured: boolean; missing: string[]; signerId: string; policyId: string; maxAvax: string; allowedTo: string[] };
type Result = { kind: "ok" | "err" | "info"; text: string; link?: string };

// Balances are read straight from each network's public RPC, so they do not depend on the wallet being connected.
const readers = {
  fuji: createPublicClient({ chain: NETWORKS.fuji.chain, transport: http() }),
  mainnet: createPublicClient({ chain: NETWORKS.mainnet.chain, transport: http() }),
};

export function AgentDemo() {
  const { ready, authenticated, user, login, logout, getAccessToken } = usePrivy();
  const { addSigners, removeSigners } = useSigners();
  const [config, setConfig] = useState<AgentConfig | null>(null);
  const [network, setNetwork] = useState<NetworkKey>("fuji");
  const [balance, setBalance] = useState<string | null>(null);
  const [to, setTo] = useState("");
  const [amount, setAmount] = useState("0.0005");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [slow, setSlow] = useState(false);

  // ❓ Which wallet is "the" wallet here?
  // → The embedded Ethereum wallet Privy created at sign-in. A user can also link MetaMask or Core, but
  //   the agent can only be added to the embedded one, because that is the wallet Privy can sign for.
  const wallet = user?.linkedAccounts.find(
    (a): a is WalletWithMetadata => a.type === "wallet" && a.walletClientType === "privy" && a.chainType === "ethereum",
  );
  // `delegated` is true while at least one signer is on the wallet. This app only ever adds the agent.
  const agentOn = wallet?.delegated === true;

  // Privy stays "not ready" for ever when it cannot load the app, for example with a wrong app ID.
  useEffect(() => {
    if (ready) return;
    const timer = setTimeout(() => setSlow(true), 8000);
    return () => clearTimeout(timer);
  }, [ready]);

  useEffect(() => {
    fetch("/api/agent/config").then((r) => r.json()).then(setConfig).catch(() => setConfig(null));
  }, []);

  const refreshBalance = useCallback(async () => {
    if (!wallet) return setBalance(null);
    try {
      const wei = await readers[network].getBalance({ address: wallet.address as `0x${string}` });
      setBalance(Number(formatEther(wei)).toFixed(4));
    } catch {
      setBalance(null);
    }
  }, [wallet, network]);

  useEffect(() => {
    setBalance(null);
    refreshBalance();
  }, [refreshBalance]);

  // Runs one action with the buttons disabled, and turns a thrown error into a message.
  const run = async (action: () => Promise<Result | void>) => {
    setBusy(true);
    setResult(null);
    try {
      setResult((await action()) ?? null);
    } catch (e) {
      setResult({ kind: "err", text: e instanceof Error ? e.message : "Something went wrong." });
    } finally {
      setBusy(false);
    }
  };

  // ❓ What happens when the user turns the agent on?
  // → addSigners asks Privy to add the agent's key quorum as a signer on THIS wallet, tied to the policy.
  //   From then on the server can ask Privy to sign for the wallet without the user, but only requests
  //   that pass the policy. The private key of the wallet never leaves Privy and the server never sees it.
  const turnOn = () =>
    run(async () => {
      if (!wallet || !config) return;
      await addSigners({ address: wallet.address, signers: [{ signerId: config.signerId, policyIds: [config.policyId] }] });
      return { kind: "ok", text: "The agent is on. It can now sign for this wallet inside its policy." };
    });

  // Removes every signer, so only the user can use the wallet again. It takes effect at once.
  const turnOff = () =>
    run(async () => {
      if (!wallet) return;
      await removeSigners({ address: wallet.address });
      return { kind: "info", text: "The agent is off. Only you can use this wallet now." };
    });

  const askAgent = () =>
    run(async () => {
      // The access token proves to the server who is asking. Privy refreshes it when it is close to expiring.
      const token = await getAccessToken();
      const res = await fetch("/api/agent/send", {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
        body: JSON.stringify({ network, to: to.trim(), amount: amount.trim() }),
      });
      const data = await res.json();
      if (!data.ok) return { kind: "err", text: data.message || data.error };
      refreshBalance();
      return { kind: "ok", text: `The agent sent ${amount.trim()} AVAX on ${NETWORKS[network].label}.`, link: data.explorer };
    });

  if (!ready) {
    return (
      <section className="card">
        {slow ? (
          <p className="err">
            Privy has not loaded. Check that <code>NEXT_PUBLIC_PRIVY_APP_ID</code> in <code>.env.local</code> is the app ID
            from the Dashboard, and that this address is allowed if you listed allowed origins there.
          </p>
        ) : (
          <p className="muted">Loading Privy…</p>
        )}
      </section>
    );
  }

  if (!authenticated || !user) {
    return (
      <section className="card">
        <h2>1. Sign in</h2>
        <p className="muted">Privy creates a wallet for you the first time you sign in. There is no seed phrase to write down.</p>
        <button className="primary" onClick={() => login()}>Sign in with Privy</button>
      </section>
    );
  }

  const net = NETWORKS[network];
  return (
    <>
      <section className="card">
        <h2>1. Signed in</h2>
        <dl>
          <dt>User</dt>
          <dd className="mono">{user.email?.address ?? user.google?.email ?? user.id}</dd>
          <dt>Wallet</dt>
          <dd className="mono">
            {wallet ? <a href={addressUrl(network, wallet.address)} target="_blank" rel="noreferrer">{wallet.address}</a> : "being created…"}
          </dd>
        </dl>
        <button onClick={() => logout()}>Sign out</button>
      </section>

      <section className="card">
        <h2>2. Network</h2>
        <div className="row">
          <div className="tabs">
            {(Object.keys(NETWORKS) as NetworkKey[]).map((key) => (
              <button key={key} className={key === network ? "on" : ""} onClick={() => setNetwork(key)}>
                {NETWORKS[key].label}
              </button>
            ))}
          </div>
          <span>Balance: <b>{balance ?? "…"} AVAX</b></span>
          <button onClick={refreshBalance}>Refresh</button>
        </div>
        <p className={net.realMoney ? "warn status" : "muted status"}>
          {net.realMoney
            ? "C-Chain mainnet uses real AVAX. Send only what you can afford to lose."
            : "Fuji is a test network. Send test AVAX to the wallet address above from a faucet."}
        </p>
      </section>

      <section className="card">
        <h2>
          3. Agent <span className={agentOn ? "pill on" : "pill"}>{agentOn ? "on" : "off"}</span>
        </h2>
        {!config?.configured ? (
          <p className="err">
            The agent is not set up on the server{config ? ` (missing: ${config.missing.join(", ")})` : ""}. Run{" "}
            <code>npm run setup-agent</code> and restart <code>npm run dev</code>.
          </p>
        ) : (
          <>
            <p className="muted">
              When it is on, the server can sign for this wallet without asking you, but only transfers of at most{" "}
              <b>{config.maxAvax} AVAX</b> each, on Fuji and C-Chain
              {config.allowedTo.length ? `, to ${config.allowedTo.join(", ")}` : ""}. Privy checks this rule on every
              signature. You can turn it off at any time.
            </p>
            <button className={agentOn ? "" : "primary"} disabled={busy || !wallet} onClick={agentOn ? turnOff : turnOn}>
              {agentOn ? "Turn the agent off" : "Turn the agent on"}
            </button>
          </>
        )}
      </section>

      <section className="card">
        <h2>4. Ask the agent to send AVAX</h2>
        <p className="muted">The request goes to this app's server, which signs with the agent's key. You are not asked to confirm.</p>
        <label htmlFor="to">Recipient address</label>
        <input id="to" value={to} onChange={(e) => setTo(e.target.value)} placeholder="0x…" spellCheck={false} autoComplete="off" />
        <label htmlFor="amount">Amount in AVAX on {net.label}</label>
        <input id="amount" value={amount} onChange={(e) => setAmount(e.target.value)} inputMode="decimal" />
        <div className="row" style={{ marginTop: 14 }}>
          <button className="primary" disabled={busy || !agentOn || !to.trim()} onClick={askAgent}>
            {busy ? "Working…" : "Ask the agent to send"}
          </button>
          {!agentOn && <span className="muted">Turn the agent on first.</span>}
        </div>
        <p className={`status ${result?.kind ?? ""}`} role="status">
          {result?.text}{" "}
          {result?.link && <a href={result.link} target="_blank" rel="noreferrer">View the transaction</a>}
        </p>
      </section>
    </>
  );
}
