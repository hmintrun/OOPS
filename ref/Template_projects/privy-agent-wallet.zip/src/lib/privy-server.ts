import "server-only";
import { PrivyClient } from "@privy-io/node";

// Everything in this file runs on the server only. The `server-only` import makes the build fail
// if a client component ever imports it, so the secrets below cannot leak into the browser bundle.

const env = (name: string) => (process.env[name] ?? "").trim();

export const agentConfig = {
  appId: env("NEXT_PUBLIC_PRIVY_APP_ID"),
  appSecret: env("PRIVY_APP_SECRET"),
  /** Key quorum id. The user adds THIS as a signer on their wallet when they turn the agent on. */
  signerId: env("PRIVY_AGENT_SIGNER_ID"),
  /** The policy every agent request must satisfy. Stored and enforced by Privy. */
  policyId: env("PRIVY_AGENT_POLICY_ID"),
  /** P-256 private key that proves a request comes from the agent. */
  privateKey: env("PRIVY_AGENT_PRIVATE_KEY"),
  maxAvax: env("AGENT_MAX_AVAX") || "0.01",
  allowedTo: env("AGENT_ALLOWED_TO").split(",").map((a) => a.trim()).filter(Boolean),
};

/** Names of the settings that are still empty, in the order you fill them in. */
export function missingSettings(): string[] {
  const need: [string, string][] = [
    ["NEXT_PUBLIC_PRIVY_APP_ID", agentConfig.appId],
    ["PRIVY_APP_SECRET", agentConfig.appSecret],
    ["PRIVY_AGENT_SIGNER_ID", agentConfig.signerId],
    ["PRIVY_AGENT_POLICY_ID", agentConfig.policyId],
    ["PRIVY_AGENT_PRIVATE_KEY", agentConfig.privateKey],
  ];
  return need.filter(([, value]) => !value).map(([name]) => name);
}

// ❓ Why keep one client in a module variable?
// → The client caches Privy's token verification key after the first request. Building a new client
//   per request would fetch that key again every time.
let client: PrivyClient | null = null;

export function privy(): PrivyClient {
  if (!client) client = new PrivyClient({ appId: agentConfig.appId, appSecret: agentConfig.appSecret });
  return client;
}
