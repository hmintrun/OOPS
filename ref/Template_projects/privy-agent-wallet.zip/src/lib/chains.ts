import { avalanche, avalancheFuji } from "viem/chains";

// ❓ Why do both networks live in one list?
// → An address is the same on Fuji and on C-Chain, so one Privy wallet works on both. The only thing
//   that changes is which chain a transaction is built for. Every place that needs a network
//   (the page, the API route, the policy) reads it from here.
export const NETWORKS = {
  fuji: {
    key: "fuji",
    label: "Fuji testnet",
    chain: avalancheFuji, // chain id 43113
    explorer: "https://testnet.snowtrace.io",
    realMoney: false,
  },
  mainnet: {
    key: "mainnet",
    label: "C-Chain mainnet",
    chain: avalanche, // chain id 43114
    explorer: "https://snowtrace.io",
    realMoney: true,
  },
} as const;

export type NetworkKey = keyof typeof NETWORKS;

export const isNetworkKey = (v: unknown): v is NetworkKey => v === "fuji" || v === "mainnet";

/** The chain ids the agent's policy allows, as the strings Privy's policy engine compares against. */
export const AGENT_CHAIN_IDS = [String(avalancheFuji.id), String(avalanche.id)];

export const txUrl = (network: NetworkKey, hash: string) => `${NETWORKS[network].explorer}/tx/${hash}`;
export const addressUrl = (network: NetworkKey, address: string) => `${NETWORKS[network].explorer}/address/${address}`;
