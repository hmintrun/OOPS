// The Privy app ID is public: every browser that opens the page receives it. The app secret is not here.
export const PRIVY_APP_ID = (process.env.NEXT_PUBLIC_PRIVY_APP_ID ?? "").trim();

// ❓ Why check the length?
// → A Privy app ID is exactly 25 characters, and PrivyProvider throws on anything else, which would
//   replace the whole page with an error screen. Checking first lets the page explain what to fix.
export const APP_ID_STATE: "missing" | "malformed" | "ok" = !PRIVY_APP_ID ? "missing" : PRIVY_APP_ID.length !== 25 ? "malformed" : "ok";
