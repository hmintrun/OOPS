import type { NextConfig } from "next";

// ❓ Why is there no `output: "export"` here, unlike a static site?
// → This app has API routes (src/app/api/agent/*) that hold the app secret and the agent's key.
//   They need a server, so it runs with `next dev` / `next start` or on a host that runs Next.js.
const nextConfig: NextConfig = {};

export default nextConfig;
