# Privy login and an agent wallet on Avalanche

A Next.js app. A person signs in with Privy and gets an embedded wallet with no seed phrase to write down. With one button they let an agent on your server sign for that wallet, inside a policy that Privy enforces: small AVAX transfers, on Fuji and on C-Chain mainnet only. They can turn the agent off again at any time.

## Run it
You need Node 22.9 or newer and a Privy account. `docs/privy-setup.md` shows how to sign up and where to find the two values for step 2.

1. Install the packages and copy `.env.example` to `.env.local`.
2. Put your Privy app ID and app secret in `.env.local`.
3. Create the agent. This registers a key and a policy in your Privy app and writes their ids into `.env.local`.
4. Start the app and open http://localhost:3000.

```bash
npm install
cp .env.example .env.local
npm run setup-agent
npm run dev
```

In the app, sign in and copy the wallet address it shows. Send it some test AVAX ([this site's faucet page](https://team1vn.xyz/faucet.html) shows how), press **Turn the agent on**, then ask the agent to send a small amount, for example 0.0005 AVAX, to any address. With more than 0.02 AVAX in the wallet you can also ask for 0.02: the policy at Privy should refuse to sign, because it stops at 0.01.

## Testnet and mainnet
The switch on the page picks Fuji or C-Chain. The wallet has the same address on both, and the agent works on both with the same policy. On C-Chain it moves real AVAX, so fund the wallet with very little.

## Where to look
- `scripts/setup-agent.mjs` creates the agent: a key pair, a key quorum (the "signer" a user adds to their wallet) and the policy.
- `src/app/providers.tsx` sets up Privy: both Avalanche networks, and an embedded wallet for everyone who signs in.
- `src/components/AgentDemo.tsx` is the page: sign in, turn the agent on with `addSigners`, turn it off with `removeSigners`.
- `src/app/api/agent/send/route.ts` is the agent. It checks who is asking, then signs with Privy and sends through viem.
- `src/lib/chains.ts` lists the two networks.

## Watch out
- **Not run against a live Privy app yet.** The build passes and the server answers correctly without credentials, but the sign-in, the agent switch and a real transfer have not been tried with a real Privy account. Test on Fuji before you rely on it.
- `.env.local` holds the app secret and the agent's private key. With both, a server can sign for every wallet that turned the agent on, inside the policy. Never commit that file.
- The limit is for one transaction, not for a day. An agent in a loop can send 0.01 AVAX many times. Privy's [stateful policies](https://docs.privy.io/controls/policies/stateful-policies) can cap a total over time.
- A policy cannot see whether a transaction carries calldata. The rule "more than 0 AVAX" stops standard token transfers, because token contracts reject a call that carries AVAX, but it is not a proof. To be strict, list the addresses the agent may pay in `AGENT_ALLOWED_TO` and run `npm run setup-agent -- --force`.
- The user trusts your server. They approve a signer and a policy id, and whoever holds the agent's key can change that policy's rules later. Tell your users plainly what the agent may do.
- `npm run setup-agent -- --force` makes a new agent. Everyone who had the agent on has to turn it on again.
- The app has API routes, so it needs a host that runs Next.js. It cannot be exported as a static site.
- Privy's React SDK imports its Solana helpers even in an Avalanche-only app. The three `@solana` packages in `package.json` are only there so the build can resolve them.

## Make it yours
Replace the body of `src/app/api/agent/send/route.ts` with what your agent should do: call a contract, pay for an API, or act when an AI model decides to. Change the policy in `scripts/setup-agent.mjs` first, so the agent can do that and nothing more.
