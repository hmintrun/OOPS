# Sign up for Privy and get your keys

Privy is the service that signs your users in and keeps their wallets. To run this starter you need a Privy account and one app in it. It is free to start: when this was written the free plan covered up to 499 monthly active users. Check [the pricing page](https://www.privy.io/pricing) for the current limits.

## 1. Create an account and an app
1. Open [dashboard.privy.io](https://dashboard.privy.io) and sign up.
2. Create a new app and give it any name, for example "agent wallet dev".

Privy suggests one app for each environment, so make a second app later for production. Users, wallets, keys and policies all belong to one app and are not shared between apps.

## 2. Copy the app ID and the app secret
In the Dashboard, open **Configuration > App settings > Basics**. You need two values from it.

- **App ID**. It is public. Put it in `.env.local` as `NEXT_PUBLIC_PRIVY_APP_ID`.
- **App secret**. It is private. Put it in `.env.local` as `PRIVY_APP_SECRET` and never in code or in git. Privy does not keep a copy, so if you lose it you have to generate a new one.

## 3. Choose how people sign in
Open **User management > Authentication** and turn on at least one login method. Email is the simplest: Privy sends a one-time code and there is nothing else to set up. You can add Google, passkeys or wallets on the same page later.

## 4. Turn on a test account (optional)
A test account lets you sign in without a real inbox. On **User management > Authentication > Advanced**, turn on **Enable test accounts**. The Dashboard then shows a test email that looks like `test-1234@privy.io` and a fixed code. Use them in the app's sign-in window.

## 5. Create the agent
Back in the project folder, run the command below. It makes a key on your machine, registers it in your Privy app and creates the agent's policy.

```bash
npm run setup-agent
```

Afterwards both are visible in the Dashboard under **Wallet infrastructure**: the key on the **Authorization keys** page and the rules on the **Policies** page.

## 6. Before you go live
While you work on localhost you can leave allowed origins empty. Before a launch, open **Configuration > App settings > Domains** and list the origins that may use your app ID.

- Write the full origin with `https`, and no path: `https://your-domain.example`.
- If you list anything here and still develop locally, add `http://localhost:3000` too, with the port.
- Do not allow a whole hosting domain such as `https://*.vercel.app`. Anyone can deploy there and use your app ID.

On the host, store `PRIVY_APP_SECRET` and `PRIVY_AGENT_PRIVATE_KEY` as secrets, not as plain settings.

## If something fails
- `npm run setup-agent` says the app ID is invalid: copy the app ID and the app secret again from step 2. They must come from the same app.
- The page says Privy has not loaded: the app ID is wrong, or allowed origins are set and do not include the address you opened.
- Wallets do not work on a plain `http` address. Privy's embedded wallets need `https`, with `localhost` as the only exception, so open the app as http://localhost:3000 while you develop.
- The sign-in window offers nothing to click: no login method is turned on (step 3).
- The agent button gives an error after you ran `setup-agent` again: the page still has the old ids. Restart `npm run dev`.
