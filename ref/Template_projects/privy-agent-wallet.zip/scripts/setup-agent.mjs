// Creates the agent for this app. Run it once: `npm run setup-agent`.
//
// ❓ What is "the agent" in Privy's terms?
// → Three things, all created here:
//   1. A P-256 key pair. The private key stays in .env.local; your server signs its requests with it.
//   2. A key quorum at Privy that holds the public key. Its id is the "signer" a user adds to their wallet.
//   3. A policy at Privy: the rules every request from this signer must pass before Privy signs anything.
//   A user who turns the agent on is saying "this signer may use my wallet, inside this policy".
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { APIError, PrivyClient, generateP256KeyPair } from "@privy-io/node";
import { formatEther, isAddress, parseEther, toHex } from "viem";

const ENV_FILE = ".env.local";
const env = (name) => (process.env[name] ?? "").trim();
const stop = (message) => { console.error(`\n✗ ${message}\n`); process.exit(1); };

const appId = env("NEXT_PUBLIC_PRIVY_APP_ID");
const appSecret = env("PRIVY_APP_SECRET");
if (!appId || !appSecret) {
  stop(`NEXT_PUBLIC_PRIVY_APP_ID and PRIVY_APP_SECRET must be set in ${ENV_FILE}.\n  docs/privy-setup.md shows how to sign up for Privy and where to find them.`);
}

// ❓ Why refuse to run twice?
// → A second run makes a NEW key and a NEW signer id. Wallets that turned the agent on hold the old id,
//   so the agent would stop working for them until they turn it on again. Pass --force when you mean it,
//   for example after changing AGENT_MAX_AVAX.
if (env("PRIVY_AGENT_SIGNER_ID") && !process.argv.includes("--force")) {
  stop(`The agent already exists (PRIVY_AGENT_SIGNER_ID is set in ${ENV_FILE}).\n  To replace it, run: npm run setup-agent -- --force\n  Users will then have to turn the agent on again.`);
}

let maxWei;
try {
  maxWei = parseEther(env("AGENT_MAX_AVAX") || "0.01");
} catch {
  stop("AGENT_MAX_AVAX must be a number of AVAX, for example 0.01.");
}
if (maxWei <= 0n) stop("AGENT_MAX_AVAX must be more than 0.");

const allowedTo = env("AGENT_ALLOWED_TO").split(",").map((a) => a.trim()).filter(Boolean);
const badAddress = allowedTo.find((a) => !isAddress(a));
if (badAddress) stop(`AGENT_ALLOWED_TO contains "${badAddress}", which is not an address.`);

// ❓ How does Privy read these rules?
// → A request is allowed only when it satisfies EVERY condition of an ALLOW rule. Anything that matches
//   no rule is denied, and so is every method the policy does not mention (signing messages, exporting
//   the key…). The server in this starter asks Privy to sign a transaction and broadcasts it itself,
//   so the one method the agent needs is eth_signTransaction.
const conditions = [
  // Only the two Avalanche networks: Fuji (43113) and C-Chain (43114). Keep in step with src/lib/chains.ts.
  { field_source: "ethereum_transaction", field: "chain_id", operator: "in", value: ["43113", "43114"] },
  // Never more than the cap in one transaction…
  { field_source: "ethereum_transaction", field: "value", operator: "lte", value: toHex(maxWei) },
  // …and never zero. ❓ Why forbid zero?
  // → A policy cannot look at "is there calldata". A token transfer is a call with value 0, so without
  //   this line the agent could move any ERC-20 in the wallet. Standard token contracts reject a call
  //   that carries AVAX, which makes this a strong hint, not a proof: see "Watch out" in the README.
  { field_source: "ethereum_transaction", field: "value", operator: "gt", value: "0x0" },
];
if (allowedTo.length) conditions.push({ field_source: "ethereum_transaction", field: "to", operator: "in", value: allowedTo });

const privy = new PrivyClient({ appId, appSecret });

try {
  console.log("1/3  Making a key pair on this machine…");
  const { privateKey, publicKey } = await generateP256KeyPair();

  console.log("2/3  Registering the public key with Privy as a key quorum…");
  const quorum = await privy.keyQuorums().create({
    display_name: "Agent (privy-agent-wallet starter)",
    authorization_threshold: 1,
    public_keys: [publicKey],
  });

  console.log("3/3  Creating the policy…");
  const policy = await privy.policies().create({
    name: `Agent: up to ${formatEther(maxWei)} AVAX per transaction on Avalanche`,
    version: "1.0",
    chain_type: "ethereum",
    rules: [{ name: "Small AVAX transfers on Fuji and C-Chain", method: "eth_signTransaction", action: "ALLOW", conditions }],
    // ❓ Why give the policy an owner?
    // → Without one, the app secret alone can rewrite the rules. With the key quorum as owner, a change
    //   must also be signed with the agent's private key.
    owner_id: quorum.id,
  });

  // Write the three values into .env.local without touching the other lines.
  let file = existsSync(ENV_FILE) ? readFileSync(ENV_FILE, "utf8") : "";
  const upsert = (key, value) => {
    const line = `${key}=${value}`;
    const re = new RegExp(`^${key}=.*$`, "m");
    file = re.test(file) ? file.replace(re, line) : file + (file === "" || file.endsWith("\n") ? "" : "\n") + line + "\n";
  };
  upsert("PRIVY_AGENT_SIGNER_ID", quorum.id);
  upsert("PRIVY_AGENT_POLICY_ID", policy.id);
  upsert("PRIVY_AGENT_PRIVATE_KEY", privateKey);
  writeFileSync(ENV_FILE, file);

  console.log(`
✓ The agent exists.
   signer (key quorum) : ${quorum.id}
   policy              : ${policy.id}
   it may sign         : transfers of more than 0 and at most ${formatEther(maxWei)} AVAX, on Fuji and C-Chain${allowedTo.length ? `, only to ${allowedTo.join(", ")}` : ", to any address"}
   written to          : ${ENV_FILE} (the private key is in there: never commit that file)

Start the app with \`npm run dev\`. If it is already running, restart it so it reads the new values.
Both show in the Privy Dashboard under Wallet infrastructure: Authorization keys and Policies.`);
} catch (e) {
  if (e instanceof APIError) {
    const hint = e.status === 401 || /app id/i.test(e.message) ? "\n  The app ID or the app secret is wrong. Copy both again from the Dashboard (docs/privy-setup.md, step 2)." : "";
    stop(`Privy answered ${e.status}: ${e.message}${hint}`);
  }
  throw e;
}
